(() => {
    "use strict";
    var e, t = {
            135: (e, t, s) => {
                s.d(t, {
                    Z: () => wt
                });
                s(747);
                const n = (e, ...t) => {
                    let s = e;
                    return t.length > 0 && (s += ` :: ${JSON.stringify(t)}`), s
                };
                class r extends Error {
                    constructor(e, t) {
                        super(n(e, t)), this.name = e, this.details = t
                    }
                }
                let a, i;
                const o = new WeakMap,
                    c = new WeakMap,
                    h = new WeakMap,
                    u = new WeakMap,
                    l = new WeakMap;
                let d = {
                    get(e, t, s) {
                        if (e instanceof IDBTransaction) {
                            if ("done" === t) return c.get(e);
                            if ("objectStoreNames" === t) return e.objectStoreNames || h.get(e);
                            if ("store" === t) return s.objectStoreNames[1] ? void 0 : s.objectStore(s.objectStoreNames[0])
                        }
                        return m(e[t])
                    },
                    set: (e, t, s) => (e[t] = s, !0),
                    has: (e, t) => e instanceof IDBTransaction && ("done" === t || "store" === t) || t in e
                };

                function f(e) {
                    return e !== IDBDatabase.prototype.transaction || "objectStoreNames" in IDBTransaction.prototype ? (i || (i = [IDBCursor.prototype.advance, IDBCursor.prototype.continue, IDBCursor.prototype.continuePrimaryKey])).includes(e) ? function(...t) {
                        return e.apply(w(this), t), m(o.get(this))
                    } : function(...t) {
                        return m(e.apply(w(this), t))
                    } : function(t, ...s) {
                        const n = e.call(w(this), t, ...s);
                        return h.set(n, t.sort ? t.sort() : [t]), m(n)
                    }
                }

                function p(e) {
                    return "function" == typeof e ? f(e) : (e instanceof IDBTransaction && function(e) {
                        if (c.has(e)) return;
                        const t = new Promise(((t, s) => {
                            const n = () => {
                                    e.removeEventListener("complete", r), e.removeEventListener("error", a), e.removeEventListener("abort", a)
                                },
                                r = () => {
                                    t(), n()
                                },
                                a = () => {
                                    s(e.error || new DOMException("AbortError", "AbortError")), n()
                                };
                            e.addEventListener("complete", r), e.addEventListener("error", a), e.addEventListener("abort", a)
                        }));
                        c.set(e, t)
                    }(e), t = e, (a || (a = [IDBDatabase, IDBObjectStore, IDBIndex, IDBCursor, IDBTransaction])).some((e => t instanceof e)) ? new Proxy(e, d) : e);
                    var t
                }

                function m(e) {
                    if (e instanceof IDBRequest) return function(e) {
                        const t = new Promise(((t, s) => {
                            const n = () => {
                                    e.removeEventListener("success", r), e.removeEventListener("error", a)
                                },
                                r = () => {
                                    t(m(e.result)), n()
                                },
                                a = () => {
                                    s(e.error), n()
                                };
                            e.addEventListener("success", r), e.addEventListener("error", a)
                        }));
                        return t.then((t => {
                            t instanceof IDBCursor && o.set(t, e)
                        })).catch((() => {})), l.set(t, e), t
                    }(e);
                    if (u.has(e)) return u.get(e);
                    const t = p(e);
                    return t !== e && (u.set(e, t), l.set(t, e)), t
                }
                const w = e => l.get(e);
                const g = ["get", "getKey", "getAll", "getAllKeys", "count"],
                    y = ["put", "add", "delete", "clear"],
                    _ = new Map;

                function b(e, t) {
                    if (!(e instanceof IDBDatabase) || t in e || "string" != typeof t) return;
                    if (_.get(t)) return _.get(t);
                    const s = t.replace(/FromIndex$/, ""),
                        n = t !== s,
                        r = y.includes(s);
                    if (!(s in (n ? IDBIndex : IDBObjectStore).prototype) || !r && !g.includes(s)) return;
                    const a = async function(e, ...t) {
                        const a = this.transaction(e, r ? "readwrite" : "readonly");
                        let i = a.store;
                        return n && (i = i.index(t.shift())), (await Promise.all([i[s](...t), r && a.done]))[0]
                    };
                    return _.set(t, a), a
                }
                d = (e => ({ ...e,
                    get: (t, s, n) => b(t, s) || e.get(t, s, n),
                    has: (t, s) => !!b(t, s) || e.has(t, s)
                }))(d);
                s(272);
                const v = "requests",
                    q = "queueName";
                class R {
                    constructor() {
                        this._db = null
                    }
                    async addEntry(e) {
                        const t = (await this.getDb()).transaction(v, "readwrite", {
                            durability: "relaxed"
                        });
                        await t.store.add(e), await t.done
                    }
                    async getFirstEntryId() {
                        const e = await this.getDb(),
                            t = await e.transaction(v).store.openCursor();
                        return null == t ? void 0 : t.value.id
                    }
                    async getAllEntriesByQueueName(e) {
                        const t = await this.getDb(),
                            s = await t.getAllFromIndex(v, q, IDBKeyRange.only(e));
                        return s || new Array
                    }
                    async getEntryCountByQueueName(e) {
                        return (await this.getDb()).countFromIndex(v, q, IDBKeyRange.only(e))
                    }
                    async deleteEntry(e) {
                        const t = await this.getDb();
                        await t.delete(v, e)
                    }
                    async getFirstEntryByQueueName(e) {
                        return await this.getEndEntryFromIndex(IDBKeyRange.only(e), "next")
                    }
                    async getLastEntryByQueueName(e) {
                        return await this.getEndEntryFromIndex(IDBKeyRange.only(e), "prev")
                    }
                    async getEndEntryFromIndex(e, t) {
                        const s = await this.getDb(),
                            n = await s.transaction(v).store.index(q).openCursor(e, t);
                        return null == n ? void 0 : n.value
                    }
                    async getDb() {
                        return this._db || (this._db = await
                            function(e, t, {
                                blocked: s,
                                upgrade: n,
                                blocking: r,
                                terminated: a
                            } = {}) {
                                const i = indexedDB.open(e, t),
                                    o = m(i);
                                return n && i.addEventListener("upgradeneeded", (e => {
                                    n(m(i.result), e.oldVersion, e.newVersion, m(i.transaction))
                                })), s && i.addEventListener("blocked", (() => s())), o.then((e => {
                                    a && e.addEventListener("close", (() => a())), r && e.addEventListener("versionchange", (() => r()))
                                })).catch((() => {})), o
                            }("workbox-background-sync", 3, {
                                upgrade: this._upgradeDb
                            })), this._db
                    }
                    _upgradeDb(e, t) {
                        t > 0 && t < 3 && e.objectStoreNames.contains(v) && e.deleteObjectStore(v);
                        e.createObjectStore(v, {
                            autoIncrement: !0,
                            keyPath: "id"
                        }).createIndex(q, q, {
                            unique: !1
                        })
                    }
                }
                class E {
                    constructor(e) {
                        this._queueName = e, this._queueDb = new R
                    }
                    async pushEntry(e) {
                        delete e.id, e.queueName = this._queueName, await this._queueDb.addEntry(e)
                    }
                    async unshiftEntry(e) {
                        const t = await this._queueDb.getFirstEntryId();
                        t ? e.id = t - 1 : delete e.id, e.queueName = this._queueName, await this._queueDb.addEntry(e)
                    }
                    async popEntry() {
                        return this._removeEntry(await this._queueDb.getLastEntryByQueueName(this._queueName))
                    }
                    async shiftEntry() {
                        return this._removeEntry(await this._queueDb.getFirstEntryByQueueName(this._queueName))
                    }
                    async getAll() {
                        return await this._queueDb.getAllEntriesByQueueName(this._queueName)
                    }
                    async size() {
                        return await this._queueDb.getEntryCountByQueueName(this._queueName)
                    }
                    async deleteEntry(e) {
                        await this._queueDb.deleteEntry(e)
                    }
                    async _removeEntry(e) {
                        return e && await this.deleteEntry(e.id), e
                    }
                }
                const x = ["method", "referrer", "referrerPolicy", "mode", "credentials", "cache", "redirect", "integrity", "keepalive"];
                class k {
                    constructor(e) {
                        "navigate" === e.mode && (e.mode = "same-origin"), this._requestData = e
                    }
                    static async fromRequest(e) {
                        const t = {
                            url: e.url,
                            headers: {}
                        };
                        "GET" !== e.method && (t.body = await e.clone().arrayBuffer());
                        for (const [s, n] of e.headers.entries()) t.headers[s] = n;
                        for (const s of x) void 0 !== e[s] && (t[s] = e[s]);
                        return new k(t)
                    }
                    toObject() {
                        const e = Object.assign({}, this._requestData);
                        return e.headers = Object.assign({}, this._requestData.headers), e.body && (e.body = e.body.slice(0)), e
                    }
                    toRequest() {
                        return new Request(this._requestData.url, this._requestData)
                    }
                    clone() {
                        return new k(this.toObject())
                    }
                }
                const D = "workbox-background-sync",
                    C = new Set,
                    S = e => {
                        const t = {
                            request: new k(e.requestData).toRequest(),
                            timestamp: e.timestamp
                        };
                        return e.metadata && (t.metadata = e.metadata), t
                    };
                class T {
                    constructor(e, {
                        onSync: t,
                        maxRetentionTime: s
                    } = {}) {
                        if (this._syncInProgress = !1, this._requestsAddedDuringSync = !1, C.has(e)) throw new r("duplicate-queue-name", {
                            name: e
                        });
                        C.add(e), this._name = e, this._onSync = t || this.replayRequests, this._maxRetentionTime = s || 10080, this._queueStore = new E(this._name), this._addSyncListener()
                    }
                    get name() {
                        return this._name
                    }
                    async pushRequest(e) {
                        await this._addRequest(e, "push")
                    }
                    async unshiftRequest(e) {
                        await this._addRequest(e, "unshift")
                    }
                    async popRequest() {
                        return this._removeRequest("pop")
                    }
                    async shiftRequest() {
                        return this._removeRequest("shift")
                    }
                    async getAll() {
                        const e = await this._queueStore.getAll(),
                            t = Date.now(),
                            s = [];
                        for (const n of e) {
                            const e = 60 * this._maxRetentionTime * 1e3;
                            t - n.timestamp > e ? await this._queueStore.deleteEntry(n.id) : s.push(S(n))
                        }
                        return s
                    }
                    async size() {
                        return await this._queueStore.size()
                    }
                    async _addRequest({
                        request: e,
                        metadata: t,
                        timestamp: s = Date.now()
                    }, n) {
                        const r = {
                            requestData: (await k.fromRequest(e.clone())).toObject(),
                            timestamp: s
                        };
                        t && (r.metadata = t), await this._queueStore[`${n}Entry`](r), this._syncInProgress ? this._requestsAddedDuringSync = !0 : await this.registerSync()
                    }
                    async _removeRequest(e) {
                        const t = Date.now(),
                            s = await this._queueStore[`${e}Entry`]();
                        if (s) {
                            const n = 60 * this._maxRetentionTime * 1e3;
                            return t - s.timestamp > n ? this._removeRequest(e) : S(s)
                        }
                    }
                    async replayRequests() {
                        let e;
                        for (; e = await this.shiftRequest();) try {
                            await fetch(e.request.clone())
                        } catch (t) {
                            throw await this.unshiftRequest(e), new r("queue-replay-failed", {
                                name: this._name
                            })
                        }
                    }
                    async registerSync() {
                        if ("sync" in self.registration) try {
                            await self.registration.sync.register(`${D}:${this._name}`)
                        } catch (e) {
                            0
                        }
                    }
                    _addSyncListener() {
                        "sync" in self.registration ? self.addEventListener("sync", (e => {
                            if (e.tag === `${D}:${this._name}`) {
                                0;
                                const t = async () => {
                                    let t;
                                    this._syncInProgress = !0;
                                    try {
                                        await this._onSync({
                                            queue: this
                                        })
                                    } catch (s) {
                                        if (s instanceof Error) throw t = s, t
                                    } finally {
                                        !this._requestsAddedDuringSync || t && !e.lastChance || await this.registerSync(), this._syncInProgress = !1, this._requestsAddedDuringSync = !1
                                    }
                                };
                                e.waitUntil(t())
                            }
                        })) : this._onSync({
                            queue: this
                        })
                    }
                    static get _queueNames() {
                        return C
                    }
                }
                class N {
                    constructor(e, t) {
                        this.fetchDidFail = async ({
                            request: e
                        }) => {
                            await this._queue.pushRequest({
                                request: e
                            })
                        }, this._queue = new T(e, t)
                    }
                }
                s(988);
                const L = {
                        googleAnalytics: "googleAnalytics",
                        precache: "precache-v2",
                        prefix: "workbox",
                        runtime: "runtime",
                        suffix: "undefined" != typeof registration ? registration.scope : ""
                    },
                    P = e => [L.prefix, e, L.suffix].filter((e => e && e.length > 0)).join("-"),
                    I = e => e || P(L.googleAnalytics),
                    U = e => e || P(L.runtime),
                    O = e => new URL(String(e), location.href).href.replace(new RegExp(`^${location.origin}`), ""),
                    M = (e, ...t) => {
                        let s = e;
                        return t.length > 0 && (s += ` :: ${JSON.stringify(t)}`), s
                    };
                class A extends Error {
                    constructor(e, t) {
                        super(M(e, t)), this.name = e, this.details = t
                    }
                }
                s(931);
                const B = e => e && "object" == typeof e ? e : {
                    handle: e
                };
                class j {
                    constructor(e, t, s = "GET") {
                        this.handler = B(t), this.match = e, this.method = s
                    }
                    setCatchHandler(e) {
                        this.catchHandler = B(e)
                    }
                }
                class K {
                    constructor() {
                        this._routes = new Map, this._defaultHandlerMap = new Map
                    }
                    get routes() {
                        return this._routes
                    }
                    addFetchListener() {
                        self.addEventListener("fetch", (e => {
                            const {
                                request: t
                            } = e, s = this.handleRequest({
                                request: t,
                                event: e
                            });
                            s && e.respondWith(s)
                        }))
                    }
                    addCacheListener() {
                        self.addEventListener("message", (e => {
                            if (e.data && "CACHE_URLS" === e.data.type) {
                                const {
                                    payload: t
                                } = e.data;
                                0;
                                const s = Promise.all(t.urlsToCache.map((t => {
                                    "string" == typeof t && (t = [t]);
                                    const s = new Request(...t);
                                    return this.handleRequest({
                                        request: s,
                                        event: e
                                    })
                                })));
                                e.waitUntil(s), e.ports && e.ports[0] && s.then((() => e.ports[0].postMessage(!0)))
                            }
                        }))
                    }
                    handleRequest({
                        request: e,
                        event: t
                    }) {
                        const s = new URL(e.url, location.href);
                        if (!s.protocol.startsWith("http")) return void 0;
                        const n = s.origin === location.origin,
                            {
                                params: r,
                                route: a
                            } = this.findMatchingRoute({
                                event: t,
                                request: e,
                                sameOrigin: n,
                                url: s
                            });
                        let i = a && a.handler;
                        const o = e.method;
                        if (!i && this._defaultHandlerMap.has(o) && (i = this._defaultHandlerMap.get(o)), !i) return void 0;
                        let c;
                        try {
                            c = i.handle({
                                url: s,
                                request: e,
                                event: t,
                                params: r
                            })
                        } catch (u) {
                            c = Promise.reject(u)
                        }
                        const h = a && a.catchHandler;
                        return c instanceof Promise && (this._catchHandler || h) && (c = c.catch((async n => {
                            if (h) {
                                0;
                                try {
                                    return await h.handle({
                                        url: s,
                                        request: e,
                                        event: t,
                                        params: r
                                    })
                                } catch (a) {
                                    a instanceof Error && (n = a)
                                }
                            }
                            if (this._catchHandler) return this._catchHandler.handle({
                                url: s,
                                request: e,
                                event: t
                            });
                            throw n
                        }))), c
                    }
                    findMatchingRoute({
                        url: e,
                        sameOrigin: t,
                        request: s,
                        event: n
                    }) {
                        const r = this._routes.get(s.method) || [];
                        for (const a of r) {
                            let r;
                            const i = a.match({
                                url: e,
                                sameOrigin: t,
                                request: s,
                                event: n
                            });
                            if (i) return r = i, (Array.isArray(r) && 0 === r.length || i.constructor === Object && 0 === Object.keys(i).length || "boolean" == typeof i) && (r = void 0), {
                                route: a,
                                params: r
                            }
                        }
                        return {}
                    }
                    setDefaultHandler(e, t = "GET") {
                        this._defaultHandlerMap.set(t, B(e))
                    }
                    setCatchHandler(e) {
                        this._catchHandler = B(e)
                    }
                    registerRoute(e) {
                        this._routes.has(e.method) || this._routes.set(e.method, []), this._routes.get(e.method).push(e)
                    }
                    unregisterRoute(e) {
                        if (!this._routes.has(e.method)) throw new A("unregister-route-but-not-found-with-method", {
                            method: e.method
                        });
                        const t = this._routes.get(e.method).indexOf(e);
                        if (!(t > -1)) throw new A("unregister-route-route-not-registered");
                        this._routes.get(e.method).splice(t, 1)
                    }
                }
                s(691);
                const W = {
                    cacheWillUpdate: async ({
                        response: e
                    }) => 200 === e.status || 0 === e.status ? e : null
                };

                function F(e, t) {
                    const s = new URL(e);
                    for (const n of t) s.searchParams.delete(n);
                    return s.href
                }
                class H {
                    constructor() {
                        this.promise = new Promise(((e, t) => {
                            this.resolve = e, this.reject = t
                        }))
                    }
                }
                const $ = new Set;

                function V(e) {
                    return new Promise((t => setTimeout(t, e)))
                }

                function G(e) {
                    return "string" == typeof e ? new Request(e) : e
                }
                class Q {
                    constructor(e, t) {
                        this._cacheKeys = {}, Object.assign(this, t), this.event = t.event, this._strategy = e, this._handlerDeferred = new H, this._extendLifetimePromises = [], this._plugins = [...e.plugins], this._pluginStateMap = new Map;
                        for (const s of this._plugins) this._pluginStateMap.set(s, {});
                        this.event.waitUntil(this._handlerDeferred.promise)
                    }
                    async fetch(e) {
                        const {
                            event: t
                        } = this;
                        let s = G(e);
                        if ("navigate" === s.mode && t instanceof FetchEvent && t.preloadResponse) {
                            const e = await t.preloadResponse;
                            if (e) return e
                        }
                        const n = this.hasCallback("fetchDidFail") ? s.clone() : null;
                        try {
                            for (const e of this.iterateCallbacks("requestWillFetch")) s = await e({
                                request: s.clone(),
                                event: t
                            })
                        } catch (a) {
                            if (a instanceof Error) throw new A("plugin-error-request-will-fetch", {
                                thrownErrorMessage: a.message
                            })
                        }
                        const r = s.clone();
                        try {
                            let e;
                            e = await fetch(s, "navigate" === s.mode ? void 0 : this._strategy.fetchOptions);
                            for (const s of this.iterateCallbacks("fetchDidSucceed")) e = await s({
                                event: t,
                                request: r,
                                response: e
                            });
                            return e
                        } catch (i) {
                            throw n && await this.runCallbacks("fetchDidFail", {
                                error: i,
                                event: t,
                                originalRequest: n.clone(),
                                request: r.clone()
                            }), i
                        }
                    }
                    async fetchAndCachePut(e) {
                        const t = await this.fetch(e),
                            s = t.clone();
                        return this.waitUntil(this.cachePut(e, s)), t
                    }
                    async cacheMatch(e) {
                        const t = G(e);
                        let s;
                        const {
                            cacheName: n,
                            matchOptions: r
                        } = this._strategy, a = await this.getCacheKey(t, "read"), i = Object.assign(Object.assign({}, r), {
                            cacheName: n
                        });
                        s = await caches.match(a, i);
                        for (const o of this.iterateCallbacks("cachedResponseWillBeUsed")) s = await o({
                            cacheName: n,
                            matchOptions: r,
                            cachedResponse: s,
                            request: a,
                            event: this.event
                        }) || void 0;
                        return s
                    }
                    async cachePut(e, t) {
                        const s = G(e);
                        await V(0);
                        const n = await this.getCacheKey(s, "write");
                        if (!t) throw new A("cache-put-with-no-response", {
                            url: O(n.url)
                        });
                        const r = await this._ensureResponseSafeToCache(t);
                        if (!r) return !1;
                        const {
                            cacheName: a,
                            matchOptions: i
                        } = this._strategy, o = await self.caches.open(a), c = this.hasCallback("cacheDidUpdate"), h = c ? await async function(e, t, s, n) {
                            const r = F(t.url, s);
                            if (t.url === r) return e.match(t, n);
                            const a = Object.assign(Object.assign({}, n), {
                                    ignoreSearch: !0
                                }),
                                i = await e.keys(t, a);
                            for (const o of i)
                                if (r === F(o.url, s)) return e.match(o, n)
                        }(o, n.clone(), ["__WB_REVISION__"], i) : null;
                        try {
                            await o.put(n, c ? r.clone() : r)
                        } catch (u) {
                            if (u instanceof Error) throw "QuotaExceededError" === u.name && await async function() {
                                for (const e of $) await e()
                            }(), u
                        }
                        for (const l of this.iterateCallbacks("cacheDidUpdate")) await l({
                            cacheName: a,
                            oldResponse: h,
                            newResponse: r.clone(),
                            request: n,
                            event: this.event
                        });
                        return !0
                    }
                    async getCacheKey(e, t) {
                        const s = `${e.url} | ${t}`;
                        if (!this._cacheKeys[s]) {
                            let n = e;
                            for (const e of this.iterateCallbacks("cacheKeyWillBeUsed")) n = G(await e({
                                mode: t,
                                request: n,
                                event: this.event,
                                params: this.params
                            }));
                            this._cacheKeys[s] = n
                        }
                        return this._cacheKeys[s]
                    }
                    hasCallback(e) {
                        for (const t of this._strategy.plugins)
                            if (e in t) return !0;
                        return !1
                    }
                    async runCallbacks(e, t) {
                        for (const s of this.iterateCallbacks(e)) await s(t)
                    }* iterateCallbacks(e) {
                        for (const t of this._strategy.plugins)
                            if ("function" == typeof t[e]) {
                                const s = this._pluginStateMap.get(t),
                                    n = n => {
                                        const r = Object.assign(Object.assign({}, n), {
                                            state: s
                                        });
                                        return t[e](r)
                                    };
                                yield n
                            }
                    }
                    waitUntil(e) {
                        return this._extendLifetimePromises.push(e), e
                    }
                    async doneWaiting() {
                        let e;
                        for (; e = this._extendLifetimePromises.shift();) await e
                    }
                    destroy() {
                        this._handlerDeferred.resolve(null)
                    }
                    async _ensureResponseSafeToCache(e) {
                        let t = e,
                            s = !1;
                        for (const n of this.iterateCallbacks("cacheWillUpdate"))
                            if (t = await n({
                                    request: this.request,
                                    response: t,
                                    event: this.event
                                }) || void 0, s = !0, !t) break;
                        return s || t && 200 !== t.status && (t = void 0), t
                    }
                }
                class z {
                    constructor(e = {}) {
                        this.cacheName = U(e.cacheName), this.plugins = e.plugins || [], this.fetchOptions = e.fetchOptions, this.matchOptions = e.matchOptions
                    }
                    handle(e) {
                        const [t] = this.handleAll(e);
                        return t
                    }
                    handleAll(e) {
                        e instanceof FetchEvent && (e = {
                            event: e,
                            request: e.request
                        });
                        const t = e.event,
                            s = "string" == typeof e.request ? new Request(e.request) : e.request,
                            n = "params" in e ? e.params : void 0,
                            r = new Q(this, {
                                event: t,
                                request: s,
                                params: n
                            }),
                            a = this._getResponse(r, s, t);
                        return [a, this._awaitComplete(a, r, s, t)]
                    }
                    async _getResponse(e, t, s) {
                        let n;
                        await e.runCallbacks("handlerWillStart", {
                            event: s,
                            request: t
                        });
                        try {
                            if (n = await this._handle(t, e), !n || "error" === n.type) throw new A("no-response", {
                                url: t.url
                            })
                        } catch (r) {
                            if (r instanceof Error)
                                for (const a of e.iterateCallbacks("handlerDidError"))
                                    if (n = await a({
                                            error: r,
                                            event: s,
                                            request: t
                                        }), n) break;
                            if (!n) throw r
                        }
                        for (const a of e.iterateCallbacks("handlerWillRespond")) n = await a({
                            event: s,
                            request: t,
                            response: n
                        });
                        return n
                    }
                    async _awaitComplete(e, t, s, n) {
                        let r, a;
                        try {
                            r = await e
                        } catch (a) {}
                        try {
                            await t.runCallbacks("handlerDidRespond", {
                                event: n,
                                request: s,
                                response: r
                            }), await t.doneWaiting()
                        } catch (i) {
                            i instanceof Error && (a = i)
                        }
                        if (await t.runCallbacks("handlerDidComplete", {
                                event: n,
                                request: s,
                                response: r,
                                error: a
                            }), t.destroy(), a) throw a
                    }
                }
                class J extends z {
                    constructor(e = {}) {
                        super(e), this.plugins.some((e => "cacheWillUpdate" in e)) || this.plugins.unshift(W), this._networkTimeoutSeconds = e.networkTimeoutSeconds || 0
                    }
                    async _handle(e, t) {
                        const s = [];
                        const n = [];
                        let r;
                        if (this._networkTimeoutSeconds) {
                            const {
                                id: a,
                                promise: i
                            } = this._getTimeoutPromise({
                                request: e,
                                logs: s,
                                handler: t
                            });
                            r = a, n.push(i)
                        }
                        const a = this._getNetworkPromise({
                            timeoutId: r,
                            request: e,
                            logs: s,
                            handler: t
                        });
                        n.push(a);
                        const i = await t.waitUntil((async () => await t.waitUntil(Promise.race(n)) || await a)());
                        if (!i) throw new A("no-response", {
                            url: e.url
                        });
                        return i
                    }
                    _getTimeoutPromise({
                        request: e,
                        logs: t,
                        handler: s
                    }) {
                        let n;
                        return {
                            promise: new Promise((t => {
                                n = setTimeout((async () => {
                                    t(await s.cacheMatch(e))
                                }), 1e3 * this._networkTimeoutSeconds)
                            })),
                            id: n
                        }
                    }
                    async _getNetworkPromise({
                        timeoutId: e,
                        request: t,
                        logs: s,
                        handler: n
                    }) {
                        let r, a;
                        try {
                            a = await n.fetchAndCachePut(t)
                        } catch (i) {
                            i instanceof Error && (r = i)
                        }
                        return e && clearTimeout(e), !r && a || (a = await n.cacheMatch(t)), a
                    }
                }
                class Z extends z {
                    constructor(e = {}) {
                        super(e), this._networkTimeoutSeconds = e.networkTimeoutSeconds || 0
                    }
                    async _handle(e, t) {
                        let s, n;
                        try {
                            const s = [t.fetch(e)];
                            if (this._networkTimeoutSeconds) {
                                const e = V(1e3 * this._networkTimeoutSeconds);
                                s.push(e)
                            }
                            if (n = await Promise.race(s), !n) throw new Error(`Timed out the network response after ${this._networkTimeoutSeconds} seconds.`)
                        } catch (r) {
                            r instanceof Error && (s = r)
                        }
                        if (!n) throw new A("no-response", {
                            url: e.url,
                            error: s
                        });
                        return n
                    }
                }
                s(612);
                const X = "www.google-analytics.com",
                    Y = "www.googletagmanager.com",
                    ee = /^\/(\w+\/)?collect/,
                    te = e => {
                        const t = ({
                                url: e
                            }) => e.hostname === X && ee.test(e.pathname),
                            s = new Z({
                                plugins: [e]
                            });
                        return [new j(t, s, "GET"), new j(t, s, "POST")]
                    },
                    se = e => {
                        const t = new J({
                            cacheName: e
                        });
                        return new j((({
                            url: e
                        }) => e.hostname === X && "/analytics.js" === e.pathname), t, "GET")
                    },
                    ne = e => {
                        const t = new J({
                            cacheName: e
                        });
                        return new j((({
                            url: e
                        }) => e.hostname === Y && "/gtag/js" === e.pathname), t, "GET")
                    },
                    re = e => {
                        const t = new J({
                            cacheName: e
                        });
                        return new j((({
                            url: e
                        }) => e.hostname === Y && "/gtm.js" === e.pathname), t, "GET")
                    };
                s(913);
                const ae = (e, ...t) => {
                    let s = e;
                    return t.length > 0 && (s += ` :: ${JSON.stringify(t)}`), s
                };
                class ie extends Error {
                    constructor(e, t) {
                        super(ae(e, t)), this.name = e, this.details = t
                    }
                }
                const oe = new Set;
                const ce = {
                        googleAnalytics: "googleAnalytics",
                        precache: "precache-v2",
                        prefix: "workbox",
                        runtime: "runtime",
                        suffix: "undefined" != typeof registration ? registration.scope : ""
                    },
                    he = e => [ce.prefix, e, ce.suffix].filter((e => e && e.length > 0)).join("-"),
                    ue = e => {
                        (e => {
                            for (const t of Object.keys(ce)) e(t)
                        })((t => {
                            "string" == typeof e[t] && (ce[t] = e[t])
                        }))
                    },
                    le = e => e || he(ce.precache),
                    de = e => e || he(ce.runtime);

                function fe(e, t) {
                    const s = new URL(e);
                    for (const n of t) s.searchParams.delete(n);
                    return s.href
                }
                let pe;

                function me(e) {
                    e.then((() => {}))
                }
                class we {
                    constructor() {
                        this.promise = new Promise(((e, t) => {
                            this.resolve = e, this.reject = t
                        }))
                    }
                }
                const ge = e => new URL(String(e), location.href).href.replace(new RegExp(`^${location.origin}`), "");

                function ye(e) {
                    return new Promise((t => setTimeout(t, e)))
                }

                function _e(e, t) {
                    const s = t();
                    return e.waitUntil(s), s
                }
                async function be(e, t) {
                    let s = null;
                    if (e.url) {
                        s = new URL(e.url).origin
                    }
                    if (s !== self.location.origin) throw new ie("cross-origin-copy-response", {
                        origin: s
                    });
                    const n = e.clone(),
                        r = {
                            headers: new Headers(n.headers),
                            status: n.status,
                            statusText: n.statusText
                        },
                        a = t ? t(r) : r,
                        i = function() {
                            if (void 0 === pe) {
                                const t = new Response("");
                                if ("body" in t) try {
                                    new Response(t.body), pe = !0
                                } catch (e) {
                                    pe = !1
                                }
                                pe = !1
                            }
                            return pe
                        }() ? n.body : await n.blob();
                    return new Response(i, a)
                }
                s(977);

                function ve(e) {
                    if (!e) throw new ie("add-to-cache-list-unexpected-type", {
                        entry: e
                    });
                    if ("string" == typeof e) {
                        const t = new URL(e, location.href);
                        return {
                            cacheKey: t.href,
                            url: t.href
                        }
                    }
                    const {
                        revision: t,
                        url: s
                    } = e;
                    if (!s) throw new ie("add-to-cache-list-unexpected-type", {
                        entry: e
                    });
                    if (!t) {
                        const e = new URL(s, location.href);
                        return {
                            cacheKey: e.href,
                            url: e.href
                        }
                    }
                    const n = new URL(s, location.href),
                        r = new URL(s, location.href);
                    return n.searchParams.set("__WB_REVISION__", t), {
                        cacheKey: n.href,
                        url: r.href
                    }
                }
                class qe {
                    constructor() {
                        this.updatedURLs = [], this.notUpdatedURLs = [], this.handlerWillStart = async ({
                            request: e,
                            state: t
                        }) => {
                            t && (t.originalRequest = e)
                        }, this.cachedResponseWillBeUsed = async ({
                            event: e,
                            state: t,
                            cachedResponse: s
                        }) => {
                            if ("install" === e.type && t && t.originalRequest && t.originalRequest instanceof Request) {
                                const e = t.originalRequest.url;
                                s ? this.notUpdatedURLs.push(e) : this.updatedURLs.push(e)
                            }
                            return s
                        }
                    }
                }
                class Re {
                    constructor({
                        precacheController: e
                    }) {
                        this.cacheKeyWillBeUsed = async ({
                            request: e,
                            params: t
                        }) => {
                            const s = (null == t ? void 0 : t.cacheKey) || this._precacheController.getCacheKeyForURL(e.url);
                            return s ? new Request(s, {
                                headers: e.headers
                            }) : e
                        }, this._precacheController = e
                    }
                }
                s(873);

                function Ee(e) {
                    return "string" == typeof e ? new Request(e) : e
                }
                class xe {
                    constructor(e, t) {
                        this._cacheKeys = {}, Object.assign(this, t), this.event = t.event, this._strategy = e, this._handlerDeferred = new we, this._extendLifetimePromises = [], this._plugins = [...e.plugins], this._pluginStateMap = new Map;
                        for (const s of this._plugins) this._pluginStateMap.set(s, {});
                        this.event.waitUntil(this._handlerDeferred.promise)
                    }
                    async fetch(e) {
                        const {
                            event: t
                        } = this;
                        let s = Ee(e);
                        if ("navigate" === s.mode && t instanceof FetchEvent && t.preloadResponse) {
                            const e = await t.preloadResponse;
                            if (e) return e
                        }
                        const n = this.hasCallback("fetchDidFail") ? s.clone() : null;
                        try {
                            for (const e of this.iterateCallbacks("requestWillFetch")) s = await e({
                                request: s.clone(),
                                event: t
                            })
                        } catch (a) {
                            if (a instanceof Error) throw new ie("plugin-error-request-will-fetch", {
                                thrownErrorMessage: a.message
                            })
                        }
                        const r = s.clone();
                        try {
                            let e;
                            e = await fetch(s, "navigate" === s.mode ? void 0 : this._strategy.fetchOptions);
                            for (const s of this.iterateCallbacks("fetchDidSucceed")) e = await s({
                                event: t,
                                request: r,
                                response: e
                            });
                            return e
                        } catch (i) {
                            throw n && await this.runCallbacks("fetchDidFail", {
                                error: i,
                                event: t,
                                originalRequest: n.clone(),
                                request: r.clone()
                            }), i
                        }
                    }
                    async fetchAndCachePut(e) {
                        const t = await this.fetch(e),
                            s = t.clone();
                        return this.waitUntil(this.cachePut(e, s)), t
                    }
                    async cacheMatch(e) {
                        const t = Ee(e);
                        let s;
                        const {
                            cacheName: n,
                            matchOptions: r
                        } = this._strategy, a = await this.getCacheKey(t, "read"), i = Object.assign(Object.assign({}, r), {
                            cacheName: n
                        });
                        s = await caches.match(a, i);
                        for (const o of this.iterateCallbacks("cachedResponseWillBeUsed")) s = await o({
                            cacheName: n,
                            matchOptions: r,
                            cachedResponse: s,
                            request: a,
                            event: this.event
                        }) || void 0;
                        return s
                    }
                    async cachePut(e, t) {
                        const s = Ee(e);
                        await ye(0);
                        const n = await this.getCacheKey(s, "write");
                        if (!t) throw new ie("cache-put-with-no-response", {
                            url: ge(n.url)
                        });
                        const r = await this._ensureResponseSafeToCache(t);
                        if (!r) return !1;
                        const {
                            cacheName: a,
                            matchOptions: i
                        } = this._strategy, o = await self.caches.open(a), c = this.hasCallback("cacheDidUpdate"), h = c ? await async function(e, t, s, n) {
                            const r = fe(t.url, s);
                            if (t.url === r) return e.match(t, n);
                            const a = Object.assign(Object.assign({}, n), {
                                    ignoreSearch: !0
                                }),
                                i = await e.keys(t, a);
                            for (const o of i)
                                if (r === fe(o.url, s)) return e.match(o, n)
                        }(o, n.clone(), ["__WB_REVISION__"], i) : null;
                        try {
                            await o.put(n, c ? r.clone() : r)
                        } catch (u) {
                            if (u instanceof Error) throw "QuotaExceededError" === u.name && await async function() {
                                for (const e of oe) await e()
                            }(), u
                        }
                        for (const l of this.iterateCallbacks("cacheDidUpdate")) await l({
                            cacheName: a,
                            oldResponse: h,
                            newResponse: r.clone(),
                            request: n,
                            event: this.event
                        });
                        return !0
                    }
                    async getCacheKey(e, t) {
                        const s = `${e.url} | ${t}`;
                        if (!this._cacheKeys[s]) {
                            let n = e;
                            for (const e of this.iterateCallbacks("cacheKeyWillBeUsed")) n = Ee(await e({
                                mode: t,
                                request: n,
                                event: this.event,
                                params: this.params
                            }));
                            this._cacheKeys[s] = n
                        }
                        return this._cacheKeys[s]
                    }
                    hasCallback(e) {
                        for (const t of this._strategy.plugins)
                            if (e in t) return !0;
                        return !1
                    }
                    async runCallbacks(e, t) {
                        for (const s of this.iterateCallbacks(e)) await s(t)
                    }* iterateCallbacks(e) {
                        for (const t of this._strategy.plugins)
                            if ("function" == typeof t[e]) {
                                const s = this._pluginStateMap.get(t),
                                    n = n => {
                                        const r = Object.assign(Object.assign({}, n), {
                                            state: s
                                        });
                                        return t[e](r)
                                    };
                                yield n
                            }
                    }
                    waitUntil(e) {
                        return this._extendLifetimePromises.push(e), e
                    }
                    async doneWaiting() {
                        let e;
                        for (; e = this._extendLifetimePromises.shift();) await e
                    }
                    destroy() {
                        this._handlerDeferred.resolve(null)
                    }
                    async _ensureResponseSafeToCache(e) {
                        let t = e,
                            s = !1;
                        for (const n of this.iterateCallbacks("cacheWillUpdate"))
                            if (t = await n({
                                    request: this.request,
                                    response: t,
                                    event: this.event
                                }) || void 0, s = !0, !t) break;
                        return s || t && 200 !== t.status && (t = void 0), t
                    }
                }
                class ke {
                    constructor(e = {}) {
                        this.cacheName = de(e.cacheName), this.plugins = e.plugins || [], this.fetchOptions = e.fetchOptions, this.matchOptions = e.matchOptions
                    }
                    handle(e) {
                        const [t] = this.handleAll(e);
                        return t
                    }
                    handleAll(e) {
                        e instanceof FetchEvent && (e = {
                            event: e,
                            request: e.request
                        });
                        const t = e.event,
                            s = "string" == typeof e.request ? new Request(e.request) : e.request,
                            n = "params" in e ? e.params : void 0,
                            r = new xe(this, {
                                event: t,
                                request: s,
                                params: n
                            }),
                            a = this._getResponse(r, s, t);
                        return [a, this._awaitComplete(a, r, s, t)]
                    }
                    async _getResponse(e, t, s) {
                        let n;
                        await e.runCallbacks("handlerWillStart", {
                            event: s,
                            request: t
                        });
                        try {
                            if (n = await this._handle(t, e), !n || "error" === n.type) throw new ie("no-response", {
                                url: t.url
                            })
                        } catch (r) {
                            if (r instanceof Error)
                                for (const a of e.iterateCallbacks("handlerDidError"))
                                    if (n = await a({
                                            error: r,
                                            event: s,
                                            request: t
                                        }), n) break;
                            if (!n) throw r
                        }
                        for (const a of e.iterateCallbacks("handlerWillRespond")) n = await a({
                            event: s,
                            request: t,
                            response: n
                        });
                        return n
                    }
                    async _awaitComplete(e, t, s, n) {
                        let r, a;
                        try {
                            r = await e
                        } catch (a) {}
                        try {
                            await t.runCallbacks("handlerDidRespond", {
                                event: n,
                                request: s,
                                response: r
                            }), await t.doneWaiting()
                        } catch (i) {
                            i instanceof Error && (a = i)
                        }
                        if (await t.runCallbacks("handlerDidComplete", {
                                event: n,
                                request: s,
                                response: r,
                                error: a
                            }), t.destroy(), a) throw a
                    }
                }
                class De extends ke {
                    constructor(e = {}) {
                        e.cacheName = le(e.cacheName), super(e), this._fallbackToNetwork = !1 !== e.fallbackToNetwork, this.plugins.push(De.copyRedirectedCacheableResponsesPlugin)
                    }
                    async _handle(e, t) {
                        const s = await t.cacheMatch(e);
                        return s || (t.event && "install" === t.event.type ? await this._handleInstall(e, t) : await this._handleFetch(e, t))
                    }
                    async _handleFetch(e, t) {
                        let s;
                        const n = t.params || {};
                        if (!this._fallbackToNetwork) throw new ie("missing-precache-entry", {
                            cacheName: this.cacheName,
                            url: e.url
                        }); {
                            0;
                            const r = n.integrity,
                                a = e.integrity,
                                i = !a || a === r;
                            if (s = await t.fetch(new Request(e, {
                                    integrity: "no-cors" !== e.mode ? a || r : void 0
                                })), r && i && "no-cors" !== e.mode) {
                                this._useDefaultCacheabilityPluginIfNeeded();
                                await t.cachePut(e, s.clone());
                                0
                            }
                        }
                        return s
                    }
                    async _handleInstall(e, t) {
                        this._useDefaultCacheabilityPluginIfNeeded();
                        const s = await t.fetch(e);
                        if (!(await t.cachePut(e, s.clone()))) throw new ie("bad-precaching-response", {
                            url: e.url,
                            status: s.status
                        });
                        return s
                    }
                    _useDefaultCacheabilityPluginIfNeeded() {
                        let e = null,
                            t = 0;
                        for (const [s, n] of this.plugins.entries()) n !== De.copyRedirectedCacheableResponsesPlugin && (n === De.defaultPrecacheCacheabilityPlugin && (e = s), n.cacheWillUpdate && t++);
                        0 === t ? this.plugins.push(De.defaultPrecacheCacheabilityPlugin) : t > 1 && null !== e && this.plugins.splice(e, 1)
                    }
                }
                De.defaultPrecacheCacheabilityPlugin = {
                    cacheWillUpdate: async ({
                        response: e
                    }) => !e || e.status >= 400 ? null : e
                }, De.copyRedirectedCacheableResponsesPlugin = {
                    cacheWillUpdate: async ({
                        response: e
                    }) => e.redirected ? await be(e) : e
                };
                class Ce {
                    constructor({
                        cacheName: e,
                        plugins: t = [],
                        fallbackToNetwork: s = !0
                    } = {}) {
                        this._urlsToCacheKeys = new Map, this._urlsToCacheModes = new Map, this._cacheKeysToIntegrities = new Map, this._strategy = new De({
                            cacheName: le(e),
                            plugins: [...t, new Re({
                                precacheController: this
                            })],
                            fallbackToNetwork: s
                        }), this.install = this.install.bind(this), this.activate = this.activate.bind(this)
                    }
                    get strategy() {
                        return this._strategy
                    }
                    precache(e) {
                        this.addToCacheList(e), this._installAndActiveListenersAdded || (self.addEventListener("install", this.install), self.addEventListener("activate", this.activate), this._installAndActiveListenersAdded = !0)
                    }
                    addToCacheList(e) {
                        const t = [];
                        for (const s of e) {
                            "string" == typeof s ? t.push(s) : s && void 0 === s.revision && t.push(s.url);
                            const {
                                cacheKey: e,
                                url: n
                            } = ve(s), r = "string" != typeof s && s.revision ? "reload" : "default";
                            if (this._urlsToCacheKeys.has(n) && this._urlsToCacheKeys.get(n) !== e) throw new ie("add-to-cache-list-conflicting-entries", {
                                firstEntry: this._urlsToCacheKeys.get(n),
                                secondEntry: e
                            });
                            if ("string" != typeof s && s.integrity) {
                                if (this._cacheKeysToIntegrities.has(e) && this._cacheKeysToIntegrities.get(e) !== s.integrity) throw new ie("add-to-cache-list-conflicting-integrities", {
                                    url: n
                                });
                                this._cacheKeysToIntegrities.set(e, s.integrity)
                            }
                            if (this._urlsToCacheKeys.set(n, e), this._urlsToCacheModes.set(n, r), t.length > 0) {
                                const e = `Workbox is precaching URLs without revision info: ${t.join(", ")}\nThis is generally NOT safe. Learn more at https://bit.ly/wb-precache`;
                                console.warn(e)
                            }
                        }
                    }
                    install(e) {
                        return _e(e, (async () => {
                            const t = new qe;
                            this.strategy.plugins.push(t);
                            for (const [r, a] of this._urlsToCacheKeys) {
                                const t = this._cacheKeysToIntegrities.get(a),
                                    s = this._urlsToCacheModes.get(r),
                                    n = new Request(r, {
                                        integrity: t,
                                        cache: s,
                                        credentials: "same-origin"
                                    });
                                await Promise.all(this.strategy.handleAll({
                                    params: {
                                        cacheKey: a
                                    },
                                    request: n,
                                    event: e
                                }))
                            }
                            const {
                                updatedURLs: s,
                                notUpdatedURLs: n
                            } = t;
                            return {
                                updatedURLs: s,
                                notUpdatedURLs: n
                            }
                        }))
                    }
                    activate(e) {
                        return _e(e, (async () => {
                            const e = await self.caches.open(this.strategy.cacheName),
                                t = await e.keys(),
                                s = new Set(this._urlsToCacheKeys.values()),
                                n = [];
                            for (const r of t) s.has(r.url) || (await e.delete(r), n.push(r.url));
                            return {
                                deletedURLs: n
                            }
                        }))
                    }
                    getURLsToCacheKeys() {
                        return this._urlsToCacheKeys
                    }
                    getCachedURLs() {
                        return [...this._urlsToCacheKeys.keys()]
                    }
                    getCacheKeyForURL(e) {
                        const t = new URL(e, location.href);
                        return this._urlsToCacheKeys.get(t.href)
                    }
                    getIntegrityForCacheKey(e) {
                        return this._cacheKeysToIntegrities.get(e)
                    }
                    async matchPrecache(e) {
                        const t = e instanceof Request ? e.url : e,
                            s = this.getCacheKeyForURL(t);
                        if (s) {
                            return (await self.caches.open(this.strategy.cacheName)).match(s)
                        }
                    }
                    createHandlerBoundToURL(e) {
                        const t = this.getCacheKeyForURL(e);
                        if (!t) throw new ie("non-precached-url", {
                            url: e
                        });
                        return s => (s.request = new Request(e), s.params = Object.assign({
                            cacheKey: t
                        }, s.params), this.strategy.handle(s))
                    }
                }
                let Se;
                const Te = () => (Se || (Se = new Ce), Se);
                s(80);
                const Ne = e => e && "object" == typeof e ? e : {
                    handle: e
                };
                class Le {
                    constructor(e, t, s = "GET") {
                        this.handler = Ne(t), this.match = e, this.method = s
                    }
                    setCatchHandler(e) {
                        this.catchHandler = Ne(e)
                    }
                }
                class Pe extends Le {
                    constructor(e, t, s) {
                        super((({
                            url: t
                        }) => {
                            const s = e.exec(t.href);
                            if (s && (t.origin === location.origin || 0 === s.index)) return s.slice(1)
                        }), t, s)
                    }
                }
                class Ie {
                    constructor() {
                        this._routes = new Map, this._defaultHandlerMap = new Map
                    }
                    get routes() {
                        return this._routes
                    }
                    addFetchListener() {
                        self.addEventListener("fetch", (e => {
                            const {
                                request: t
                            } = e, s = this.handleRequest({
                                request: t,
                                event: e
                            });
                            s && e.respondWith(s)
                        }))
                    }
                    addCacheListener() {
                        self.addEventListener("message", (e => {
                            if (e.data && "CACHE_URLS" === e.data.type) {
                                const {
                                    payload: t
                                } = e.data;
                                0;
                                const s = Promise.all(t.urlsToCache.map((t => {
                                    "string" == typeof t && (t = [t]);
                                    const s = new Request(...t);
                                    return this.handleRequest({
                                        request: s,
                                        event: e
                                    })
                                })));
                                e.waitUntil(s), e.ports && e.ports[0] && s.then((() => e.ports[0].postMessage(!0)))
                            }
                        }))
                    }
                    handleRequest({
                        request: e,
                        event: t
                    }) {
                        const s = new URL(e.url, location.href);
                        if (!s.protocol.startsWith("http")) return void 0;
                        const n = s.origin === location.origin,
                            {
                                params: r,
                                route: a
                            } = this.findMatchingRoute({
                                event: t,
                                request: e,
                                sameOrigin: n,
                                url: s
                            });
                        let i = a && a.handler;
                        const o = e.method;
                        if (!i && this._defaultHandlerMap.has(o) && (i = this._defaultHandlerMap.get(o)), !i) return void 0;
                        let c;
                        try {
                            c = i.handle({
                                url: s,
                                request: e,
                                event: t,
                                params: r
                            })
                        } catch (u) {
                            c = Promise.reject(u)
                        }
                        const h = a && a.catchHandler;
                        return c instanceof Promise && (this._catchHandler || h) && (c = c.catch((async n => {
                            if (h) {
                                0;
                                try {
                                    return await h.handle({
                                        url: s,
                                        request: e,
                                        event: t,
                                        params: r
                                    })
                                } catch (a) {
                                    a instanceof Error && (n = a)
                                }
                            }
                            if (this._catchHandler) return this._catchHandler.handle({
                                url: s,
                                request: e,
                                event: t
                            });
                            throw n
                        }))), c
                    }
                    findMatchingRoute({
                        url: e,
                        sameOrigin: t,
                        request: s,
                        event: n
                    }) {
                        const r = this._routes.get(s.method) || [];
                        for (const a of r) {
                            let r;
                            const i = a.match({
                                url: e,
                                sameOrigin: t,
                                request: s,
                                event: n
                            });
                            if (i) return r = i, (Array.isArray(r) && 0 === r.length || i.constructor === Object && 0 === Object.keys(i).length || "boolean" == typeof i) && (r = void 0), {
                                route: a,
                                params: r
                            }
                        }
                        return {}
                    }
                    setDefaultHandler(e, t = "GET") {
                        this._defaultHandlerMap.set(t, Ne(e))
                    }
                    setCatchHandler(e) {
                        this._catchHandler = Ne(e)
                    }
                    registerRoute(e) {
                        this._routes.has(e.method) || this._routes.set(e.method, []), this._routes.get(e.method).push(e)
                    }
                    unregisterRoute(e) {
                        if (!this._routes.has(e.method)) throw new ie("unregister-route-but-not-found-with-method", {
                            method: e.method
                        });
                        const t = this._routes.get(e.method).indexOf(e);
                        if (!(t > -1)) throw new ie("unregister-route-route-not-registered");
                        this._routes.get(e.method).splice(t, 1)
                    }
                }
                let Ue;
                const Oe = () => (Ue || (Ue = new Ie, Ue.addFetchListener(), Ue.addCacheListener()), Ue);

                function Me(e, t, s) {
                    let n;
                    if ("string" == typeof e) {
                        const r = new URL(e, location.href);
                        0;
                        n = new Le((({
                            url: e
                        }) => e.href === r.href), t, s)
                    } else if (e instanceof RegExp) n = new Pe(e, t, s);
                    else if ("function" == typeof e) n = new Le(e, t, s);
                    else {
                        if (!(e instanceof Le)) throw new ie("unsupported-route-type", {
                            moduleName: "workbox-routing",
                            funcName: "registerRoute",
                            paramName: "capture"
                        });
                        n = e
                    }
                    return Oe().registerRoute(n), n
                }
                class Ae extends Le {
                    constructor(e, t) {
                        super((({
                            request: s
                        }) => {
                            const n = e.getURLsToCacheKeys();
                            for (const r of function*(e, {
                                    ignoreURLParametersMatching: t = [/^utm_/, /^fbclid$/],
                                    directoryIndex: s = "index.html",
                                    cleanURLs: n = !0,
                                    urlManipulation: r
                                } = {}) {
                                    const a = new URL(e, location.href);
                                    a.hash = "", yield a.href;
                                    const i = function(e, t = []) {
                                        for (const s of [...e.searchParams.keys()]) t.some((e => e.test(s))) && e.searchParams.delete(s);
                                        return e
                                    }(a, t);
                                    if (yield i.href, s && i.pathname.endsWith("/")) {
                                        const e = new URL(i.href);
                                        e.pathname += s, yield e.href
                                    }
                                    if (n) {
                                        const e = new URL(i.href);
                                        e.pathname += ".html", yield e.href
                                    }
                                    if (r) {
                                        const e = r({
                                            url: a
                                        });
                                        for (const t of e) yield t.href
                                    }
                                }(s.url, t)) {
                                const t = n.get(r);
                                if (t) {
                                    return {
                                        cacheKey: t,
                                        integrity: e.getIntegrityForCacheKey(t)
                                    }
                                }
                            }
                        }), e.strategy)
                    }
                }

                function Be(e, t) {
                    ! function(e) {
                        Te().precache(e)
                    }(e),
                    function(e) {
                        const t = Te();
                        Me(new Ae(t, e))
                    }(t)
                }
                s(895);
                class je {
                    constructor(e = {}) {
                        this._statuses = e.statuses, this._headers = e.headers
                    }
                    isResponseCacheable(e) {
                        let t = !0;
                        return this._statuses && (t = this._statuses.includes(e.status)), this._headers && t && (t = Object.keys(this._headers).some((t => e.headers.get(t) === this._headers[t]))), t
                    }
                }
                class Ke {
                    constructor(e) {
                        this.cacheWillUpdate = async ({
                            response: e
                        }) => this._cacheableResponse.isResponseCacheable(e) ? e : null, this._cacheableResponse = new je(e)
                    }
                }
                let We, Fe;
                const He = new WeakMap,
                    $e = new WeakMap,
                    Ve = new WeakMap,
                    Ge = new WeakMap,
                    Qe = new WeakMap;
                let ze = {
                    get(e, t, s) {
                        if (e instanceof IDBTransaction) {
                            if ("done" === t) return $e.get(e);
                            if ("objectStoreNames" === t) return e.objectStoreNames || Ve.get(e);
                            if ("store" === t) return s.objectStoreNames[1] ? void 0 : s.objectStore(s.objectStoreNames[0])
                        }
                        return Xe(e[t])
                    },
                    set: (e, t, s) => (e[t] = s, !0),
                    has: (e, t) => e instanceof IDBTransaction && ("done" === t || "store" === t) || t in e
                };

                function Je(e) {
                    return e !== IDBDatabase.prototype.transaction || "objectStoreNames" in IDBTransaction.prototype ? (Fe || (Fe = [IDBCursor.prototype.advance, IDBCursor.prototype.continue, IDBCursor.prototype.continuePrimaryKey])).includes(e) ? function(...t) {
                        return e.apply(Ye(this), t), Xe(He.get(this))
                    } : function(...t) {
                        return Xe(e.apply(Ye(this), t))
                    } : function(t, ...s) {
                        const n = e.call(Ye(this), t, ...s);
                        return Ve.set(n, t.sort ? t.sort() : [t]), Xe(n)
                    }
                }

                function Ze(e) {
                    return "function" == typeof e ? Je(e) : (e instanceof IDBTransaction && function(e) {
                        if ($e.has(e)) return;
                        const t = new Promise(((t, s) => {
                            const n = () => {
                                    e.removeEventListener("complete", r), e.removeEventListener("error", a), e.removeEventListener("abort", a)
                                },
                                r = () => {
                                    t(), n()
                                },
                                a = () => {
                                    s(e.error || new DOMException("AbortError", "AbortError")), n()
                                };
                            e.addEventListener("complete", r), e.addEventListener("error", a), e.addEventListener("abort", a)
                        }));
                        $e.set(e, t)
                    }(e), t = e, (We || (We = [IDBDatabase, IDBObjectStore, IDBIndex, IDBCursor, IDBTransaction])).some((e => t instanceof e)) ? new Proxy(e, ze) : e);
                    var t
                }

                function Xe(e) {
                    if (e instanceof IDBRequest) return function(e) {
                        const t = new Promise(((t, s) => {
                            const n = () => {
                                    e.removeEventListener("success", r), e.removeEventListener("error", a)
                                },
                                r = () => {
                                    t(Xe(e.result)), n()
                                },
                                a = () => {
                                    s(e.error), n()
                                };
                            e.addEventListener("success", r), e.addEventListener("error", a)
                        }));
                        return t.then((t => {
                            t instanceof IDBCursor && He.set(t, e)
                        })).catch((() => {})), Qe.set(t, e), t
                    }(e);
                    if (Ge.has(e)) return Ge.get(e);
                    const t = Ze(e);
                    return t !== e && (Ge.set(e, t), Qe.set(t, e)), t
                }
                const Ye = e => Qe.get(e);
                const et = ["get", "getKey", "getAll", "getAllKeys", "count"],
                    tt = ["put", "add", "delete", "clear"],
                    st = new Map;

                function nt(e, t) {
                    if (!(e instanceof IDBDatabase) || t in e || "string" != typeof t) return;
                    if (st.get(t)) return st.get(t);
                    const s = t.replace(/FromIndex$/, ""),
                        n = t !== s,
                        r = tt.includes(s);
                    if (!(s in (n ? IDBIndex : IDBObjectStore).prototype) || !r && !et.includes(s)) return;
                    const a = async function(e, ...t) {
                        const a = this.transaction(e, r ? "readwrite" : "readonly");
                        let i = a.store;
                        return n && (i = i.index(t.shift())), (await Promise.all([i[s](...t), r && a.done]))[0]
                    };
                    return st.set(t, a), a
                }! function(e) {
                    ze = e(ze)
                }((e => ({ ...e,
                    get: (t, s, n) => nt(t, s) || e.get(t, s, n),
                    has: (t, s) => !!nt(t, s) || e.has(t, s)
                })));
                s(550);
                const rt = "cache-entries",
                    at = e => {
                        const t = new URL(e, location.href);
                        return t.hash = "", t.href
                    };
                class it {
                    constructor(e) {
                        this._db = null, this._cacheName = e
                    }
                    _upgradeDb(e) {
                        const t = e.createObjectStore(rt, {
                            keyPath: "id"
                        });
                        t.createIndex("cacheName", "cacheName", {
                            unique: !1
                        }), t.createIndex("timestamp", "timestamp", {
                            unique: !1
                        })
                    }
                    _upgradeDbAndDeleteOldDbs(e) {
                        this._upgradeDb(e), this._cacheName && function(e, {
                            blocked: t
                        } = {}) {
                            const s = indexedDB.deleteDatabase(e);
                            t && s.addEventListener("blocked", (e => t(e.oldVersion, e))), Xe(s).then((() => {}))
                        }(this._cacheName)
                    }
                    async setTimestamp(e, t) {
                        const s = {
                                url: e = at(e),
                                timestamp: t,
                                cacheName: this._cacheName,
                                id: this._getId(e)
                            },
                            n = (await this.getDb()).transaction(rt, "readwrite", {
                                durability: "relaxed"
                            });
                        await n.store.put(s), await n.done
                    }
                    async getTimestamp(e) {
                        const t = await this.getDb(),
                            s = await t.get(rt, this._getId(e));
                        return null == s ? void 0 : s.timestamp
                    }
                    async expireEntries(e, t) {
                        const s = await this.getDb();
                        let n = await s.transaction(rt).store.index("timestamp").openCursor(null, "prev");
                        const r = [];
                        let a = 0;
                        for (; n;) {
                            const s = n.value;
                            s.cacheName === this._cacheName && (e && s.timestamp < e || t && a >= t ? r.push(n.value) : a++), n = await n.continue()
                        }
                        const i = [];
                        for (const o of r) await s.delete(rt, o.id), i.push(o.url);
                        return i
                    }
                    _getId(e) {
                        return this._cacheName + "|" + at(e)
                    }
                    async getDb() {
                        return this._db || (this._db = await
                            function(e, t, {
                                blocked: s,
                                upgrade: n,
                                blocking: r,
                                terminated: a
                            } = {}) {
                                const i = indexedDB.open(e, t),
                                    o = Xe(i);
                                return n && i.addEventListener("upgradeneeded", (e => {
                                    n(Xe(i.result), e.oldVersion, e.newVersion, Xe(i.transaction), e)
                                })), s && i.addEventListener("blocked", (e => s(e.oldVersion, e.newVersion, e))), o.then((e => {
                                    a && e.addEventListener("close", (() => a())), r && e.addEventListener("versionchange", (e => r(e.oldVersion, e.newVersion, e)))
                                })).catch((() => {})), o
                            }("workbox-expiration", 1, {
                                upgrade: this._upgradeDbAndDeleteOldDbs.bind(this)
                            })), this._db
                    }
                }
                class ot {
                    constructor(e, t = {}) {
                        this._isRunning = !1, this._rerunRequested = !1, this._maxEntries = t.maxEntries, this._maxAgeSeconds = t.maxAgeSeconds, this._matchOptions = t.matchOptions, this._cacheName = e, this._timestampModel = new it(e)
                    }
                    async expireEntries() {
                        if (this._isRunning) return void(this._rerunRequested = !0);
                        this._isRunning = !0;
                        const e = this._maxAgeSeconds ? Date.now() - 1e3 * this._maxAgeSeconds : 0,
                            t = await this._timestampModel.expireEntries(e, this._maxEntries),
                            s = await self.caches.open(this._cacheName);
                        for (const n of t) await s.delete(n, this._matchOptions);
                        this._isRunning = !1, this._rerunRequested && (this._rerunRequested = !1, me(this.expireEntries()))
                    }
                    async updateTimestamp(e) {
                        await this._timestampModel.setTimestamp(e, Date.now())
                    }
                    async isURLExpired(e) {
                        if (this._maxAgeSeconds) {
                            const t = await this._timestampModel.getTimestamp(e),
                                s = Date.now() - 1e3 * this._maxAgeSeconds;
                            return void 0 === t || t < s
                        }
                        return !1
                    }
                    async delete() {
                        this._rerunRequested = !1, await this._timestampModel.expireEntries(1 / 0)
                    }
                }
                class ct {
                    constructor(e = {}) {
                        this.cachedResponseWillBeUsed = async ({
                            event: e,
                            request: t,
                            cacheName: s,
                            cachedResponse: n
                        }) => {
                            if (!n) return null;
                            const r = this._isResponseDateFresh(n),
                                a = this._getCacheExpiration(s);
                            me(a.expireEntries());
                            const i = a.updateTimestamp(t.url);
                            if (e) try {
                                e.waitUntil(i)
                            } catch (o) {
                                0
                            }
                            return r ? n : null
                        }, this.cacheDidUpdate = async ({
                            cacheName: e,
                            request: t
                        }) => {
                            const s = this._getCacheExpiration(e);
                            await s.updateTimestamp(t.url), await s.expireEntries()
                        }, this._config = e, this._maxAgeSeconds = e.maxAgeSeconds, this._cacheExpirations = new Map, e.purgeOnQuotaError && function(e) {
                            oe.add(e)
                        }((() => this.deleteCacheAndMetadata()))
                    }
                    _getCacheExpiration(e) {
                        if (e === de()) throw new ie("expire-custom-caches-only");
                        let t = this._cacheExpirations.get(e);
                        return t || (t = new ot(e, this._config), this._cacheExpirations.set(e, t)), t
                    }
                    _isResponseDateFresh(e) {
                        if (!this._maxAgeSeconds) return !0;
                        const t = this._getDateHeaderTimestamp(e);
                        if (null === t) return !0;
                        return t >= Date.now() - 1e3 * this._maxAgeSeconds
                    }
                    _getDateHeaderTimestamp(e) {
                        if (!e.headers.has("date")) return null;
                        const t = e.headers.get("date"),
                            s = new Date(t).getTime();
                        return isNaN(s) ? null : s
                    }
                    async deleteCacheAndMetadata() {
                        for (const [e, t] of this._cacheExpirations) await self.caches.delete(e), await t.delete();
                        this._cacheExpirations = new Map
                    }
                }
                class ht extends ke {
                    async _handle(e, t) {
                        let s, n = await t.cacheMatch(e);
                        if (n) 0;
                        else {
                            0;
                            try {
                                n = await t.fetchAndCachePut(e)
                            } catch (r) {
                                r instanceof Error && (s = r)
                            }
                            0
                        }
                        if (!n) throw new ie("no-response", {
                            url: e.url,
                            error: s
                        });
                        return n
                    }
                }
                const ut = {
                    cacheWillUpdate: async ({
                        response: e
                    }) => 200 === e.status || 0 === e.status ? e : null
                };
                class lt extends ke {
                    constructor(e = {}) {
                        super(e), this.plugins.some((e => "cacheWillUpdate" in e)) || this.plugins.unshift(ut), this._networkTimeoutSeconds = e.networkTimeoutSeconds || 0
                    }
                    async _handle(e, t) {
                        const s = [];
                        const n = [];
                        let r;
                        if (this._networkTimeoutSeconds) {
                            const {
                                id: a,
                                promise: i
                            } = this._getTimeoutPromise({
                                request: e,
                                logs: s,
                                handler: t
                            });
                            r = a, n.push(i)
                        }
                        const a = this._getNetworkPromise({
                            timeoutId: r,
                            request: e,
                            logs: s,
                            handler: t
                        });
                        n.push(a);
                        const i = await t.waitUntil((async () => await t.waitUntil(Promise.race(n)) || await a)());
                        if (!i) throw new ie("no-response", {
                            url: e.url
                        });
                        return i
                    }
                    _getTimeoutPromise({
                        request: e,
                        logs: t,
                        handler: s
                    }) {
                        let n;
                        return {
                            promise: new Promise((t => {
                                n = setTimeout((async () => {
                                    t(await s.cacheMatch(e))
                                }), 1e3 * this._networkTimeoutSeconds)
                            })),
                            id: n
                        }
                    }
                    async _getNetworkPromise({
                        timeoutId: e,
                        request: t,
                        logs: s,
                        handler: n
                    }) {
                        let r, a;
                        try {
                            a = await n.fetchAndCachePut(t)
                        } catch (i) {
                            i instanceof Error && (r = i)
                        }
                        return e && clearTimeout(e), !r && a || (a = await n.cacheMatch(t)), a
                    }
                }
                class dt extends ke {
                    constructor(e = {}) {
                        super(e), this._networkTimeoutSeconds = e.networkTimeoutSeconds || 0
                    }
                    async _handle(e, t) {
                        let s, n;
                        try {
                            const s = [t.fetch(e)];
                            if (this._networkTimeoutSeconds) {
                                const e = ye(1e3 * this._networkTimeoutSeconds);
                                s.push(e)
                            }
                            if (n = await Promise.race(s), !n) throw new Error(`Timed out the network response after ${this._networkTimeoutSeconds} seconds.`)
                        } catch (r) {
                            r instanceof Error && (s = r)
                        }
                        if (!n) throw new ie("no-response", {
                            url: e.url,
                            error: s
                        });
                        return n
                    }
                }
                class ft extends ke {
                    constructor(e = {}) {
                        super(e), this.plugins.some((e => "cacheWillUpdate" in e)) || this.plugins.unshift(ut)
                    }
                    async _handle(e, t) {
                        const s = t.fetchAndCachePut(e).catch((() => {}));
                        t.waitUntil(s);
                        let n, r = await t.cacheMatch(e);
                        if (r) 0;
                        else {
                            0;
                            try {
                                r = await s
                            } catch (a) {
                                a instanceof Error && (n = a)
                            }
                        }
                        if (!r) throw new ie("no-response", {
                            url: e.url,
                            error: n
                        });
                        return r
                    }
                }
                var pt = function(e, t, s, n) {
                        return new(s || (s = Promise))((function(r, a) {
                            function i(e) {
                                try {
                                    c(n.next(e))
                                } catch (t) {
                                    a(t)
                                }
                            }

                            function o(e) {
                                try {
                                    c(n.throw(e))
                                } catch (t) {
                                    a(t)
                                }
                            }

                            function c(e) {
                                var t;
                                e.done ? r(e.value) : (t = e.value, t instanceof s ? t : new s((function(e) {
                                    e(t)
                                }))).then(i, o)
                            }
                            c((n = n.apply(e, t || [])).next())
                        }))
                    },
                    mt = function(e, t) {
                        var s, n, r, a, i = {
                            label: 0,
                            sent: function() {
                                if (1 & r[0]) throw r[1];
                                return r[1]
                            },
                            trys: [],
                            ops: []
                        };
                        return a = {
                            next: o(0),
                            throw: o(1),
                            return: o(2)
                        }, "function" == typeof Symbol && (a[Symbol.iterator] = function() {
                            return this
                        }), a;

                        function o(o) {
                            return function(c) {
                                return function(o) {
                                    if (s) throw new TypeError("Generator is already executing.");
                                    for (; a && (a = 0, o[0] && (i = 0)), i;) try {
                                        if (s = 1, n && (r = 2 & o[0] ? n.return : o[0] ? n.throw || ((r = n.return) && r.call(n), 0) : n.next) && !(r = r.call(n, o[1])).done) return r;
                                        switch (n = 0, r && (o = [2 & o[0], r.value]), o[0]) {
                                            case 0:
                                            case 1:
                                                r = o;
                                                break;
                                            case 4:
                                                return i.label++, {
                                                    value: o[1],
                                                    done: !1
                                                };
                                            case 5:
                                                i.label++, n = o[1], o = [0];
                                                continue;
                                            case 7:
                                                o = i.ops.pop(), i.trys.pop();
                                                continue;
                                            default:
                                                if (!(r = i.trys, (r = r.length > 0 && r[r.length - 1]) || 6 !== o[0] && 2 !== o[0])) {
                                                    i = 0;
                                                    continue
                                                }
                                                if (3 === o[0] && (!r || o[1] > r[0] && o[1] < r[3])) {
                                                    i.label = o[1];
                                                    break
                                                }
                                                if (6 === o[0] && i.label < r[1]) {
                                                    i.label = r[1], r = o;
                                                    break
                                                }
                                                if (r && i.label < r[2]) {
                                                    i.label = r[2], i.ops.push(o);
                                                    break
                                                }
                                                r[2] && i.ops.pop(), i.trys.pop();
                                                continue
                                        }
                                        o = t.call(e, i)
                                    } catch (c) {
                                        o = [6, c], n = 0
                                    } finally {
                                        s = r = 0
                                    }
                                    if (5 & o[0]) throw o[1];
                                    return {
                                        value: o[0] ? o[1] : void 0,
                                        done: !0
                                    }
                                }([o, c])
                            }
                        }
                    };

                function wt(e, t) {
                    var s = this;
                    self.skipWaiting(), self.addEventListener("activate", (() => self.clients.claim()));
                    var n, r = "".concat("https://www.mi.com", "/").concat(e, "/manifest.json?xm-v=").concat("0.45.8"),
                        a = "".concat("https://www.mi.com", "/").concat(e, "/offline.html?xm-v=").concat("0.45.8");
                    self.addEventListener("activate", (function(e) {
                            e.waitUntil(caches.open("web-runtime").then((function(e) {
                                return pt(s, void 0, void 0, (function() {
                                    var t, s;
                                    return mt(this, (function(n) {
                                        switch (n.label) {
                                            case 0:
                                                return [4, e.keys()];
                                            case 1:
                                                return t = n.sent(), s = t.filter((function(e) {
                                                    return !e.url.includes("/".concat("0.45.8", "/"))
                                                })), [2, Promise.all(s.map((function(t) {
                                                    return e.delete(t)
                                                })))]
                                        }
                                    }))
                                }))
                            })))
                        })), ue({
                            prefix: "web",
                            suffix: "",
                            precache: "precache",
                            runtime: "runtime"
                        }), ((e = {}) => {
                            const t = I(e.cacheName),
                                s = new N("workbox-google-analytics", {
                                    maxRetentionTime: 2880,
                                    onSync: (n = e, async ({
                                        queue: e
                                    }) => {
                                        let t;
                                        for (; t = await e.shiftRequest();) {
                                            const {
                                                request: r,
                                                timestamp: a
                                            } = t, i = new URL(r.url);
                                            try {
                                                const e = "POST" === r.method ? new URLSearchParams(await r.clone().text()) : i.searchParams,
                                                    t = a - (Number(e.get("qt")) || 0),
                                                    s = Date.now() - t;
                                                if (e.set("qt", String(s)), n.parameterOverrides)
                                                    for (const r of Object.keys(n.parameterOverrides)) {
                                                        const t = n.parameterOverrides[r];
                                                        e.set(r, t)
                                                    }
                                                "function" == typeof n.hitFilter && n.hitFilter.call(null, e), await fetch(new Request(i.origin + i.pathname, {
                                                    body: e.toString(),
                                                    method: "POST",
                                                    mode: "cors",
                                                    credentials: "omit",
                                                    headers: {
                                                        "Content-Type": "text/plain"
                                                    }
                                                }))
                                            } catch (s) {
                                                throw await e.unshiftRequest(t), s
                                            }
                                        }
                                    })
                                });
                            var n;
                            const r = [re(t), se(t), ne(t), ...te(s)],
                                a = new K;
                            for (const i of r) a.registerRoute(i);
                            a.addFetchListener()
                        })({
                            cacheName: "google-analytics"
                        }), Be(([{
                            'revision': null,
                            'url': 'https://s05.appmifile.com/sgp/spps_files/store/0.45.8/css/global/index.css'
                        }, {
                            'revision': null,
                            'url': 'https://s05.appmifile.com/sgp/spps_files/store/0.45.8/js/global/index.js'
                        }, {
                            'revision': null,
                            'url': 'https://s05.appmifile.com/sgp/spps_files/store/0.45.8/js/global/runtime.js'
                        }, {
                            'revision': null,
                            'url': 'https://s05.appmifile.com/sgp/spps_files/store/0.45.8/js/react.js'
                        }, {
                            'revision': null,
                            'url': 'https://s05.appmifile.com/sgp/spps_files/store/0.45.8/js/vendor.js'
                        }] || []).concat([{
                            url: "".concat(a),
                            revision: null
                        }, {
                            url: "".concat(r),
                            revision: null
                        }]), {
                            ignoreURLParametersMatching: [/.*/],
                            cleanURLs: !1
                        }), n = new dt, Oe().setDefaultHandler(n),
                        function(e) {
                            Oe().setCatchHandler(e)
                        }((function(e) {
                            return pt(s, void 0, void 0, (function() {
                                var t, s;
                                return mt(this, (function(n) {
                                    switch (n.label) {
                                        case 0:
                                            return t = e.request.destination, [4, self.caches.open("web-precache")];
                                        case 1:
                                            return s = n.sent(), "document" !== t ? [3, 3] : [4, s.match(a)];
                                        case 2:
                                            return [2, n.sent() || Response.error()];
                                        case 3:
                                            return [2, Response.error()]
                                    }
                                }))
                            }))
                        })), Me((function(e) {
                            var t = e.request,
                                s = e.url,
                                n = ["/product/", "/errors/", "/buy/", "/crowd-buying/", "/discover/"].some((function(e) {
                                    return s.pathname.includes(e)
                                }));
                            return "navigate" === t.mode && !n
                        }), new lt({
                            networkTimeoutSeconds: 5,
                            cacheName: "web-pages",
                            plugins: [new Ke({
                                statuses: [0, 200]
                            })]
                        })), Me((function(e) {
                            var t = e.request,
                                s = e.url,
                                n = "https://fonts.googleapis.com" === s.origin,
                                r = "style" === t.destination && (s.pathname || "").includes("/i18n/fonts/"),
                                a = "style" === t.destination && (s.pathname || "").includes("/i18n/micon/");
                            return n || r || a
                        }), new ft({
                            cacheName: "web-fonts-stylesheets",
                            plugins: [new Ke({
                                statuses: [0, 200]
                            })]
                        })), Me((function(e) {
                            var t = e.request,
                                s = e.url;
                            return "https://fonts.gstatic.com" === s.origin || "font" === t.destination && (s.pathname || "").includes("/i18n/fonts/")
                        }), new ht({
                            cacheName: "web-fonts-webfonts",
                            plugins: [new Ke({
                                statuses: [0, 200]
                            }), new ct({
                                maxAgeSeconds: 31536e3
                            })]
                        })), Me((function(e) {
                            var t = e.request,
                                s = e.url,
                                n = "script" === t.destination && ["www.dwin1.com", "www.googleadservices.com", "connect.facebook.net", "cdn.polyfill.io", "consent.trustarc.com", "ssl-cdn.static.browser.mi-img.com"].includes(s.hostname || ""),
                                r = "image" !== t.destination && (s.hostname || "").includes("appmifile.com");
                            return n || r
                        }), new ht({
                            cacheName: "web-resources",
                            plugins: [new Ke({
                                statuses: [0, 200]
                            }), new ct({
                                maxAgeSeconds: 7776e3,
                                maxEntries: 20
                            })]
                        })), Me((function(e) {
                            var t = e.request,
                                s = e.url.hostname || "",
                                n = s.includes("appmifile.com"),
                                r = s.includes("fds.api.mi-img.com");
                            return "image" === t.destination && (n || r)
                        }), new ht({
                            cacheName: "web-images",
                            plugins: [new Ke({
                                statuses: [0, 200]
                            }), new ct({
                                maxAgeSeconds: 604800,
                                maxEntries: 100
                            })]
                        })), Me((function(e) {
                            var t = e.request,
                                s = e.url;
                            return ["style", "script"].includes(t.destination) && (s.pathname || "").includes("chunk")
                        }), new ft({
                            cacheName: "web-runtime",
                            plugins: [new Ke({
                                statuses: [0, 200]
                            })]
                        })), Me((function(e) {
                            var s = e.url;
                            return t.some((function(e) {
                                return s.href.includes(e)
                            })) && "1" === s.searchParams.get("cacheable")
                        }), new lt({
                            cacheName: "web-api-data",
                            plugins: [new Ke({
                                statuses: [0, 200]
                            }), new ct({
                                maxEntries: 100,
                                maxAgeSeconds: 259200
                            })]
                        }), "GET"), Me((function(e) {
                            return e.url.pathname.includes("cwms-translate-language")
                        }), new ft({
                            cacheName: "web-translation",
                            plugins: [new Ke({
                                statuses: [0, 200]
                            }), new ct({
                                maxAgeSeconds: 2592e3
                            })]
                        }))
                }
            },
            272: () => {
                try {
                    self["workbox:background-sync:6.4.1"] && _()
                } catch (e) {}
            },
            747: () => {
                try {
                    self["workbox:core:6.4.1"] && _()
                } catch (e) {}
            },
            895: () => {
                try {
                    self["workbox:cacheable-response:7.0.0"] && _()
                } catch (e) {}
            },
            913: () => {
                try {
                    self["workbox:core:7.0.0"] && _()
                } catch (e) {}
            },
            550: () => {
                try {
                    self["workbox:expiration:7.0.0"] && _()
                } catch (e) {}
            },
            612: () => {
                try {
                    self["workbox:google-analytics:6.4.1"] && _()
                } catch (e) {}
            },
            988: () => {
                try {
                    self["workbox:core:6.4.1"] && _()
                } catch (e) {}
            },
            931: () => {
                try {
                    self["workbox:routing:6.4.1"] && _()
                } catch (e) {}
            },
            691: () => {
                try {
                    self["workbox:strategies:6.4.1"] && _()
                } catch (e) {}
            },
            977: () => {
                try {
                    self["workbox:precaching:7.0.0"] && _()
                } catch (e) {}
            },
            80: () => {
                try {
                    self["workbox:routing:7.0.0"] && _()
                } catch (e) {}
            },
            873: () => {
                try {
                    self["workbox:strategies:7.0.0"] && _()
                } catch (e) {}
            }
        },
        s = {};

    function n(e) {
        var r = s[e];
        if (void 0 !== r) return r.exports;
        var a = s[e] = {
            exports: {}
        };
        return t[e](a, a.exports, n), a.exports
    }
    n.d = (e, t) => {
        for (var s in t) n.o(t, s) && !n.o(e, s) && Object.defineProperty(e, s, {
            enumerable: !0,
            get: t[s]
        })
    }, n.o = (e, t) => Object.prototype.hasOwnProperty.call(e, t), e = ["//sgp-api.buy.mi.com/global", "//go.buy.mi.com/global", "//d2s.buy.mi.com/global"], n(135).Z("global", e)
})();