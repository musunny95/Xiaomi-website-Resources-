! function(n, t) {
    var e = n.document,
        r = n.location,
        i = n.navigator,
        o = n.console,
        a = n.parseInt,
        c = n.setTimeout,
        u = n.encodeURIComponent,
        s = n.decodeURIComponent,
        f = n.localStorage,
        p = n.sessionStorage,
        l = n.String,
        g = n.Array,
        v = n.Object,
        d = n.Date,
        h = n.Function,
        _ = n.Math,
        m = n.JSON,
        k = n.Image,
        w = n.XMLHttpRequest,
        y = n.FormData,
        I = n.unescape,
        b = n.Promise,
        C = n.CompressionStream,
        S = n.Response,
        T = n.Blob;

    function x() {
        return "prerender" == e.visibilityState
    }
    var P, U = {}.hasOwnProperty;

    function B(n, t) {
        var e;
        for (e in n) U.call(n, e) && t(e, n[e])
    }

    function O(n) {
        return "object" == typeof n && null !== n && n.constructor === v
    }

    function A(n, e) {
        return B(e, (function(e, r) {
            r !== t && (n[e] = r)
        })), n
    }

    function L(n, e) {
        return B(e, (function(e, r) {
            n[e] === t && (n[e] = r)
        })), n
    }

    function H(n) {
        n = n || {};
        var t, r, i, o, a = {},
            c = e.cookie.split("; ");
        for (t = 0; t < c.length; t++) c[t] && (i = (r = c[t].split("=")).shift(), '"' == (o = r.join("="))[0] && (o = o.slice(1, -1)), a[s(i)] = n.raw ? o : s(o));
        return a
    }

    function z(n, t, r) {
        var i = u(n) + "=" + u(t);
        return (r = A({
            path: "/"
        }, r)).expires && (r.expires = r.expires.toUTCString()), B(r, (function(n) {
            var t = r[n];
            t && (i += "; " + n, !0 !== t && (i += "=" + t))
        })), e.cookie = i, e.cookie
    }

    function j(n) {
        return f ? f.getItem(n) : H()[n]
    }

    function R(n, t) {
        f ? f.setItem(n, t) : z(n, t, {
            expire: new d(+new d + 31536e7)
        })
    }

    function M(n) {
        f ? f.removeItem(n) : function(n, t) {
            z(n, "", t = A({
                expires: new d(d.now() - 1)
            }, t))
        }(n)
    }

    function q(n) {
        return p ? p.getItem(n) : H()[n]
    }

    function D(n, t) {
        p ? p.setItem(n, t) : z(n, t)
    }

    function E(n, t) {
        n = n.charCodeAt(0), t = t.charCodeAt(0);
        for (var e = "", r = n; r <= t; r++) e += l.fromCharCode(r);
        return e
    }

    function F() {
        return P || (P = E("0", "9") + E("a", "z")),
            function(n, t) {
                for (var e = "", r = 0; r < 32; r++) e += n[_.floor(_.random() * n.length)];
                return e
            }(P)
    }

    function J(n) {
        var e = {};
        return B(n, (function(n, r) {
            e[n] = function(n, e) {
                if (e instanceof h) try {
                    return e(n)
                } catch (r) {
                    return t
                }
                return e
            }(n, r)
        })), e
    }
    var G, N = "_onetrack_cid",
        X = "_onetrack_uid",
        K = "_onetrack_uid_type",
        Q = [3e3, 1e4, 3e4],
        V = {
            cn: "tracking.miui.com",
            "in": "tracking.india.miui.com",
            ru: "tracking.rus.miui.com",
            auto: "auto.tracking.miui.com",
            _: "tracking.intl.miui.com"
        };

    function W(n) {
        var t = "string" == typeof n,
            e = G || (G = function() {
                for (var n = [], t = 0; t < 256; t++) {
                    for (var e = t, r = 0; r < 8; r++) e = 1 & e ? 3988292384 ^ e >>> 1 : e >>> 1;
                    n[t] = e
                }
                return n
            }()),
            r = -1;
        t && (n = I(u(n)));
        for (var i = 0; i < n.length; i++) r = r >>> 8 ^ e[255 & (r ^ (t ? n.charCodeAt(i) : n[i]))];
        return ((-1 ^ r) >>> 0).toString(16)
    }

    function Y(n) {
        var t = n.url,
            e = n.fail,
            r = n.data,
            o = n.success;
        "beacon" == n.transport && i.sendBeacon ? i.sendBeacon(t, r) ? o() : e() : function(n, t) {
            var e = new w,
                r = t.data,
                i = t.fail,
                o = t.success;
            e.open(t.method, n, !0), e.onreadystatechange = function() {
                if (4 === e.readyState) {
                    var n = {};
                    if (200 == e.status) try {
                        n = m.parse(e.responseText)
                    } catch (t) {}
                    0 === n.code ? o() : i()
                }
            }, e.send(r)
        }(t, A(n, {
            data: r
        }))
    }

    function Z(n, e) {
        var r = new k,
            i = {
                _: 0 + _.floor(1000000001 * _.random())
            };
        B((e = e || {}).H, (function(n, t) {
            i["H." + n] = t
        })), B(e.B, (function(n, t) {
            i["B." + n] = t
        })), i = function(n, e) {
            var r, i = "";
            return B(n, (function(n, e) {
                if (e != t)
                    if (e instanceof g)
                        for (r = 0; r < e.length; r++) i += "&" + u(n) + "=" + u(e[r]);
                    else i += "&" + u(n) + "=" + u(e)
            })), i.substr(1)
        }(i), r.src = n + "?" + i + "&sign=" + W(i)
    }
    var $ = [].push;

    function nn(e, r) {
        var i, a = [];

        function u() {
            a.length && s(a.splice(0, 20), u)
        }

        function s(t, e, i) {
            var o = r.transport,
                u = r.serverUrl,
                f = r.serverImgUrl;
            if ("native" == o) try {
                if (n.OneTrack_APP_H5_Bridge.track(m.stringify(t))) return void e()
            } catch (p) {}
            u && function(n) {
                var t = n.data,
                    e = n.imgUrl,
                    r = n.success;
                if (b) {
                    var i = m.stringify(t),
                        o = new y;
                    (function(n) {
                        var t = "function" == typeof C;
                        return new b((function(e, r) {
                            return t ? new S(new T([n]).stream().pipeThrough(new C("gzip"))).arrayBuffer().then((function(n) {
                                e(n)
                            })) : r()
                        }))
                    })(i).then((function(t) {
                        o.append("p", new T([t]), "p"), o.append("gzip", 1), o.append("sign", W(new Uint8Array(t))), Y(A(n, {
                            data: o
                        }))
                    }), (function() {
                        o.append("p", new T([i]), "p"), o.append("sign", W(i)), Y(A(n, {
                            data: o
                        }))
                    }))
                } else if (y) {
                    var a = m.stringify(t),
                        c = new y;
                    c.append("p", new T([a]), "p"), c.append("sign", W(a)), Y(A(n, {
                        data: c
                    }))
                } else {
                    for (var u = 0; u < t.length; u++) Z(e, t[u]);
                    r()
                }
            }({
                transport: o,
                url: u,
                imgUrl: f,
                method: "POST",
                data: t,
                success: e,
                fail: function() {
                    ! function(n, t, e) {
                        var r = Q[Q.indexOf(e) + 1];
                        r ? c((function() {
                            s(n, t, r)
                        }), r) : $.apply(a, n)
                    }(t, e, i)
                }
            })
        }
        return function(n) {
            var r;
            a.push(n), i == t && (i = c((function() {
                i = t, u()
            }))), r = "_onetrack_debug", (f ? null !== f.getItem(r) : H()[r]) && o.log("onetrack" + e, n)
        }
    }
    var tn = {},
        en = 0;

    function rn(o) {
        if (tn[o]) return tn[o];
        var c, u, s, f = o ? "__" + o : "",
            p = {},
            l = {},
            g = [],
            v = !1,
            h = !1,
            m = {
                send: !1,
                transport: "beacon"
            };

        function k() {
            if (v && h) {
                var n, e;
                A(p, {
                    instance_id: (i = j(N), i || (en = 1, i = F(), R(N, i)), i),
                    session_id: S(f),
                    uid: function() {
                        return j("" + X + f) || t
                    },
                    uid_type: function() {
                        return j("" + K + f) || t
                    },
                    sdk_ver: "1.0.0",
                    e_ts: function() {
                        return +new d
                    },
                    tz: (n = (new d).getTimezoneOffset(), e = _.abs(n), "GMT" + (n > 0 ? "-" : "+") + ("00" + _.floor(e / 60)).slice(-2) + ":" + ("00" + e % 60).slice(-2)),
                    ot_test_env: j("_onetrack_test" + f) ? 1 : t
                }), A(p, c), A(l, {
                    first_open: en
                }), A(l, u), s = nn(f, m);
                for (var r = 0; r < g.length; r++) try {
                    g[r][0].apply(t, g[r][1])
                } catch (o) {}
                g.length = 0
            }
            var i
        }
        var w = !1;

        function y() {
            var n, t;
            w = !0, v = !0, k(), n = {
                platform: "JS"
            }, t = {
                referrer: e.referrer,
                location: function() {
                    return r.href
                },
                page: function() {
                    return r.pathname
                },
                title: function() {
                    return e.title
                },
                encoding: e.characterSet || e.charset,
                language: (i.language || i.browserLanguage || "").toLowerCase(),
                screen_width: screen && screen.width,
                screen_height: screen && screen.height
            }, c = n, u = t, h = !0, k()
        }

        function I(n) {
            return function() {
                try {
                    var e = arguments;
                    w || y(), v && h ? n.apply(t, e) : g.push([n, e])
                } catch (r) {}
            }
        }
        var b = 18e5;

        function C(n, t) {
            if (n && p.app_id) {
                O(t) || (t = {});
                var e = {
                    event: n
                };
                L(e, p), L(t, l), s({
                    H: J(e),
                    B: J(t)
                })
            }
        }

        function S(n) {
            return function() {
                var t = +new d,
                    e = q("_onetrack_sid" + n),
                    r = a(q("_onetrack_st" + n), 10);
                return (!e || !r || r < t - b) && (e = F(), D("_onetrack_sid" + n, e)), D("_onetrack_st" + n, t), e
            }
        }

        function T(n, e, r) {
            n != t ? R("" + X + r, n) : M("" + X + r), e != t ? R("" + K + r, e) : M("" + K + r)
        }
        return tn[o] = {
            init: I((function(e, r, i, o, a) {
                var c, u, s;
                O(r) && (i = r.region, o = r.instanceId, a = r.transport, r.sessionTimeout && (b = r.sessionTimeout), r = r.channel), O(o) && (o = "cookie" == o.type && o.name ? (c = o.name, u = o.options, (s = H()[c]) || z(c, s = F(), A({
                    expires: new d(+new d + 31536e7)
                }, u)), s) : t), "xhr" == a && (m.transport = "xhr"), "native" == a && n.OneTrack_APP_H5_Bridge && (m.transport = "native"), A(p, {
                    app_id: e,
                    channel: r || "default",
                    instance_id: o || t,
                    region: i
                }), A(m, function(n) {
                    var t = V.cn;
                    n && n.toLowerCase && (n = n.toLowerCase(), t = V[n] || V._);
                    var e = "https://" + t + "/track/v4/js";
                    return {
                        serverImgUrl: e,
                        serverUrl: e + "_a"
                    }
                }(i)), C("onetrack_dau")
            })),
            set: I((function(n, t) {
                O(n) ? A(l, n) : l[n] = t
            })),
            track: I(C),
            trackPage: I((function(n) {
                C("view", n)
            })),
            login: I((function(n, t, e, r) {
                T(n, t, f), r || C("ot_login", e)
            })),
            logout: I((function(n) {
                C("ot_logout", n), T(t, t, f)
            }))
        }
    }

    function on(n) {
        return function() {
            try {
                rn("")[n].apply(t, arguments)
            } catch (e) {}
        }
    }
    var an, cn = {
            getInstance: rn,
            init: on("init"),
            set: on("set"),
            track: on("track"),
            trackPage: on("trackPage"),
            login: on("login"),
            logout: on("logout")
        },
        un = [].slice;

    function sn(n) {
        try {
            var e = un.call(arguments, 1),
                r = "",
                i = n.split(".");
            2 == i.length && (r = i[0], n = i[1]), cn.getInstance(r)[n].apply(t, e)
        } catch (o) {}
    }
    an = function() {
        var e, r = n.onetrack;
        if (r && r.length || (n.onetrack = sn), (r = r && r.q) instanceof g)
            for (e = 0; e < r.length; e++) sn.apply(t, r[e])
    }, x() ? e.addEventListener("visibilitychange", (function fn() {
        x() || (e.removeEventListener("visibilitychange", fn), an())
    })) : an()
}(window);