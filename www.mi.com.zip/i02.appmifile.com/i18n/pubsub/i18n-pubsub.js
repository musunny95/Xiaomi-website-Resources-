! function(t, e) {
    var n = t.document,
        i = t.console,
        o = t.setTimeout,
        r = t.encodeURIComponent,
        a = t.decodeURIComponent,
        s = t.localStorage,
        c = t.sessionStorage,
        u = t.String,
        p = t.Array,
        f = t.Object,
        l = t.Date,
        g = t.JSON,
        d = t.XMLHttpRequest,
        v = t.FormData,
        y = t.btoa,
        m = t.unescape,
        b = t.Promise,
        h = t.CompressionStream,
        w = t.Response,
        k = t.Blob;

    function _() {
        return "prerender" === n.visibilityState
    }
    var T, j = {
        _: "https://sdkconfig.ad.intl.xiaomi.com",
        "in": "https://sdkconfig.ad.india.xiaomi.com",
        test: "http://onetrack-sdkconfig-staging-cl41763.alisgp.ingress.mice.cc.d.xiaomi.net"
    };

    function x(t, e) {
        var n, i = f.prototype.hasOwnProperty;
        for (n in t) i.call(t, n) && e(n, t[n])
    }

    function C(t) {
        return "object" == typeof t && null !== t && t.constructor === f
    }

    function S(t, n, i) {
        return x(n, (function(n, o) {
            i && C(o) ? (C(t[n]) || (t[n] = {}), S(t[n], o, i)) : i && o instanceof p ? (t[n] instanceof p || (t[n] = []), S(t[n], o, i)) : o !== e && (t[n] = o)
        })), t
    }

    function I(t) {
        var e = "string" == typeof t,
            n = T || (T = function() {
                for (var t = [], e = 0; e < 256; e++) {
                    for (var n = e, i = 0; i < 8; i++) n = 1 & n ? 3988292384 ^ n >>> 1 : n >>> 1;
                    t[e] = n
                }
                return t
            }()),
            i = -1;
        e && (t = m(r(t)));
        for (var o = 0; o < t.length; o++) i = i >>> 8 ^ n[255 & (i ^ (e ? t.charCodeAt(o) : t[o]))];
        return ((-1 ^ i) >>> 0).toString(16)
    }
    var z = [].slice;

    function A(t) {
        return t = "string" == typeof t ? m(r(t)) : z.apply(t).map((function(t) {
            return u.fromCharCode(t)
        })).join(""), y(t)
    }

    function R(t) {
        var e = t.data,
            n = t.fail,
            i = t.success,
            o = t.url,
            r = t.token,
            a = t.removeToken,
            s = new d;
        s.open("POST", o, !0);
        var c = new k([g.stringify(e)], {
            type: "application/json"
        });
        s.setRequestHeader("Authorization", r), s.setRequestHeader("Content-Type", "application/json"), s.onreadystatechange = function() {
            if (4 === s.readyState)
                if (200 === s.status) i();
                else {
                    try {
                        "UNAUTHENTICATED" === g.parse(s.responseText).error.status && a()
                    } catch (t) {
                        a()
                    }
                    n()
                }
        }, s.send(c)
    }

    function U(t) {
        t = t || {};
        var e, i, o, r, s = {},
            c = n.cookie.split("; ");
        for (e = 0; e < c.length; e++) c[e] && (o = (i = c[e].split("=")).shift(), '"' === (r = i.join("="))[0] && (r = r.slice(1, -1)), s[a(o)] = t.raw ? r : a(r));
        return s
    }

    function q(t, e, i) {
        var o = r(t) + "=" + r(e);
        return (i = S({
            path: "/"
        }, i)).expires && (i.expires = i.expires.toUTCString()), x(i, (function(t) {
            var e = i[t];
            e && (o += "; " + t, !0 !== e && (o += "=" + e))
        })), n.cookie = o, n.cookie
    }

    function E(t) {
        var e;
        try {
            e = g.parse(function(t) {
                return s ? s.getItem(t) : U()[t]
            }(t) || "[]")
        } catch (n) {
            e = []
        }
        return e
    }

    function L(t, e) {
        ! function(t, e) {
            s ? s.setItem(t, e) : q(t, e, {
                expire: new l(+new l + 31536e7)
            })
        }(t, g.stringify(e || []))
    }
    var O = [3e3, 1e4, 3e4],
        H = {};
    t.iim = H;

    function B(t) {
        return function() {
            try {
                var n = arguments;
                t.apply(e, n)
            } catch (i) {}
        }
    }
    var D, K = {
        init: B((function(t, n, r, a, u) {
            "object" == typeof n && (r = n.privateKey, a = n.project, u = n.topic, t = n.key, n = n.region), n && r && a && u && function(t) {
                var n = t.key;
                void 0 === n && (n = "default");
                var r = t.project,
                    a = t.topic,
                    u = t.region,
                    p = t.privateKey;
                H[n] && i.error("Instance " + n + " has been initialized. The new initialization will create a new instance and replace the old one. This replacement may cause various problems. We supported this replacement due to historical reasons. But we strongly recommend not initializing instances with the same name.");
                var y, m = "default" === n ? "_" : "_" + n,
                    _ = m + "_projects/" + r + "/topics/" + a,
                    T = function(t) {
                        return t && t.toLowerCase && (t = t.toLowerCase()), j[t] || j._
                    }(u),
                    x = "https://pubsub.googleapis.com/v1/projects/" + r + "/topics/" + a + ":publish",
                    C = "_pubsub_debug" + m,
                    z = "_pubsub_token" + _,
                    B = "_pubsub_queue" + _;

                function D() {
                    y = e;
                    for (var t = 0; t < 1; t++) K()
                }

                function K() {
                    var t = E(B);
                    if (t.length) {
                        var e = t.slice(0, 20);
                        L(B, t.slice(20)), P(e, K)
                    }
                }

                function N(t, e, n) {
                    var i = O[O.indexOf(n) + 1];
                    i ? o((function() {
                        P(t, e, i)
                    }), i) : L(B, E(B).concat(t))
                }

                function P(t, e, n) {
                    ! function(t, e) {
                        var n = function(t) {
                            return c ? c.getItem(t) : U()[t]
                        }(z);
                        if (n) t(n);
                        else {
                            var i = new d;
                            i.open("GET", T + "/api/v1/js/token?key=" + p, !0), i.onreadystatechange = function() {
                                if (4 === i.readyState) {
                                    var n = {};
                                    if (200 === i.status) try {
                                        n = g.parse(i.responseText)
                                    } catch (o) {}
                                    0 === n.code && n.data && n.data.accessToken ? (function(t, e) {
                                        c ? c.setItem(t, e) : q(t, e)
                                    }(z, n.data.accessToken), t(n.data.accessToken)) : e()
                                }
                            }, i.send()
                        }
                    }((function(i) {
                        return function(t) {
                            for (var e = t.data, n = [], i = null, o = 0; o < e.length; o++) {
                                var r = g.parse(e[o]);
                                r.attributes && (i = r.attributes, delete r.attributes), n.push(g.stringify(r))
                            }
                            var a = g.stringify(n);
                            if (b)(function(t) {
                                var e = "function" == typeof h;
                                return new b((function(n, i) {
                                    return e ? new w(new k([t]).stream().pipeThrough(new h("gzip"))).arrayBuffer().then((function(t) {
                                        n(t)
                                    })) : i()
                                }))
                            })(a).then((function(e) {
                                var n = new Uint8Array(e),
                                    o = A(n),
                                    r = {
                                        pub_gzip: "true",
                                        pub_web_sign: I(n)
                                    };
                                i && (r = f.assign(r, i)), R(S(t, {
                                    data: {
                                        messages: [{
                                            data: o,
                                            attributes: r
                                        }]
                                    }
                                }))
                            }), (function() {
                                var e = {
                                    pub_gzip: "true",
                                    pub_web_sign: I(a)
                                };
                                i && (e = f.assign(e, i)), R(S(t, {
                                    data: {
                                        messages: [{
                                            data: A(a),
                                            attributes: e
                                        }]
                                    }
                                }))
                            }));
                            else if (v) {
                                var s = {
                                    pub_gzip: "true",
                                    pub_web_sign: I(a)
                                };
                                i && (s = f.assign(s, i)), R(S(t, {
                                    data: {
                                        messages: [{
                                            data: A(a),
                                            attributes: s
                                        }]
                                    }
                                }))
                            }
                        }({
                            url: x,
                            token: i,
                            data: t,
                            success: e,
                            fail: function() {
                                N(t, e, n)
                            },
                            removeToken: function() {
                                ! function(t) {
                                    c ? c.removeItem(t) : function(t, e) {
                                        q(t, "", e = S({
                                            expires: new l(l.now() - 1)
                                        }, e))
                                    }(t)
                                }(z)
                            }
                        })
                    }), (function() {
                        return N(t, e, n)
                    }))
                }(function(t) {
                    L(E(t))
                })(m), K(), H[n] = {
                    send: function(t) {
                        L(B, E(B).concat(t)), y === e && (y = o(D, 0)),
                            function(t) {
                                return s ? null !== s.getItem(t) : U()[t]
                            }(C) && i.log("instance: " + n + "; url: " + x + "; message: " + t)
                    }
                }
            }({
                key: t,
                project: a,
                topic: u,
                region: n,
                privateKey: r
            })
        })),
        pub: B((function(t, e) {
            "string" == typeof e && "string" == typeof t && H[t] && H[t].send(e)
        }))
    };

    function N(t) {
        try {
            var n = p.prototype.slice.call(arguments, 1);
            if ("string" == typeof t) {
                var i = t.split(".");
                1 === i.length && (n = p.prototype.concat.call(["default"], n)), 2 === i.length && (n = p.prototype.concat.call([i[0]], n), t = i[1]), K[t].apply(e, n)
            }
        } catch (o) {}
    }
    D = function() {
        var n, i = t.pubsub;
        if (t.pubsub = N, (i = i && i.q) instanceof p)
            for (n = 0; n < i.length; n++) N.apply(e, i[n])
    }, _() ? n.addEventListener("visibilitychange", (function P() {
        _() || (n.removeEventListener("visibilitychange", P), D())
    })) : D()
}(window);