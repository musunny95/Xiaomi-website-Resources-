(() => {
    "use strict";
    var e, t, r, o, a, n, i, s, l, u, c, p = {},
        d = {};

    function f(e) {
        var t = d[e];
        if (void 0 !== t) return t.exports;
        var r = d[e] = {
            id: e,
            loaded: !1,
            exports: {}
        };
        return p[e].call(r.exports, r, r.exports, f), r.loaded = !0, r.exports
    }
    f.m = p, e = [], f.O = (t, r, o, a) => {
        if (!r) {
            var n = 1 / 0;
            for (u = 0; u < e.length; u++) {
                for (var [r, o, a] = e[u], i = !0, s = 0; s < r.length; s++)(!1 & a || n >= a) && Object.keys(f.O).every((e => f.O[e](r[s]))) ? r.splice(s--, 1) : (i = !1, a < n && (n = a));
                if (i) {
                    e.splice(u--, 1);
                    var l = o();
                    void 0 !== l && (t = l)
                }
            }
            return t
        }
        a = a || 0;
        for (var u = e.length; u > 0 && e[u - 1][2] > a; u--) e[u] = e[u - 1];
        e[u] = [r, o, a]
    }, f.n = e => {
        var t = e && e.__esModule ? () => e.default : () => e;
        return f.d(t, {
            a: t
        }), t
    }, r = Object.getPrototypeOf ? e => Object.getPrototypeOf(e) : e => e.__proto__, f.t = function(e, o) {
        if (1 & o && (e = this(e)), 8 & o) return e;
        if ("object" == typeof e && e) {
            if (4 & o && e.__esModule) return e;
            if (16 & o && "function" == typeof e.then) return e
        }
        var a = Object.create(null);
        f.r(a);
        var n = {};
        t = t || [null, r({}), r([]), r(r)];
        for (var i = 2 & o && e;
            "object" == typeof i && !~t.indexOf(i); i = r(i)) Object.getOwnPropertyNames(i).forEach((t => n[t] = () => e[t]));
        return n.default = () => e, f.d(a, n), a
    }, f.d = (e, t) => {
        for (var r in t) f.o(t, r) && !f.o(e, r) && Object.defineProperty(e, r, {
            enumerable: !0,
            get: t[r]
        })
    }, f.f = {}, f.e = e => Promise.all(Object.keys(f.f).reduce(((t, r) => (f.f[r](e, t), t)), [])), f.u = e => "js/" + ({
        78: "NotificationPreferences",
        372: "Business",
        623: "SupportFaqList",
        883: "SelectLocation",
        1391: "PaymentSuccessful",
        1414: "SiteMap",
        1677: "Support",
        1741: "Notification",
        1903: "UserAddress",
        1991: "RepairSchedule",
        2231: "Compliance",
        2477: "ProductCatalogue",
        2503: "SupportFaqDetail",
        2928: "Coupon",
        3091: "SupportOfflineForm",
        3348: "CardPayment",
        3681: "StoreDetail",
        3895: "SupportTerms",
        3985: "Categories",
        3997: "Message",
        4288: "Search",
        4664: "PaymentCompleted",
        4681: "Checkout",
        5024: "SupportNfcBank",
        5153: "SplitPaymentDetails",
        5538: "Editable",
        5884: "AfterSalesApplyList",
        6302: "SupportArticle",
        6707: "Club",
        6819: "Compare",
        7210: "FriendCode",
        7306: "AfterSalesApply",
        7693: "ItemDetail",
        7950: "Voucher",
        8225: "Components",
        8321: "UserCenter",
        8420: "HeaderFooter",
        8424: "CheckoutAgain",
        8435: "SupportEsim",
        8765: "StoreMap",
        9149: "ServiceSupport",
        9528: "SparePartsPrice",
        9531: "Feedback"
    }[e] || e) + ".chunk.js", f.miniCssF = e => 134 === e ? "css/global/runtime.css" : 4736 === e ? "css/vendor.css" : 5514 === e ? "css/react.css" : 9218 === e ? "css/global/index.css" : "css/" + ({
        78: "NotificationPreferences",
        372: "Business",
        623: "SupportFaqList",
        883: "SelectLocation",
        1391: "PaymentSuccessful",
        1414: "SiteMap",
        1677: "Support",
        1741: "Notification",
        1903: "UserAddress",
        1991: "RepairSchedule",
        2231: "Compliance",
        2477: "ProductCatalogue",
        2503: "SupportFaqDetail",
        2928: "Coupon",
        3091: "SupportOfflineForm",
        3348: "CardPayment",
        3681: "StoreDetail",
        3895: "SupportTerms",
        3985: "Categories",
        3997: "Message",
        4288: "Search",
        4664: "PaymentCompleted",
        4681: "Checkout",
        5024: "SupportNfcBank",
        5153: "SplitPaymentDetails",
        5538: "Editable",
        5884: "AfterSalesApplyList",
        6302: "SupportArticle",
        6707: "Club",
        6819: "Compare",
        7210: "FriendCode",
        7306: "AfterSalesApply",
        7693: "ItemDetail",
        7950: "Voucher",
        8225: "Components",
        8321: "UserCenter",
        8420: "HeaderFooter",
        8424: "CheckoutAgain",
        8435: "SupportEsim",
        8765: "StoreMap",
        9149: "ServiceSupport",
        9528: "SparePartsPrice",
        9531: "Feedback"
    }[e] || e) + ".chunk.css", f.g = function() {
        if ("object" == typeof globalThis) return globalThis;
        try {
            return this || new Function("return this")()
        } catch (e) {
            if ("object" == typeof window) return window
        }
    }(), f.o = (e, t) => Object.prototype.hasOwnProperty.call(e, t), o = {}, a = "@mi/store-mi-web:", f.l = (e, t, r, n) => {
        if (o[e]) o[e].push(t);
        else {
            var i, s;
            if (void 0 !== r)
                for (var l = document.getElementsByTagName("script"), u = 0; u < l.length; u++) {
                    var c = l[u];
                    if (c.getAttribute("src") == e || c.getAttribute("data-webpack") == a + r) {
                        i = c;
                        break
                    }
                }
            i || (s = !0, (i = document.createElement("script")).charset = "utf-8", i.timeout = 120, f.nc && i.setAttribute("nonce", f.nc), i.setAttribute("data-webpack", a + r), i.src = e), o[e] = [t];
            var p = (t, r) => {
                    i.onerror = i.onload = null, clearTimeout(d);
                    var a = o[e];
                    if (delete o[e], i.parentNode && i.parentNode.removeChild(i), a && a.forEach((e => e(r))), t) return t(r)
                },
                d = setTimeout(p.bind(null, void 0, {
                    type: "timeout",
                    target: i
                }), 12e4);
            i.onerror = p.bind(null, i.onerror), i.onload = p.bind(null, i.onload), s && document.head.appendChild(i)
        }
    }, f.r = e => {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(e, "__esModule", {
            value: !0
        })
    }, f.nmd = e => (e.paths = [], e.children || (e.children = []), e), (() => {
        var e;
        f.g.importScripts && (e = f.g.location + "");
        var t = f.g.document;
        if (!e && t && (t.currentScript && (e = t.currentScript.src), !e)) {
            var r = t.getElementsByTagName("script");
            if (r.length)
                for (var o = r.length - 1; o > -1 && !e;) e = r[o--].src
        }
        if (!e) throw new Error("Automatic publicPath is not supported in this browser");
        e = e.replace(/#.*$/, "").replace(/\?.*$/, "").replace(/\/[^\/]+$/, "/"), f.p = e + "../../"
    })(), n = f.u, i = f.e, s = new Map, l = new Map, f.u = function(e) {
        return n(e) + (s.has(e) ? "?" + s.get(e) : "")
    }, f.e = function(e) {
        return i(e).catch((function(t) {
            var r = l.has(e) ? l.get(e) : 5;
            if (r < 1) {
                var o = n(e);
                throw t.message = "Loading chunk " + e + " failed after 5 retries.\n(" + o + ")", t.request = o, t
            }
            var a = "?t=" + Date.now();
            return s.set(e, a), l.set(e, r - 1), f.e(e)
        }))
    }, u = e => new Promise(((t, r) => {
        var o = f.miniCssF(e),
            a = f.p + o;
        if (((e, t) => {
                for (var r = document.getElementsByTagName("link"), o = 0; o < r.length; o++) {
                    var a = (i = r[o]).getAttribute("data-href") || i.getAttribute("href");
                    if ("stylesheet" === i.rel && (a === e || a === t)) return i
                }
                var n = document.getElementsByTagName("style");
                for (o = 0; o < n.length; o++) {
                    var i;
                    if ((a = (i = n[o]).getAttribute("data-href")) === e || a === t) return i
                }
            })(o, a)) return t();
        ((e, t, r, o) => {
            var a = document.createElement("link");
            a.rel = "stylesheet", a.type = "text/css", a.onerror = a.onload = n => {
                if (a.onerror = a.onload = null, "load" === n.type) r();
                else {
                    var i = n && ("load" === n.type ? "missing" : n.type),
                        s = n && n.target && n.target.href || t,
                        l = new Error("Loading CSS chunk " + e + " failed.\n(" + s + ")");
                    l.code = "CSS_CHUNK_LOAD_FAILED", l.type = i, l.request = s, a.parentNode.removeChild(a), o(l)
                }
            }, a.href = t, document.head.appendChild(a)
        })(e, a, t, r)
    })), c = {
        134: 0
    }, f.f.miniCss = (e, t) => {
        c[e] ? t.push(c[e]) : 0 !== c[e] && {
            51: 1,
            57: 1,
            78: 1,
            372: 1,
            455: 1,
            537: 1,
            623: 1,
            668: 1,
            792: 1,
            797: 1,
            801: 1,
            883: 1,
            1091: 1,
            1188: 1,
            1391: 1,
            1414: 1,
            1477: 1,
            1677: 1,
            1741: 1,
            1844: 1,
            1903: 1,
            1908: 1,
            1975: 1,
            1991: 1,
            2168: 1,
            2231: 1,
            2388: 1,
            2477: 1,
            2480: 1,
            2503: 1,
            2775: 1,
            2928: 1,
            2959: 1,
            3035: 1,
            3091: 1,
            3256: 1,
            3348: 1,
            3355: 1,
            3681: 1,
            3716: 1,
            3895: 1,
            3971: 1,
            3985: 1,
            3997: 1,
            4086: 1,
            4090: 1,
            4097: 1,
            4288: 1,
            4664: 1,
            4789: 1,
            4980: 1,
            4984: 1,
            5024: 1,
            5144: 1,
            5153: 1,
            5221: 1,
            5265: 1,
            5361: 1,
            5607: 1,
            5720: 1,
            5884: 1,
            6186: 1,
            6236: 1,
            6302: 1,
            6407: 1,
            6457: 1,
            6707: 1,
            6819: 1,
            7210: 1,
            7306: 1,
            7358: 1,
            7626: 1,
            7693: 1,
            7919: 1,
            7950: 1,
            8225: 1,
            8289: 1,
            8291: 1,
            8321: 1,
            8424: 1,
            8435: 1,
            8765: 1,
            8957: 1,
            9149: 1,
            9355: 1,
            9528: 1,
            9531: 1,
            9653: 1,
            9841: 1,
            9842: 1
        }[e] && t.push(c[e] = u(e).then((() => {
            c[e] = 0
        }), (t => {
            throw delete c[e], t
        })))
    }, (() => {
        var e = {
            134: 0
        };
        f.f.j = (t, r) => {
            var o = f.o(e, t) ? e[t] : void 0;
            if (0 !== o)
                if (o) r.push(o[2]);
                else if (134 != t) {
                var a = new Promise(((r, a) => o = e[t] = [r, a]));
                r.push(o[2] = a);
                var n = f.p + f.u(t),
                    i = new Error;
                f.l(n, (r => {
                    if (f.o(e, t) && (0 !== (o = e[t]) && (e[t] = void 0), o)) {
                        var a = r && ("load" === r.type ? "missing" : r.type),
                            n = r && r.target && r.target.src;
                        i.message = "Loading chunk " + t + " failed.\n(" + a + ": " + n + ")", i.name = "ChunkLoadError", i.type = a, i.request = n, o[1](i)
                    }
                }), "chunk-" + t, t)
            } else e[t] = 0
        }, f.O.j = t => 0 === e[t];
        var t = (t, r) => {
                var o, a, [n, i, s] = r,
                    l = 0;
                if (n.some((t => 0 !== e[t]))) {
                    for (o in i) f.o(i, o) && (f.m[o] = i[o]);
                    if (s) var u = s(f)
                }
                for (t && t(r); l < n.length; l++) a = n[l], f.o(e, a) && e[a] && e[a][0](), e[a] = 0;
                return f.O(u)
            },
            r = self.__LOADABLE_LOADED_CHUNKS__ = self.__LOADABLE_LOADED_CHUNKS__ || [];
        r.forEach(t.bind(null, 0)), r.push = t.bind(null, r.push.bind(r))
    })()
})();