"use strict";
(self.__LOADABLE_LOADED_CHUNKS__ = self.__LOADABLE_LOADED_CHUNKS__ || []).push([
    [5538], {
        63220: (e, t, n) => {
            n.r(t), n.d(t, {
                default: () => f
            });
            var a = n(67294),
                r = n(27392),
                o = n(28403),
                i = n(89522),
                l = n(16125),
                c = n(1796),
                s = function(e, t) {
                    var n = "function" == typeof Symbol && e[Symbol.iterator];
                    if (!n) return e;
                    var a, r, o = n.call(e),
                        i = [];
                    try {
                        for (;
                            (void 0 === t || t-- > 0) && !(a = o.next()).done;) i.push(a.value)
                    } catch (l) {
                        r = {
                            error: l
                        }
                    } finally {
                        try {
                            a && !a.done && (n = o.return) && n.call(o)
                        } finally {
                            if (r) throw r.error
                        }
                    }
                    return i
                };

            function u() {
                var e = (0, c.oW)(),
                    t = (0, c.z1)(),
                    n = s((0, a.useState)(!1), 2),
                    u = n[0],
                    f = n[1],
                    d = (0, a.useContext)(l.__);
                return (0, a.useEffect)((function() {
                    d.getServiceSuccess && "success" === d.ajaxStatus && !d.data.layouts.length && window.location.assign("".concat(e.wwwSite.pc, "/errors/404"))
                }), [d.ajaxStatus]), a.createElement(a.Fragment, null, a.createElement(r.h, {
                    hasReportedView: u
                }), !!t.headings && a.createElement("h1", {
                    style: {
                        display: "none",
                        height: 0,
                        margin: 0,
                        visibility: "hidden"
                    }
                }, t.headings), a.createElement(o.u, {
                    onGetDataSuccess: function() {
                        f(!0)
                    }
                }), a.createElement(i.$, {
                    footnote: d.data.footnote
                }))
            }

            function f() {
                var e = (0, c.oW)();
                return a.createElement(l.hP, {
                    siteConfig: e
                }, a.createElement(u, null))
            }
        }
    }
]);