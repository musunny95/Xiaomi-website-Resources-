"use strict";
(self.__LOADABLE_LOADED_CHUNKS__ = self.__LOADABLE_LOADED_CHUNKS__ || []).push([
    [1091], {
        20172: () => {},
        62367: () => {},
        64457: (e, t, n) => {
            n.d(t, {
                v: () => p
            });
            var a = n(67294),
                o = n(26859),
                l = n(85319),
                r = n(4153),
                i = n(86579),
                c = n(70308),
                s = n(16125),
                u = ["#898989", "#FF6900"],
                m = n(94184),
                d = n(1796),
                v = n(42625),
                f = function() {
                    return f = Object.assign || function(e) {
                        for (var t, n = 1, a = arguments.length; n < a; n++)
                            for (var o in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
                        return e
                    }, f.apply(this, arguments)
                };

            function p(e) {
                var t, n, p, g, _, b, y, E, h, N, k, x, S, w, C, T, O, I, M, U, P, A, L = e.subtitle,
                    D = e.style,
                    F = e.theme,
                    j = e.goods,
                    z = e.images,
                    q = e.buttons,
                    B = e.classModify,
                    W = e.skeletonData,
                    R = e.otClick,
                    J = e.otModule,
                    G = e.onClickGoodsItem,
                    Y = e.exposeGoodsItem,
                    V = e.exposeCustomProperty,
                    Z = void 0 === V ? "data-ot-expose" : V,
                    H = "quarter" !== B,
                    Q = (0, d.Sz)(),
                    $ = ["view_item_list", "select_item"],
                    K = {
                        elementTitle: null === (p = null == q ? void 0 : q[0]) || void 0 === p ? void 0 : p.text,
                        elementName: "learn_more",
                        itemName: null === (g = null == j ? void 0 : j[0]) || void 0 === g ? void 0 : g.name
                    },
                    X = ((t = {})[Z] = Y || JSON.stringify(f({
                        event: $[0],
                        tip: {
                            c: J
                        }
                    }, K)), t),
                    ee = (0, a.useContext)(s.__).getServiceSuccess || !!W,
                    te = (0, a.useMemo)((function() {
                        return z.length > 1
                    }), []);
                return a.createElement("section", f({
                    className: m((n = {
                        "store-goods": !0
                    }, n["store-goods--".concat(B)] = !!B, n["store-goods--".concat(F)] = te && !!F, n)),
                    role: "button",
                    tabIndex: 0,
                    onClick: function() {
                        var e, t;
                        G ? G() : (null === (e = null == q ? void 0 : q[0]) || void 0 === e ? void 0 : e.gotoUrl) && (R(f({
                            event: $[1],
                            tip: {
                                c: J,
                                d: 1
                            }
                        }, K)), (0, v.MN)("".concat(null === (t = null == q ? void 0 : q[0]) || void 0 === t ? void 0 : t.gotoUrl)))
                    }
                }, X), te && a.createElement(o.t, {
                    className: "store-goods__full-image",
                    alt: (null === (_ = z[1]) || void 0 === _ ? void 0 : _.alt) || (null === (b = null == q ? void 0 : q[0]) || void 0 === b ? void 0 : b.text) || "",
                    srcSet: (null === (y = z[1]) || void 0 === y ? void 0 : y.src) || []
                }), a.createElement("div", {
                    className: "store-goods__wrapper"
                }, a.createElement("div", {
                    className: "store-goods__info"
                }, a.createElement("div", {
                    className: "store-goods__info--upper"
                }, a.createElement("div", {
                    className: "store-goods__title"
                }, a.createElement(l.i, {
                    href: null === (E = null == q ? void 0 : q[0]) || void 0 === E ? void 0 : E.gotoUrl
                }, null === (h = null == q ? void 0 : q[0]) || void 0 === h ? void 0 : h.text)), H && !!L && a.createElement("span", {
                    className: "store-goods__subtitle",
                    style: te ? {} : {
                        color: u[D - 1]
                    }
                }, L), a.createElement(r.Y, {
                    className: "store-goods__energy",
                    energyInfo: null === (N = null == j ? void 0 : j[0]) || void 0 === N ? void 0 : N.energyInfo
                }), !te && a.createElement(i.Z.Tags, {
                    className: "store-goods__tag-list",
                    tags: null === (x = null === (k = null == j ? void 0 : j[0]) || void 0 === k ? void 0 : k.marketingInfo) || void 0 === x ? void 0 : x.tags
                })), a.createElement("div", {
                    className: "store-goods__info--lower"
                }, !!Array.from(j || []).length && a.createElement(c.n, {
                    className: "store-goods__price",
                    salePrice: String(null === (S = j[0]) || void 0 === S ? void 0 : S.salePrice),
                    delPrice: String(null === (w = j[0]) || void 0 === w ? void 0 : w.originPrice),
                    isShowFrom: !(null === (C = j[0]) || void 0 === C ? void 0 : C.salePriceIsEQ),
                    isShowBlank: Q || !ee
                }), a.createElement(i.Z.Installment, {
                    className: "store-goods__installment",
                    installment: null === (O = null === (T = null == j ? void 0 : j[0]) || void 0 === T ? void 0 : T.marketingInfo) || void 0 === O ? void 0 : O.installment
                }))), a.createElement("div", {
                    className: "store-goods__product"
                }, a.createElement("img", {
                    className: "store-goods__image",
                    src: null === (M = null === (I = null == z ? void 0 : z[0]) || void 0 === I ? void 0 : I.src) || void 0 === M ? void 0 : M.widescreen,
                    alt: null === (U = null == j ? void 0 : j[0]) || void 0 === U ? void 0 : U.name,
                    loading: "lazy",
                    style: te ? {
                        display: "none"
                    } : {}
                }), a.createElement(i.Z.Gift, {
                    className: "store-goods__gift",
                    gift: null === (A = null === (P = null == j ? void 0 : j[0]) || void 0 === P ? void 0 : P.marketingInfo) || void 0 === A ? void 0 : A.gift
                }))))
            }
        },
        37133: (e, t, n) => {
            n.d(t, {
                $: () => r
            });
            var a = n(67294),
                o = n(94184),
                l = n(26859);

            function r(e) {
                var t, n, r = e.className,
                    i = void 0 === r ? "" : r,
                    c = e.borderWidth,
                    s = void 0 === c ? 0 : c,
                    u = e.borderColor,
                    m = void 0 === u ? "none" : u,
                    d = e.hasBorderShadow,
                    v = void 0 !== d && d,
                    f = e.hasShadow,
                    p = void 0 !== f && f,
                    g = e.src,
                    _ = e.alt,
                    b = (0, a.useMemo)((function() {
                        return i.split(" ").map((function(e) {
                            return "".concat(e, "-border")
                        })).join(" ")
                    }), []);
                return a.createElement(l.t, {
                    className: o((t = {
                        "clip-image": !0,
                        "clip-image--shadow": p
                    }, t[i] = !!i, t)),
                    alt: _,
                    srcSet: {
                        widescreen: g
                    }
                }, s ? a.createElement("svg", {
                    viewBox: "0 0 1 1",
                    className: o((n = {
                        "clip-image__border": !0,
                        "clip-image__border--shadow": v
                    }, n[b] = !!b, n))
                }, a.createElement("g", {
                    strokeWidth: s / 180,
                    stroke: m,
                    fill: "none",
                    transform: "scale(".concat(1 - s / 240, ") translate(").concat(s / 480, ", ").concat(s / 480, ")")
                }, a.createElement("use", {
                    xlinkHref: "#svgBasePath"
                }))) : a.createElement(a.Fragment, null))
            }
        },
        13845: (e, t, n) => {
            n.d(t, {
                Z: () => l
            });
            var a = n(67294),
                o = n(42152);
            const l = function(e) {
                var t = e.copyValue,
                    n = e.children,
                    l = e.onClick;
                return (0, a.useEffect)((function() {
                    var t = new o(".mi-copy");
                    t.on("success", (function() {
                        var t;
                        null === (t = e.successCopy) || void 0 === t || t.call(e)
                    })), t.on("error", (function() {
                        var t;
                        null === (t = e.errorCopy) || void 0 === t || t.call(e)
                    }))
                })), a.createElement("span", {
                    className: "mi-copy",
                    "data-clipboard-action": "copy",
                    "data-clipboard-text": t,
                    role: "button",
                    tabIndex: 0,
                    onClick: function() {
                        return "function" == typeof l && l()
                    }
                }, n)
            }
        },
        85319: (e, t, n) => {
            n.d(t, {
                i: () => i
            });
            var a = n(67294),
                o = n(94184),
                l = n.n(o),
                r = n(86969);

            function i(e) {
                var t, n = e.children,
                    o = e.href,
                    i = void 0 === o ? "" : o,
                    c = e.className;
                return a.createElement("a", {
                    className: l()("inner-chain", (t = {}, t["".concat(c)] = !!c, t)),
                    href: (0, r.H)(i),
                    onClick: function(e) {
                        e.preventDefault()
                    }
                }, n)
            }
        },
        86579: (e, t, n) => {
            n.d(t, {
                Z: () => f
            });
            var a = n(67294),
                o = n(62711),
                l = n(94184),
                r = n.n(l);

            function i(e) {
                var t, n = e.className,
                    l = void 0 === n ? "" : n,
                    i = e.usage,
                    c = void 0 === i ? "display" : i,
                    s = e.totalStars,
                    u = void 0 === s ? 5 : s,
                    m = e.lightUpStars,
                    d = void 0 === m ? 0 : m,
                    v = e.onClick,
                    f = "mi-stars";
                return a.createElement("div", {
                    className: r()(f, (t = {}, t[l] = !!l, t))
                }, a.createElement("ul", {
                    className: "".concat(f, "__list")
                }, Array.from({
                    length: Math.floor(u)
                }, (function() {
                    return null
                })).map((function(e, t) {
                    var n, l;
                    return a.createElement("li", {
                        key: t,
                        className: "".concat(f, "__item")
                    }, a.createElement(o.q, {
                        symbol: "star",
                        className: r()("".concat(f, "__star"), "".concat(f, "__star--top"), (n = {}, n["".concat(f, "__star--interactive")] = "rate" === c, n)),
                        style: {
                            width: Math.floor(d) > t ? "100%" : Math.ceil(d) > t ? "".concat(d % 1 * 100, "%") : "0"
                        }
                    }), a.createElement(o.q, {
                        symbol: "star",
                        className: r()("".concat(f, "__star"), "".concat(f, "__star--bottom"), (l = {}, l["".concat(f, "__star--interactive")] = "rate" === c, l)),
                        onClick: function() {
                            return function(e) {
                                "rate" === c && "function" == typeof v && v(e)
                            }(t)
                        }
                    }))
                }))))
            }
            var c = n(37133),
                s = n(1796);
            var u = n(39784),
                m = n(56024),
                d = function() {
                    return d = Object.assign || function(e) {
                        for (var t, n = 1, a = arguments.length; n < a; n++)
                            for (var o in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
                        return e
                    }, d.apply(this, arguments)
                };

            function v(e) {
                var t, n = e.className,
                    o = void 0 === n ? "" : n,
                    l = e.tags,
                    i = ["out-of-stock"];
                return a.createElement("div", {
                    className: r()("mi-marketing-label__tags", (t = {}, t[o] = !!o, t))
                }, a.createElement("ul", {
                    className: "tag__list"
                }, Array.from(l || []).map((function(e, t) {
                    return a.createElement(u.V, {
                        key: "".concat(e.subType, "-").concat(t),
                        className: r()("tag__item", {
                            "tag__item--mobile-only": i.includes(e.subType)
                        }),
                        color: e.color,
                        tagName: "li"
                    }, e.label)
                }))))
            }
            var f = {
                Comment: function(e) {
                    var t, n = e.className,
                        o = void 0 === n ? "" : n,
                        l = e.comment,
                        c = e.isOutOfStock,
                        s = void 0 !== c && c;
                    return !l || !(null == l ? void 0 : l.label) && !(null == l ? void 0 : l.rating) || s ? null : a.createElement("div", {
                        className: r()("mi-marketing-label__comment", (t = {}, t[o] = !!o, t))
                    }, a.createElement("span", {
                        className: "comment__label"
                    }, l.label), a.createElement(i, {
                        className: "comment__stars",
                        lightUpStars: l.rating
                    }))
                },
                Gift: function(e) {
                    var t, n = e.className,
                        o = void 0 === n ? "" : n,
                        l = e.gift,
                        i = e.isOutOfStock,
                        u = void 0 !== i && i,
                        m = (0, s.YB)();
                    return !(null == l ? void 0 : l.imageUrl) || u ? null : a.createElement(c.$, {
                        className: r()("mi-marketing-label__gift", (t = {}, t[o] = !!o, t)),
                        src: l.imageUrl,
                        alt: m.get("0d9175fe89fb80d815e7d03698b6e83a"),
                        borderColor: "#fff",
                        borderWidth: 6
                    })
                },
                Tags: function(e) {
                    var t = e.tags,
                        n = e.isOutOfStock,
                        o = void 0 !== n && n,
                        l = (0, s.YB)(),
                        r = (0, s.oW)(),
                        i = (0, m.a)();
                    if (!r.isToC) {
                        var c = Array.from(t || []).filter((function(e) {
                            return "new" === e.subType
                        }));
                        return c.length ? a.createElement(v, d({}, e, {
                            tags: c
                        })) : null
                    }
                    return o ? "mobile" === i ? a.createElement(v, d({}, e, {
                        tags: [{
                            type: "out-of-stock",
                            subType: "out-of-stock",
                            label: l.get("b55197a49e8c4cd8c314bc2aa39d6feb"),
                            color: "grey"
                        }]
                    })) : null : (null == t ? void 0 : t.length) ? a.createElement(v, d({}, e)) : null
                },
                Installment: function(e) {
                    var t, n = e.className,
                        o = void 0 === n ? "" : n,
                        l = e.installment,
                        i = e.isOutOfStock;
                    return !l || void 0 !== i && i ? null : a.createElement("div", {
                        className: r()("mi-marketing-label__installment", (t = {}, t[o] = !!o, t))
                    }, a.createElement("span", null, l.label))
                }
            }
        },
        48651: (e, t, n) => {
            n.d(t, {
                t: () => u,
                v: () => s
            });
            var a = n(67294),
                o = n(39116),
                l = n(1796),
                r = n(99548),
                i = n(21102),
                c = n(1128);

            function s(e, t) {
                void 0 === t && (t = !1);
                var n = (0, a.useContext)(o.kn).state.companyStatus,
                    s = (0, l.YB)(),
                    u = (0, r.A)();
                return !u || u && n === i.S.GOOD ? u && t ? "" : e ? s.get("eeceac1af4e7620894d6d2083921bb73") : s.get("b55197a49e8c4cd8c314bc2aa39d6feb") : (0, c.Jb)() ? n === i.S.PENDING ? s.get("9f07825e1e70e906008d2006d555aaa1") : s.get("1bce22aa63015986194e2d666ea1f91e") : s.get("f2fdea440d768b85591e936a803c3631")
            }

            function u(e) {
                var t = e.commodity,
                    n = Object.keys(m(t, "firstSpecValue")),
                    a = Object.keys(m(t, "secondSpecValue")),
                    o = (a = !a.length && n.length > 1 ? [""] : a).map((function(e) {
                        return n.map((function(n) {
                            return m(t, "firstSpecValue")[n].find((function(t) {
                                return t.secondSpecValue === e
                            })) || {}
                        })).filter((function(e) {
                            return !!e.id
                        }))
                    }));
                return {
                    specList1: n,
                    specList2: a,
                    twoDimensionArray: o
                }
            }

            function m(e, t) {
                return e.reduce((function(e, n) {
                    return n[t] ? (e[n[t]] ? e[n[t]].push(n) : e[n[t]] = [n], e) : e
                }), {})
            }
        },
        25729: (e, t, n) => {
            n.d(t, {
                IW: () => s,
                cw: () => u,
                gJ: () => a
            });
            var a, o = n(67294),
                l = function() {
                    return l = Object.assign || function(e) {
                        for (var t, n = 1, a = arguments.length; n < a; n++)
                            for (var o in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
                        return e
                    }, l.apply(this, arguments)
                },
                r = function(e, t) {
                    var n = "function" == typeof Symbol && e[Symbol.iterator];
                    if (!n) return e;
                    var a, o, l = n.call(e),
                        r = [];
                    try {
                        for (;
                            (void 0 === t || t-- > 0) && !(a = l.next()).done;) r.push(a.value)
                    } catch (i) {
                        o = {
                            error: i
                        }
                    } finally {
                        try {
                            a && !a.done && (n = l.return) && n.call(l)
                        } finally {
                            if (o) throw o.error
                        }
                    }
                    return r
                };
            ! function(e) {
                e.SET_IS_SHOW_BUSINESS_MODAL = "SET_IS_SHOW_BUSINESS_MODAL"
            }(a || (a = {}));
            var i = {
                isShowBusinessModal: !1
            };

            function c(e, t) {
                return t.type === a.SET_IS_SHOW_BUSINESS_MODAL ? l(l({}, e), {
                    isShowBusinessModal: t.payload || !1
                }) : e
            }
            var s = (0, o.createContext)({
                state: i,
                dispatch: function(e) {}
            });

            function u(e) {
                var t = r((0, o.useReducer)(c, i), 2),
                    n = t[0],
                    a = t[1];
                return o.createElement(s.Provider, {
                    value: {
                        state: n,
                        dispatch: a
                    }
                }, e.children)
            }
        },
        98231: (e, t, n) => {
            n.d(t, {
                Pk: () => s,
                Tm: () => a,
                ZQ: () => u
            });
            var a, o = n(67294),
                l = function() {
                    return l = Object.assign || function(e) {
                        for (var t, n = 1, a = arguments.length; n < a; n++)
                            for (var o in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
                        return e
                    }, l.apply(this, arguments)
                },
                r = function(e, t) {
                    var n = "function" == typeof Symbol && e[Symbol.iterator];
                    if (!n) return e;
                    var a, o, l = n.call(e),
                        r = [];
                    try {
                        for (;
                            (void 0 === t || t-- > 0) && !(a = l.next()).done;) r.push(a.value)
                    } catch (i) {
                        o = {
                            error: i
                        }
                    } finally {
                        try {
                            a && !a.done && (n = l.return) && n.call(l)
                        } finally {
                            if (o) throw o.error
                        }
                    }
                    return r
                };
            ! function(e) {
                e.SET_IS_FOLLOWED_NEW_PRODUCTS = "SET_IS_FOLLOWED_NEW_PRODUCTS", e.RESET_IS_FOLLOWED_NEW_PRODUCTS = "RESET_IS_FOLLOWED_NEW_PRODUCTS"
            }(a || (a = {}));
            var i = {
                newProductsFollowStatus: -1
            };

            function c(e, t) {
                switch (t.type) {
                    case a.SET_IS_FOLLOWED_NEW_PRODUCTS:
                        return l(l({}, e), {
                            newProductsFollowStatus: t.payload
                        });
                    case a.RESET_IS_FOLLOWED_NEW_PRODUCTS:
                        return l(l({}, e), {
                            newProductsFollowStatus: i.newProductsFollowStatus
                        });
                    default:
                        return e
                }
            }
            var s = (0, o.createContext)({
                state: i,
                dispatch: function(e) {}
            });

            function u(e) {
                var t = r((0, o.useReducer)(c, i), 2),
                    n = t[0],
                    a = t[1];
                return o.createElement(s.Provider, {
                    value: {
                        state: n,
                        dispatch: a
                    }
                }, e.children)
            }
        },
        14363: (e, t, n) => {
            n.d(t, {
                I: () => C
            });
            var a = n(67294);

            function o(e) {
                var t = e.children;
                return a.createElement(a.Fragment, null, t.map((function(e) {
                    return a.cloneElement(e, {
                        classModify: "empty"
                    })
                })))
            }

            function l(e) {
                var t = e.children;
                return a.createElement(a.Fragment, null, t.map((function(e) {
                    return a.cloneElement(e, {
                        classModify: "full"
                    })
                })))
            }

            function r(e) {
                var t = e.children;
                return a.createElement(a.Fragment, null, t.map((function(e) {
                    return a.cloneElement(e, {
                        classModify: "half"
                    })
                })))
            }

            function i(e) {
                var t = e.children;
                return a.createElement(a.Fragment, null, t.map((function(e, t) {
                    return a.cloneElement(e, {
                        classModify: 0 === t ? "half" : "quarter"
                    })
                })))
            }

            function c(e) {
                var t = e.children;
                return a.createElement(a.Fragment, null, t.map((function(e, t) {
                    return a.cloneElement(e, {
                        classModify: 0 === t ? "half" : "quarter"
                    })
                })))
            }

            function s(e) {
                var t = e.children;
                return a.createElement(a.Fragment, null, t.map((function(e) {
                    return a.cloneElement(e, {
                        classModify: "quarter"
                    })
                })))
            }

            function u(e) {
                var t = e.children;
                return a.createElement(a.Fragment, null, t.map((function(e, t) {
                    return a.cloneElement(e, {
                        classModify: 0 === t ? "half" : "mezzanine"
                    })
                })))
            }

            function m(e) {
                var t = e.children;
                return a.createElement(a.Fragment, null, t.map((function(e, t) {
                    return a.cloneElement(e, {
                        classModify: 0 === t ? "half" : "mezzanine"
                    })
                })))
            }

            function d(e) {
                var t = e.children;
                return a.createElement(a.Fragment, null, t.map((function(e) {
                    return a.cloneElement(e, {
                        classModify: "trisection"
                    })
                })))
            }

            function v(e) {
                var t = e.children;
                return a.createElement(a.Fragment, null, t.map((function(e, t) {
                    return a.cloneElement(e, {
                        classModify: 0 === t ? "trisection" : "remainder"
                    })
                })))
            }

            function f(e) {
                var t = e.children;
                return a.createElement(a.Fragment, null, t.map((function(e, t) {
                    return a.cloneElement(e, {
                        classModify: 0 === t ? "trisection" : "remainder"
                    })
                })))
            }

            function p(e) {
                var t = e.children;
                return a.createElement(a.Fragment, null, t.map((function(e, t) {
                    return a.cloneElement(e, {
                        classModify: 0 === t ? "quarter" : "remainder"
                    })
                })))
            }

            function g(e) {
                var t = e.children;
                return a.createElement(a.Fragment, null, t.map((function(e, t) {
                    return a.cloneElement(e, {
                        classModify: 0 === t ? "quarter" : "remainder"
                    })
                })))
            }

            function _(e) {
                var t = e.children;
                return a.createElement(a.Fragment, null, t.map((function(e) {
                    return a.cloneElement(e, {
                        classModify: "half"
                    })
                })))
            }

            function b(e) {
                var t = e.children;
                return a.createElement(a.Fragment, null, t.map((function(e, t) {
                    return a.cloneElement(e, {
                        classModify: 0 === t ? "half" : "quarter"
                    })
                })))
            }

            function y(e) {
                var t = e.children;
                return a.createElement(a.Fragment, null, t.map((function(e, t) {
                    return a.cloneElement(e, {
                        classModify: 0 === t ? "half" : "quarter"
                    })
                })))
            }

            function E(e) {
                var t = e.children;
                return a.createElement(a.Fragment, null, t.map((function(e) {
                    return a.cloneElement(e, {
                        classModify: "quarter"
                    })
                })))
            }
            var h = n(56024);

            function N(e) {
                var t = e.children,
                    n = (0, h.a)();
                return a.createElement(a.Fragment, null, t.map((function(e, t) {
                    return a.cloneElement(e, {
                        classModify: 0 === t || 1 === t ? "mobile" === n ? "quarter" : "half" : "quarter"
                    })
                })))
            }

            function k(e) {
                var t = e.children,
                    n = (0, h.a)();

                function o(e) {
                    return [0, 1, 2, 5].includes(e) ? "mobile" === n ? "quarter" : "half" : "quarter"
                }
                return a.createElement(a.Fragment, null, t.map((function(e, t) {
                    return a.cloneElement(e, {
                        classModify: o(t)
                    })
                })))
            }
            n(62367);
            var x = function() {
                    return x = Object.assign || function(e) {
                        for (var t, n = 1, a = arguments.length; n < a; n++)
                            for (var o in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
                        return e
                    }, x.apply(this, arguments)
                },
                S = function(e, t) {
                    var n = "function" == typeof Symbol && e[Symbol.iterator];
                    if (!n) return e;
                    var a, o, l = n.call(e),
                        r = [];
                    try {
                        for (;
                            (void 0 === t || t-- > 0) && !(a = l.next()).done;) r.push(a.value)
                    } catch (i) {
                        o = {
                            error: i
                        }
                    } finally {
                        try {
                            a && !a.done && (n = l.return) && n.call(l)
                        } finally {
                            if (o) throw o.error
                        }
                    }
                    return r
                };

            function w(e) {
                var t = e.margin,
                    n = void 0 === t ? "small" : t,
                    h = e.style,
                    x = e.children,
                    w = e.forwardedRef,
                    C = [
                        [o, "empty"],
                        [l, "full"],
                        [r, "half"],
                        [i, "half-quarter"],
                        [c, "quarter-half"],
                        [s, "quarter"],
                        [u, "half-mezzanine"],
                        [m, "mezzanine-half"],
                        [d, "trisection"],
                        [v, "trisection-remainder"],
                        [f, "remainder-trisection"],
                        [p, "quarter-remainder"],
                        [g, "remainder-quarter"],
                        [_, "keep-half"],
                        [b, "special-half-quarter"],
                        [y, "special-quarter-half"],
                        [E, "special-quarter"],
                        [N, "unlimited-type-one"],
                        [k, "unlimited-type-two"]
                    ],
                    T = S(C[h] || C[1], 2),
                    O = T[0],
                    I = T[1];
                return a.createElement("section", {
                    className: "site-grid site-grid--".concat(n, " site-grid--").concat(I),
                    role: "grid",
                    ref: w
                }, a.createElement(O, null, x))
            }
            var C = (0, a.forwardRef)((function(e, t) {
                return a.createElement(w, x({}, e, {
                    forwardedRef: t
                }))
            }))
        },
        28403: (e, t, n) => {
            n.d(t, {
                u: () => Yl
            });
            var a = n(67294),
                o = n(16550),
                l = n(94184),
                r = n.n(l),
                i = n(26859),
                c = n(4153),
                s = n(70308),
                u = n(7651),
                m = n(16125),
                d = n(1796),
                v = n(42625);

            function f(e) {
                var t, n = e.title,
                    o = void 0 === n ? "" : n,
                    r = e.basicClassName,
                    i = e.alt,
                    c = void 0 === i ? "" : i,
                    s = e.isEvent,
                    u = void 0 !== s && s;
                return a.createElement(a.Fragment, null, o.includes(".svg") ? a.createElement("img", {
                    className: "".concat(r, "__title ").concat(r, "__title--svg"),
                    src: o,
                    alt: c
                }) : a.createElement("h2", {
                    className: l((t = {}, t["".concat(r, "__title")] = !0, t["".concat((0, v.NU)(o))] = !!(0, v.NU)(o) && !u, t))
                }, o))
            }

            function p(e) {
                var t, n, o, r, p, g, _, b, y, E, h, N, k, x = e.title,
                    S = e.subtitle,
                    w = e.style,
                    C = e.theme,
                    T = e.tips,
                    O = void 0 === T ? "" : T,
                    I = e.basicClassName,
                    M = void 0 === I ? "site-banner" : I,
                    U = e.images,
                    P = e.goods,
                    A = e.type,
                    L = e.buttons,
                    D = e.extends,
                    F = e.bannerType,
                    j = e.classModify,
                    z = e.skeletonData,
                    q = void 0 !== z && z,
                    B = e.otClick,
                    W = e.otModule,
                    R = (0, d.Sz)(),
                    J = (0, a.useContext)(m.__).getServiceSuccess || q,
                    G = {
                        panorama: {
                            isTipsBefore: !1,
                            buryEvent: ["view_promotion", "select_promotion"],
                            buttonForceArrow: "enable",
                            buttonType: "link",
                            isShowGoodsInfo: !0,
                            styleList: ["right", "left"]
                        },
                        event: {
                            isTipsBefore: !0,
                            buryEvent: ["view_promotion", "select_promotion"],
                            buttonForceArrow: void 0,
                            isShowGoodsInfo: !0,
                            styleList: ["right", "left", "top"]
                        },
                        flex: {
                            buryEvent: ["expose", "click"],
                            isShowDesc: !0,
                            styleList: ["right", "left", "top"]
                        },
                        links: {
                            buryEvent: ["expose", "click"],
                            buttonForceArrow: "enable",
                            buttonType: "link",
                            isShowGoodsInfo: !0,
                            styleList: ["right", "left", "top"]
                        },
                        default: {
                            isTipsBefore: !0,
                            buryEvent: ["view_item_list", "select_item"],
                            buttonForceArrow: void 0,
                            isShowGoodsInfo: !0,
                            styleList: ["right", "left", "top"]
                        }
                    },
                    Y = G[F] || G.default,
                    V = "event" === F && "image" === A;
                return a.createElement("div", {
                    className: l((t = {}, t["".concat(M)] = !0, t["".concat(M, "--").concat(C)] = !!C, t["".concat(M, "--").concat(Y.styleList[w - 1])] = !!w, t["".concat(M, "--").concat(j)] = !!j, t["".concat(M, "--").concat(F)] = !!F, t["".concat(M, "--has-link")] = !!(null === (r = null == L ? void 0 : L[0]) || void 0 === r ? void 0 : r.gotoUrl), t)),
                    "data-ot-expose": JSON.stringify({
                        event: Y.buryEvent[0],
                        tip: {
                            c: W
                        },
                        link: "".concat(null === (p = L[0]) || void 0 === p ? void 0 : p.gotoUrl),
                        elementName: "".concat(null === (g = L[0]) || void 0 === g ? void 0 : g.text),
                        elementTitle: "".concat(x)
                    }),
                    role: "button",
                    tabIndex: -1,
                    onClick: function(e) {
                        var t, n, a, o;
                        e.stopPropagation(), (null === (t = null == L ? void 0 : L[0]) || void 0 === t ? void 0 : t.gotoUrl) && (B({
                            event: Y.buryEvent[1],
                            tip: {
                                c: W,
                                d: 1
                            },
                            link: "".concat(null === (n = null == L ? void 0 : L[0]) || void 0 === n ? void 0 : n.gotoUrl),
                            elementName: "".concat(null === (a = null == L ? void 0 : L[0]) || void 0 === a ? void 0 : a.text),
                            elementTitle: "".concat(x)
                        }), (0, v.MN)("".concat(null === (o = null == L ? void 0 : L[0]) || void 0 === o ? void 0 : o.gotoUrl)))
                    }
                }, !!U.length && a.createElement(i.t, {
                    className: "".concat(M, "__image"),
                    alt: (null === (_ = U[0]) || void 0 === _ ? void 0 : _.alt) || x || "",
                    srcSet: (null === (b = U[0]) || void 0 === b ? void 0 : b.src) || []
                }), Y.isShowGoodsInfo && !V && a.createElement("div", {
                    className: "".concat(M, "__info")
                }, !!O && Y.isTipsBefore && a.createElement("h6", {
                    className: "".concat(M, "__tips")
                }, O), x && a.createElement(f, {
                    title: x,
                    isEvent: "event" === F,
                    basicClassName: M,
                    alt: (null === (y = U[0]) || void 0 === y ? void 0 : y.alt) || S
                }), !!O && !Y.isTipsBefore && a.createElement("h6", {
                    className: "".concat(M, "__tips")
                }, O), !!S && a.createElement("h4", {
                    className: "".concat(M, "__subtitle")
                }, S), a.createElement(c.Y, {
                    className: "".concat(M, "__energy"),
                    theme: C,
                    energyInfo: null === (E = null == P ? void 0 : P[0]) || void 0 === E ? void 0 : E.energyInfo
                }), !!Array.from(P || []).length && a.createElement(s.n, {
                    className: "".concat(M, "__price"),
                    salePrice: String(null === (h = P[0]) || void 0 === h ? void 0 : h.salePrice),
                    delPrice: String(null === (N = P[0]) || void 0 === N ? void 0 : N.originPrice),
                    isShowFrom: !(null === (k = P[0]) || void 0 === k ? void 0 : k.salePriceIsEQ),
                    isShowBlank: R || !J
                }), "links" !== F && a.createElement("div", {
                    className: l("".concat(M, "__actions"), (n = {}, n["".concat(M, "__actions--margin")] = !Array.from(P || []).length, n["".concat(M, "__actions--hide")] = !!(null == D ? void 0 : D.hideButtons), n))
                }, L.filter((function(e) {
                    return e.text && e.gotoUrl
                })).map((function(e, t, n) {
                    return a.createElement(u.z, {
                        key: t,
                        className: "".concat(M, "__link"),
                        withArrow: Y.buttonForceArrow || (t !== n.length - 1 ? "pc-only" : "disable"),
                        btnTheme: C,
                        btnType: Y.buttonType || (t !== n.length - 1 ? "link-default" : "primary"),
                        href: e.gotoUrl,
                        onClick: function(n) {
                            n.stopPropagation(), B({
                                event: Y.buryEvent[1],
                                tip: {
                                    c: W,
                                    d: t + 1
                                },
                                link: "".concat(e.gotoUrl),
                                elementName: "".concat(e.text),
                                elementTitle: "".concat(x)
                            })
                        }
                    }, e.text)
                })))), "links" === F && a.createElement("div", {
                    className: l("site-banner ".concat(M, "--lead"))
                }, a.createElement("div", {
                    className: "".concat(M, "__info")
                }, a.createElement("div", {
                    className: l("".concat(M, "__actions"), (o = {}, o["".concat(M, "__actions--margin")] = !Array.from(P || []).length, o)),
                    style: {
                        justifyContent: "normal"
                    }
                }, L.filter((function(e) {
                    return e.text && e.gotoUrl
                })).map((function(e, t, n) {
                    return a.createElement(u.z, {
                        key: t,
                        className: "".concat(M, "__link"),
                        withArrow: Y.buttonForceArrow || (t !== n.length - 1 ? "pc-only" : "disable"),
                        btnTheme: C,
                        btnType: Y.buttonType || (t !== n.length - 1 ? "link-default" : "primary"),
                        href: e.gotoUrl,
                        onClick: function(n) {
                            n.stopPropagation(), B({
                                event: Y.buryEvent[1],
                                tip: {
                                    c: W,
                                    d: t + 1
                                },
                                link: "".concat(e.gotoUrl),
                                elementName: "".concat(e.text),
                                elementTitle: "".concat(x)
                            })
                        }
                    }, e.text)
                }))))), Y.isShowDesc && a.createElement("div", {
                    className: "".concat(M, "__info")
                }, !!x && a.createElement("h2", {
                    className: "".concat(M, "__title")
                }, x), !!S && a.createElement("p", {
                    className: "".concat(M, "__subtitle")
                }, S)))
            }
            var g = function() {
                return g = Object.assign || function(e) {
                    for (var t, n = 1, a = arguments.length; n < a; n++)
                        for (var o in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
                    return e
                }, g.apply(this, arguments)
            };

            function _(e) {
                return a.createElement(p, g({}, e, {
                    bannerType: "normal"
                }))
            }
            var b = function() {
                return b = Object.assign || function(e) {
                    for (var t, n = 1, a = arguments.length; n < a; n++)
                        for (var o in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
                    return e
                }, b.apply(this, arguments)
            };

            function y(e) {
                return a.createElement(p, b({}, e, {
                    goods: [],
                    bannerType: "event"
                }))
            }
            var E = function() {
                return E = Object.assign || function(e) {
                    for (var t, n = 1, a = arguments.length; n < a; n++)
                        for (var o in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
                    return e
                }, E.apply(this, arguments)
            };

            function h(e) {
                return a.createElement(p, E({}, e, {
                    type: "default",
                    goods: [],
                    bannerType: "panorama"
                }))
            }
            var N = n(59696),
                k = n(39508),
                x = function() {
                    return x = Object.assign || function(e) {
                        for (var t, n = 1, a = arguments.length; n < a; n++)
                            for (var o in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
                        return e
                    }, x.apply(this, arguments)
                };

            function S(e) {
                var t, n, o, r = e.title,
                    i = e.subtitle,
                    c = e.buttons,
                    s = e.classModify,
                    m = e.otClick,
                    d = e.otModule,
                    v = e.hashtags,
                    f = void 0 === v ? [] : v,
                    p = ["view_promotion", "select_promotion"],
                    g = (0, k.r)("moe"),
                    _ = "true" === (null !== N.yv && void 0 !== N.yv ? N.yv : g),
                    b = {
                        categoryId: (null == (o = e.extends) ? void 0 : o.catId) || "",
                        categoryName: (null == o ? void 0 : o.title) || "",
                        parentCategoryId: (null == o ? void 0 : o.parentCatId) || "",
                        parentCategoryName: (null == o ? void 0 : o.parentCatTitle) || ""
                    };
                return a.createElement("section", {
                    className: l((t = {
                        "banner-text": !0
                    }, t["banner-text--".concat(s)] = !!s, t)),
                    "data-ot-expose": JSON.stringify(x(x({
                        event: p[0],
                        tip: {
                            c: d
                        },
                        link: "".concat(null === (n = null == c ? void 0 : c[0]) || void 0 === n ? void 0 : n.gotoUrl)
                    }, b), {
                        moeEnable: _
                    }))
                }, f.map((function(e, t) {
                    return a.createElement("a", {
                        key: "".concat(e, "-").concat(t),
                        id: e,
                        style: {
                            top: "calc(-1 * var(--header-height))",
                            display: "block",
                            position: "absolute",
                            visibility: "hidden",
                            height: "0",
                            zIndex: "-10"
                        },
                        "aria-hidden": !0
                    })
                })), a.createElement("div", {
                    className: "banner-text__info"
                }, a.createElement("span", {
                    className: "banner-text__title"
                }, r), !!i && a.createElement("span", {
                    className: "banner-text__subtitle"
                }, i), a.createElement("div", {
                    className: "banner-text__actions"
                }, c.filter((function(e) {
                    return e.text && e.gotoUrl
                })).map((function(e, t) {
                    return a.createElement(u.z, {
                        key: t,
                        className: "banner-text__link",
                        highlight: "m-only",
                        withArrow: "m-only",
                        btnType: "primary-link",
                        href: e.gotoUrl,
                        onClick: function() {
                            return m({
                                event: p[1],
                                tip: {
                                    c: d,
                                    d: t + 1
                                },
                                link: "".concat(e.gotoUrl),
                                elementName: "".concat(e.text)
                            })
                        }
                    }, e.text)
                })))))
            }
            var w = n(62711),
                C = n(56024),
                T = n(41959),
                O = function(e, t) {
                    var n = "function" == typeof Symbol && e[Symbol.iterator];
                    if (!n) return e;
                    var a, o, l = n.call(e),
                        r = [];
                    try {
                        for (;
                            (void 0 === t || t-- > 0) && !(a = l.next()).done;) r.push(a.value)
                    } catch (i) {
                        o = {
                            error: i
                        }
                    } finally {
                        try {
                            a && !a.done && (n = l.return) && n.call(l)
                        } finally {
                            if (o) throw o.error
                        }
                    }
                    return r
                };

            function I(e) {
                var t, n, r, i, c = (0, C.a)(),
                    s = (0, o.k6)(),
                    u = (0, d.oW)(),
                    m = (0, o.UO)(),
                    v = (0, a.useRef)(null),
                    f = O((0, a.useState)(0), 2),
                    p = f[0],
                    g = f[1],
                    _ = O((0, a.useState)(!1), 2),
                    b = _[0],
                    y = _[1],
                    E = O((0, a.useState)(!1), 2),
                    h = E[0],
                    N = E[1],
                    k = e.type,
                    x = e.siftList,
                    S = e.classModify,
                    I = e.otClick,
                    M = e.otModule,
                    U = k || "phone",
                    P = O((0, a.useState)(m.phone || (null === (n = x[0]) || void 0 === n ? void 0 : n.path)), 2),
                    A = P[0],
                    L = P[1],
                    D = O((0, a.useState)(m.tag || (null === (i = null === (r = x[0]) || void 0 === r ? void 0 : r.children[0]) || void 0 === i ? void 0 : i.path)), 2),
                    F = D[0],
                    j = D[1],
                    z = O((0, a.useState)(!1), 2),
                    q = z[0],
                    B = z[1],
                    W = function(e) {
                        var t;
                        return (null === (t = x.filter((function(t) {
                            return t.path === e
                        }))[0]) || void 0 === t ? void 0 : t.children) || []
                    },
                    R = function(e) {
                        var t;
                        return (null === (t = x.filter((function(t) {
                            return t.path === e
                        }))[0]) || void 0 === t ? void 0 : t.title) || ""
                    },
                    J = function(e, t, n) {
                        "".concat(A, "/").concat(F) !== "".concat(e, "/").concat(t) && (j(t), s.push(G(e, t)), I({
                            tip: {
                                c: M,
                                d: n
                            },
                            link: "".concat(u.wwwSite.pc, "/").concat(U, "/").concat(G(e, t)),
                            elementTitle: "".concat(R(e)),
                            elementName: "".concat(t)
                        }))
                    };

                function G(e, t) {
                    return "/".concat(U, "/").concat(e, "/").concat(t)
                }
                var Y = function() {
                        if (v.current && v.current.clientWidth < v.current.scrollWidth) {
                            N(!0);
                            var e = document.getElementById(m.tag);
                            null == e || e.scrollIntoView({
                                behavior: "smooth",
                                block: "center",
                                inline: "center"
                            }), g(1)
                        } else N(!1)
                    },
                    V = (0, T.N)(Y, 150, []);
                (0, a.useEffect)((function() {
                    if (m.tag) return window.addEventListener("resize", V),
                        function() {
                            window.removeEventListener("resize", V)
                        };
                    s.replace("/phone")
                }), []), (0, a.useEffect)((function() {
                    Y()
                }), [A]);
                var Z = function(e) {
                    0 === p && e > 0 || b && e < 0 || v.current && (v.current.scrollLeft -= e, g(v.current.scrollLeft), y(v.current.scrollLeft === p))
                };
                return a.createElement("div", {
                    className: l((t = {
                        "banner-select-site": !0
                    }, t["site-text--".concat(S)] = !!S, t)),
                    "data-ot-expose": JSON.stringify({
                        tip: {
                            c: M
                        }
                    })
                }, a.createElement("div", {
                    className: "banner-select__series"
                }, a.createElement("span", {
                    className: "banner-select__title",
                    onClick: function() {
                        B(!q)
                    },
                    role: "button",
                    tabIndex: 0
                }, R(A), x.length > 1 && "mobile" === c && q && a.createElement(w.q, {
                    symbol: "up",
                    className: "banner-select__title-arrow-up--mobile"
                }), x.length > 1 && "mobile" === c && !q && a.createElement(w.q, {
                    symbol: "down",
                    className: "banner-select__title-arrow-down--mobile"
                }), x.length > 1 && "mobile" !== c && a.createElement(w.q, {
                    symbol: "up",
                    className: "banner-select__title-arrow-up"
                }), x.length > 1 && "mobile" !== c && a.createElement(w.q, {
                    symbol: "down",
                    className: "banner-select__title-arrow-down"
                })), x.length > 1 && a.createElement("ul", {
                    role: "tree",
                    style: q ? {
                        display: "block"
                    } : {},
                    className: l({
                        "banner-select--hover": !0,
                        "banner-select--hover-mobile": "mobile" === c,
                        "banner-select--hover-pc": "mobile" !== c
                    })
                }, x.map((function(e) {
                    return a.createElement("li", {
                        key: e.path,
                        className: l({
                            "banner-select--li": !0,
                            "li--active": e.path === A
                        }),
                        onClick: function() {
                            return function(e) {
                                var t, n = null === (t = W(e)[0]) || void 0 === t ? void 0 : t.path;
                                L(e), J(e, n, 1), B(!1)
                            }(e.path)
                        },
                        role: "button",
                        tabIndex: 0
                    }, e.title)
                })))), W(A).length > 1 && a.createElement("div", {
                    className: "banner-select__tags"
                }, a.createElement("div", {
                    className: l({
                        "banner-select__tags-box": "mobile" !== c
                    })
                }, h && a.createElement(w.q, {
                    className: l({
                        "tags__left-icon": !0,
                        "tags__left-icon--disabled": 0 === p
                    }),
                    symbol: "fill-arrow-left",
                    onClick: function() {
                        return Z(50)
                    }
                }), a.createElement("ul", {
                    ref: v,
                    role: "tree",
                    className: l({
                        "banner-select__tags-ul": "mobile" !== c,
                        "banner-select__tags-ul--mobile": "mobile" === c
                    })
                }, W(A).map((function(e, t) {
                    return a.createElement("li", {
                        key: e.path,
                        id: e.path,
                        className: l({
                            "tags--normal": !0,
                            "tags--active": F === e.path
                        }),
                        onClick: function() {
                            return J(A, e.path, t + 1)
                        },
                        role: "button",
                        tabIndex: 0
                    }, e.title)
                }))), h && a.createElement(w.q, {
                    className: l({
                        "tags__right-icon": !0,
                        "tags__right-icon--disabled": b
                    }),
                    symbol: "fill-arrow-right",
                    onClick: function() {
                        return Z(-50)
                    }
                }))))
            }
            var M = n(58371);

            function U(e) {
                var t = e.title,
                    n = e.basicClassName,
                    o = void 0 === n ? "site-breadcrumbs" : n,
                    l = e.handleOtClick,
                    r = e.basicPage,
                    i = (0, d.YB)(),
                    c = (0, d.oW)(),
                    s = [{
                        text: i.get("fdb0c388de01d545017cdf9ccf00eb72"),
                        link: "".concat(c.wwwSite.pc, "/store"),
                        name: "store"
                    }];
                return a.createElement(M.O, {
                    className: "".concat(o, "__container site-container")
                }, Array.from(r || s || []).map((function(e, t) {
                    return a.createElement(M.O.Item, {
                        key: t
                    }, a.createElement("a", {
                        onClick: function() {
                            return l(e.text, e.link, e.name)
                        },
                        href: e.link
                    }, e.text))
                })), !!t && a.createElement(M.O.Item, null, t))
            }

            function P(e) {
                var t, n = e.title,
                    o = e.classModify,
                    r = e.otClick,
                    i = "site-breadcrumbs";
                return a.createElement("section", {
                    className: l((t = {}, t["".concat(i)] = !0, t["".concat(i, "--").concat(o)] = !!o, t))
                }, a.createElement(U, {
                    title: n,
                    handleOtClick: function(e, t, n) {
                        r({
                            tip: {
                                c: "breadcrumb",
                                d: 0
                            },
                            elementTitle: e,
                            elementName: n,
                            link: t
                        })
                    }
                }))
            }

            function A(e) {
                var t, n, o, r, s, m = e.title,
                    d = e.subtitle,
                    p = e.theme,
                    g = e.goods,
                    _ = e.images,
                    b = e.buttons,
                    y = e.classModify,
                    E = e.otClick,
                    h = e.otModule,
                    N = "site-goods",
                    k = ["view_item_list", "select_item"],
                    x = (0, a.useMemo)((function() {
                        return 1 === b.filter((function(e) {
                            return !!e.text && !!e.gotoUrl
                        })).length
                    }), []);
                return a.createElement("div", {
                    className: l((t = {}, t["".concat(N)] = !0, t["".concat(N, "--").concat(p)] = !!p, t["".concat(N, "--").concat(y)] = !!y, t)),
                    "data-ot-expose": JSON.stringify({
                        tip: {
                            c: h
                        },
                        event: k[0]
                    }),
                    role: "button",
                    tabIndex: -1,
                    onClick: function() {
                        var e, t, n, a;
                        (null === (e = null == b ? void 0 : b[0]) || void 0 === e ? void 0 : e.gotoUrl) && (E({
                            event: k[1],
                            tip: {
                                c: h,
                                d: 1
                            },
                            link: "".concat(null === (t = null == b ? void 0 : b[0]) || void 0 === t ? void 0 : t.gotoUrl),
                            elementName: "".concat(null === (n = null == b ? void 0 : b[0]) || void 0 === n ? void 0 : n.text)
                        }), (0, v.MN)("".concat(null === (a = null == b ? void 0 : b[0]) || void 0 === a ? void 0 : a.gotoUrl)))
                    }
                }, !!_.length && a.createElement(i.t, {
                    className: "".concat(N, "__image"),
                    alt: (null === (n = _[0]) || void 0 === n ? void 0 : n.alt) || m || "",
                    srcSet: (null === (o = _[0]) || void 0 === o ? void 0 : o.src) || []
                }), a.createElement("div", {
                    className: "".concat(N, "__info")
                }, a.createElement(f, {
                    title: m,
                    basicClassName: N,
                    alt: (null === (r = _[0]) || void 0 === r ? void 0 : r.alt) || d
                }), a.createElement("h4", {
                    className: "".concat(N, "__subtitle")
                }, d), a.createElement("div", {
                    className: "".concat(N, "__actions")
                }, b.filter((function(e) {
                    return e.text && e.gotoUrl
                })).map((function(e, t) {
                    return a.createElement(u.z, {
                        key: t,
                        className: "".concat(N, "__link"),
                        withArrow: "enable",
                        btnType: "link",
                        btnTheme: p,
                        highlight: x || 0 !== t ? "enable" : "disable",
                        href: e.gotoUrl,
                        onClick: function(n) {
                            n.stopPropagation(), E({
                                event: k[1],
                                tip: {
                                    c: h,
                                    d: t + 1
                                },
                                link: "".concat(e.gotoUrl),
                                elementName: "".concat(e.text)
                            })
                        }
                    }, e.text)
                })))), a.createElement(c.Y, {
                    className: "".concat(N, "__energy"),
                    useZoom: !0,
                    energyInfo: null === (s = null == g ? void 0 : g[0]) || void 0 === s ? void 0 : s.energyInfo
                }))
            }
            var L = n(39784);

            function D(e) {
                var t, n, o, r, f, p, g, _, b, y = e.title,
                    E = e.subtitle,
                    h = e.buttons,
                    N = e.goods,
                    k = e.images,
                    x = e.classModify,
                    S = e.skeletonData,
                    w = void 0 !== S && S,
                    T = e.isHidePrice,
                    O = void 0 !== T && T,
                    I = e.otClick,
                    M = e.otModule,
                    U = (0, d.YB)(),
                    P = (0, C.a)(),
                    A = (0, d.Sz)(),
                    D = "site-goods-sku",
                    F = (0, a.useMemo)((function() {
                        return "mobile" === P
                    }), [P]),
                    j = ["view_item_list", "select_item"],
                    z = (0, a.useContext)(m.__).getServiceSuccess || w;
                return a.createElement("div", {
                    className: l((t = {}, t["".concat(D)] = !0, t["".concat(D, "--").concat(x)] = !!x, t)),
                    "data-ot-expose": JSON.stringify({
                        event: j[0],
                        tip: {
                            c: M
                        },
                        link: "".concat(null === (n = null == h ? void 0 : h[0]) || void 0 === n ? void 0 : n.gotoUrl)
                    }),
                    role: "button",
                    tabIndex: -1,
                    onClick: function() {
                        var e, t, n, a;
                        (null === (e = null == h ? void 0 : h[0]) || void 0 === e ? void 0 : e.gotoUrl) && (I({
                            event: j[1],
                            tip: {
                                c: M,
                                d: 1
                            },
                            link: "".concat(null === (t = null == h ? void 0 : h[0]) || void 0 === t ? void 0 : t.gotoUrl),
                            elementName: "".concat(null === (n = null == h ? void 0 : h[0]) || void 0 === n ? void 0 : n.text)
                        }), (0, v.MN)("".concat(null === (a = null == h ? void 0 : h[0]) || void 0 === a ? void 0 : a.gotoUrl)))
                    }
                }, a.createElement("div", {
                    className: "".concat(D, "__info")
                }, a.createElement("h2", {
                    className: "".concat(D, "__title")
                }, y), a.createElement("h4", {
                    className: "".concat(D, "__subtitle")
                }, E), a.createElement(c.Y, {
                    className: "".concat(D, "__energy"),
                    useZoom: !1,
                    energyInfo: null === (o = null == N ? void 0 : N[0]) || void 0 === o ? void 0 : o.energyInfo
                }), a.createElement("ul", {
                    className: "".concat(D, "__tag-list")
                }, Array.from((null === (r = N[0]) || void 0 === r ? void 0 : r.tags) || []).map((function(e, t) {
                    return 1 - +e.text == 1 || 1 - +e.text == 0 ? a.createElement(a.Fragment, {
                        key: t
                    }) : a.createElement(L.V, {
                        key: t,
                        color: "orange",
                        tagName: "li",
                        className: "".concat(D, "__tag-item")
                    }, U.get("aa22b85761116cefd4ec0145550a64e2", {
                        discount: +e.text
                    }))
                }))), !O && !!Array.from(N || []).length && a.createElement(s.n, {
                    className: "".concat(D, "__price"),
                    salePrice: String(null === (f = N[0]) || void 0 === f ? void 0 : f.salePrice),
                    delPrice: String(null === (p = N[0]) || void 0 === p ? void 0 : p.originPrice),
                    isShowFrom: !(null === (g = N[0]) || void 0 === g ? void 0 : g.salePriceIsEQ),
                    isShowBlank: A || !z
                })), "quarter" === x && F ? a.createElement(a.Fragment, null) : a.createElement("div", {
                    className: "".concat(D, "__actions")
                }, h.map((function(e, t, n) {
                    var o, l, r = 0 !== t && (!!(null === (o = null == N ? void 0 : N[0]) || void 0 === o ? void 0 : o.isOutOfStock) || A),
                        i = A || !z;
                    return e.gotoUrl ? a.createElement(u.z, {
                        key: t,
                        className: "".concat(D, "__link"),
                        withArrow: "m-only",
                        highlight: 0 !== t ? r ? "disable" : "m-only" : "disable",
                        btnType: n.filter((function(e) {
                            return e.gotoUrl
                        })).length > 1 && 0 === t || r ? "default-link" : "primary-link",
                        disabled: r,
                        href: r ? void 0 : e.gotoUrl,
                        onClick: function(n) {
                            n.stopPropagation(), I({
                                event: j[1],
                                tip: {
                                    c: M,
                                    d: t + 1
                                },
                                link: "".concat(e.gotoUrl),
                                elementName: "".concat(e.text)
                            })
                        }
                    }, 0 === t ? U.get("f5395c9793af8a11b406ca7c1ac70da9") : i ? U.get("8524de963f07201e5c086830d370797f") : (null === (l = null == N ? void 0 : N[0]) || void 0 === l ? void 0 : l.isOutOfStock) ? U.get("b55197a49e8c4cd8c314bc2aa39d6feb") : U.get("eeceac1af4e7620894d6d2083921bb73")) : a.createElement(a.Fragment, {
                        key: t
                    })
                }))), a.createElement("div", {
                    className: "".concat(D, "__image")
                }, !!k.length && a.createElement(i.t, {
                    className: "".concat(D, "__picture"),
                    alt: (null === (_ = k[0]) || void 0 === _ ? void 0 : _.alt) || y || "",
                    srcSet: (null === (b = k[0]) || void 0 === b ? void 0 : b.src) || []
                })))
            }
            var F = function() {
                return F = Object.assign || function(e) {
                    for (var t, n = 1, a = arguments.length; n < a; n++)
                        for (var o in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
                    return e
                }, F.apply(this, arguments)
            };

            function j(e) {
                return a.createElement(D, F({}, e, {
                    isHidePrice: !0
                }))
            }

            function z(e) {
                var t, n, o, r = e.title,
                    c = e.subtitle,
                    s = e.buttons,
                    m = e.images,
                    d = e.classModify,
                    f = e.otClick,
                    p = e.otModule,
                    g = e.theme,
                    _ = ["view_promotion", "select_promotion"];
                return a.createElement("section", {
                    className: l((t = {
                        "site-event": !0
                    }, t["site-event--".concat(d)] = !!d, t["site-event--".concat(g)] = !!g, t)),
                    "data-ot-expose": JSON.stringify({
                        tip: {
                            c: p
                        },
                        event: _[0]
                    }),
                    role: "button",
                    tabIndex: -1,
                    onClick: function() {
                        var e, t, n, a;
                        (null === (e = null == s ? void 0 : s[0]) || void 0 === e ? void 0 : e.gotoUrl) && (f({
                            event: _[1],
                            tip: {
                                c: p,
                                d: 1
                            },
                            link: "".concat(null === (t = null == s ? void 0 : s[0]) || void 0 === t ? void 0 : t.gotoUrl),
                            elementName: "".concat(null === (n = null == s ? void 0 : s[0]) || void 0 === n ? void 0 : n.text)
                        }), (0, v.MN)("".concat(null === (a = null == s ? void 0 : s[0]) || void 0 === a ? void 0 : a.gotoUrl)))
                    }
                }, !!m.length && a.createElement(i.t, {
                    className: "site-event__image",
                    alt: (null === (n = m[0]) || void 0 === n ? void 0 : n.alt) || r || "",
                    srcSet: (null === (o = m[0]) || void 0 === o ? void 0 : o.src) || []
                }), a.createElement("div", {
                    className: "site-event__info"
                }, a.createElement("span", {
                    className: "site-event__title"
                }, r), a.createElement("span", {
                    className: "site-event__subtitle"
                }, c), a.createElement("div", {
                    className: "site-event_actions"
                }, s.filter((function(e) {
                    return e.text && e.gotoUrl
                })).map((function(e, t) {
                    return a.createElement(u.z, {
                        key: t,
                        className: "site-event__link",
                        withArrow: "enable",
                        btnType: "link",
                        highlight: "enable",
                        href: e.gotoUrl,
                        onClick: function(n) {
                            n.stopPropagation(), f({
                                event: _[1],
                                tip: {
                                    c: p,
                                    d: t + 1
                                },
                                link: "".concat(e.gotoUrl),
                                elementName: "".concat(e.text)
                            })
                        }
                    }, e.text)
                })))))
            }
            var q = n(30833),
                B = n(37133),
                W = n(50209),
                R = n(98661),
                J = n(43769),
                G = function() {
                    return G = Object.assign || function(e) {
                        for (var t, n = 1, a = arguments.length; n < a; n++)
                            for (var o in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
                        return e
                    }, G.apply(this, arguments)
                },
                Y = function(e, t) {
                    var n = "function" == typeof Symbol && e[Symbol.iterator];
                    if (!n) return e;
                    var a, o, l = n.call(e),
                        r = [];
                    try {
                        for (;
                            (void 0 === t || t-- > 0) && !(a = l.next()).done;) r.push(a.value)
                    } catch (i) {
                        o = {
                            error: i
                        }
                    } finally {
                        try {
                            a && !a.done && (n = l.return) && n.call(l)
                        } finally {
                            if (o) throw o.error
                        }
                    }
                    return r
                };

            function V(e) {
                var t = (0, d.oW)();
                return a.createElement(J.C9, {
                    siteConfig: t
                }, a.createElement(Z, G({}, e)))
            }

            function Z(e) {
                var t, n, o, r, i, c, s, f, p, g, _, b, y, E, h, N = e.title,
                    k = e.subtitle,
                    x = e.buttons,
                    S = e.images,
                    w = e.classModify,
                    C = e.otClick,
                    T = e.otModule,
                    O = e.skeletonData,
                    I = ["view_item_list", "select_item"],
                    M = (0, d.YB)(),
                    U = (0, d.Sz)(),
                    P = (0, d.oW)(),
                    A = "".concat(P.wwwSite.pc, "/store/daily-picks"),
                    L = Y((0, a.useState)({
                        actId: 0,
                        actType: 0,
                        children: [],
                        endTime: 0,
                        startTime: 0,
                        serverTime: Math.floor(Date.now() / 1e3)
                    }), 2),
                    D = L[0],
                    F = L[1],
                    j = (0, a.useContext)(m.__),
                    z = (0, a.useContext)(J.$m);
                (0, a.useEffect)((function() {
                    (j.getServiceSuccess || O) && z.getService()
                }), [j.getServiceSuccess, O]), (0, a.useEffect)((function() {
                    "success" === z.ajaxStatus && z.data.length && W(Date.now() + 1e3)
                }), [z.ajaxStatus]);

                function W(e) {
                    var t = z.data.find((function(t) {
                        return 1 === t.actType && 1e3 * t.endTime > e
                    }));
                    F(t)
                }
                var R = {
                    event: I[0],
                    tip: {
                        c: T
                    },
                    link: "".concat(((null == D ? void 0 : D.actId) ? A : "") || (null === (o = x[0]) || void 0 === o ? void 0 : o.gotoUrl) || ""),
                    productId: "".concat((null === (c = null === (i = null === (r = null == D ? void 0 : D.children) || void 0 === r ? void 0 : r[0]) || void 0 === i ? void 0 : i.goodsIdList) || void 0 === c ? void 0 : c[0]) || ""),
                    promotionId: "".concat((null == D ? void 0 : D.actId) || ""),
                    elementName: "".concat((null == D ? void 0 : D.actId) || "")
                };
                return U || ["unsent", "loading"].includes(z.ajaxStatus) ? a.createElement("section", {
                    className: l((t = {
                        "daily-pick": !0
                    }, t["daily-pick--".concat(w)] = !!w, t)),
                    "data-ot-expose": JSON.stringify(R)
                }, a.createElement(q.a, {
                    type: "inner"
                })) : a.createElement("section", {
                    className: l((n = {
                        "daily-pick": !0
                    }, n["daily-pick--".concat(w)] = !!w, n)),
                    "data-ot-expose": JSON.stringify(R),
                    role: "button",
                    tabIndex: -1,
                    onClick: function() {
                        var e, t, n = ((null == D ? void 0 : D.actId) ? A : "") || (null === (e = x[0]) || void 0 === e ? void 0 : e.gotoUrl) || "";
                        n && (C({
                            event: I[1],
                            tip: {
                                c: T,
                                d: 1
                            },
                            link: "".concat(n),
                            promotionId: "".concat((null == D ? void 0 : D.actId) || ""),
                            elementName: "".concat(null === (t = null == x ? void 0 : x[0]) || void 0 === t ? void 0 : t.text)
                        }), (0, v.MN)("".concat(n)))
                    }
                }, a.createElement("div", {
                    className: "daily-pick__info"
                }, a.createElement("span", {
                    className: "daily-pick__title"
                }, (null == D ? void 0 : D.actId) ? M.get("c3f95f5cf46d67a0796f99ad9b56fcc1") : N), a.createElement(H, {
                    className: "daily-pick__count",
                    key: (null == D ? void 0 : D.endTime) || (null == D ? void 0 : D.startTime) || 0,
                    data: D,
                    description: k,
                    onCallback: function() {
                        W(Date.now() + 1e3)
                    }
                }), a.createElement("div", {
                    className: "daily-pick__actions"
                }, x.map((function(e, t) {
                    return a.createElement(u.z, {
                        key: t,
                        className: "daily-pick__link",
                        withArrow: "enable",
                        btnType: "link",
                        highlight: "enable",
                        href: ((null == D ? void 0 : D.actId) ? A : "") || e.gotoUrl,
                        onClick: function(n) {
                            var a, o, l;
                            n.stopPropagation(), C({
                                event: I[1],
                                tip: {
                                    c: T,
                                    d: t + 1
                                },
                                link: "".concat(((null == D ? void 0 : D.actId) ? A : "") || e.gotoUrl || ""),
                                productId: "".concat((null === (l = null === (o = null === (a = null == D ? void 0 : D.children) || void 0 === a ? void 0 : a[0]) || void 0 === o ? void 0 : o.goodsIdList) || void 0 === l ? void 0 : l[0]) || ""),
                                promotionId: "".concat((null == D ? void 0 : D.actId) || ""),
                                elementName: "".concat((null == D ? void 0 : D.actId) || "")
                            })
                        }
                    }, e.text)
                })))), a.createElement("div", {
                    className: "daily-pick__product"
                }, a.createElement("div", {
                    className: "daily-pick__image",
                    style: {
                        backgroundImage: "url(".concat((null === (f = null === (s = null == D ? void 0 : D.children) || void 0 === s ? void 0 : s[0]) || void 0 === f ? void 0 : f.imgUrl) || (null === (g = null === (p = S[0]) || void 0 === p ? void 0 : p.src) || void 0 === g ? void 0 : g.widescreen) || "")
                    }
                }, !!(null === (b = null === (_ = null == D ? void 0 : D.children) || void 0 === _ ? void 0 : _[0]) || void 0 === b ? void 0 : b.giftUrl) && a.createElement(B.$, {
                    className: "daily-pick__tag",
                    src: null === (E = null === (y = null == D ? void 0 : D.children) || void 0 === y ? void 0 : y[0]) || void 0 === E ? void 0 : E.giftUrl,
                    alt: null === (h = S[0]) || void 0 === h ? void 0 : h.alt,
                    borderWidth: 2,
                    borderColor: "#fff"
                }))))
            }

            function H(e) {
                var t = e.data,
                    n = e.description,
                    o = e.onCallback,
                    l = e.className,
                    r = void 0 === l ? "" : l,
                    i = (0, a.useMemo)((function() {
                        return Math.floor(Date.now() / 1e3)
                    }), []),
                    c = Number((null == t ? void 0 : t.endTime) || 0) - i,
                    s = c < 86400 ? c : 0;
                return s > 0 ? a.createElement(W.i, {
                    className: r,
                    time: s,
                    displayType: "icon",
                    dataType: "timeWithoutDays",
                    onFinish: function() {
                        return o()
                    }
                }) : a.createElement("span", {
                    className: "daily-pick__subtitle"
                }, (null == t ? void 0 : t.actId) ? a.createElement(a.Fragment, null, a.createElement(R.q, {
                    timestamp: 1e3 * Number(null == t ? void 0 : t.startTime),
                    showType: "onlyDateAbbrMD",
                    isLocaleTimezone: !0
                }), " ", a.createElement(R.q, {
                    timestamp: 1e3 * Number(null == t ? void 0 : t.startTime),
                    customizedFormat: "HH:mm",
                    isLocaleTimezone: !0
                }), " ", "-", " ", a.createElement(R.q, {
                    timestamp: 1e3 * Number(null == t ? void 0 : t.endTime),
                    customizedFormat: "HH:mm",
                    isLocaleTimezone: !0
                })) : n)
            }

            function Q(e) {
                var t, n = e.title,
                    o = e.buttons,
                    r = e.images,
                    i = e.classModify,
                    c = e.otClick,
                    s = e.otModule;
                return a.createElement("div", {
                    className: l((t = {
                        "site-text-a": !0
                    }, t["site-text-a--".concat(i)] = !!i, t)),
                    "data-ot-expose": JSON.stringify({
                        tip: {
                            c: s
                        }
                    })
                }, a.createElement("div", {
                    className: "site-text-a__title"
                }, n), a.createElement("div", {
                    className: "site-text-a__link"
                }, o.map((function(e, t) {
                    var n, o;
                    return a.createElement("div", {
                        className: "site-text-a__item",
                        key: t
                    }, a.createElement("img", {
                        className: "site-text-a__image",
                        src: null === (o = null === (n = r[t]) || void 0 === n ? void 0 : n.src) || void 0 === o ? void 0 : o.widescreen,
                        alt: e.text
                    }), a.createElement(u.z, {
                        className: "site-text-a__button",
                        withArrow: "enable",
                        btnType: "link",
                        href: e.gotoUrl,
                        onClick: function() {
                            return c({
                                tip: {
                                    c: s,
                                    d: t + 1
                                },
                                link: "".concat(e.gotoUrl),
                                elementName: "".concat(e.text)
                            })
                        }
                    }, e.text))
                }))))
            }

            function $(e) {
                var t, n, o = (0, C.a)(),
                    r = e.title,
                    i = e.subtitle,
                    c = e.buttons,
                    s = e.classModify,
                    m = e.otClick,
                    d = e.otModule;
                return a.createElement("div", {
                    className: l((t = {
                        "site-text": !0
                    }, t["site-text--".concat(s)] = !!s, t)),
                    "data-ot-expose": JSON.stringify({
                        tip: {
                            c: d
                        }
                    }),
                    role: "button",
                    tabIndex: 0,
                    onClick: function() {
                        var e, t;
                        return m({
                            tip: {
                                c: d,
                                d: 1
                            },
                            link: "".concat(null === (e = null == c ? void 0 : c[0]) || void 0 === e ? void 0 : e.gotoUrl),
                            elementName: "".concat(null === (t = null == c ? void 0 : c[0]) || void 0 === t ? void 0 : t.text)
                        })
                    }
                }, a.createElement("div", {
                    className: "site-text__title"
                }, r), "mobile" === o && a.createElement("div", {
                    className: "site-text__subtitle"
                }, i), a.createElement(u.z, {
                    className: "site-text__link",
                    withArrow: "enable",
                    btnType: "link",
                    href: c[0].gotoUrl,
                    onClick: function(e) {
                        e.stopPropagation(), m({
                            tip: {
                                c: d,
                                d: 1
                            },
                            link: "".concat(c[0].gotoUrl),
                            elementName: "".concat(c[0].text)
                        })
                    }
                }, "mobile" === o ? null === (n = c[0]) || void 0 === n ? void 0 : n.text : i))
            }

            function K(e) {
                var t, n, o = e.title,
                    r = e.buttons,
                    i = e.classModify,
                    c = e.otClick,
                    s = e.otModule,
                    m = "site-text-c",
                    d = ["view_promotion", "select_promotion"];
                return a.createElement("div", {
                    className: l((t = {}, t["".concat(m)] = !0, t["".concat(m, "--").concat(i)] = !!i, t)),
                    "data-ot-expose": JSON.stringify({
                        event: d[0],
                        tip: {
                            c: s
                        },
                        link: "".concat(null === (n = null == r ? void 0 : r[0]) || void 0 === n ? void 0 : n.gotoUrl)
                    }),
                    role: "link",
                    tabIndex: 0,
                    onClick: function() {
                        var e, t, n;
                        c({
                            event: d[1],
                            tip: {
                                c: s,
                                d: 1
                            },
                            link: "".concat(null === (e = null == r ? void 0 : r[0]) || void 0 === e ? void 0 : e.gotoUrl),
                            elementName: "".concat(null === (t = null == r ? void 0 : r[0]) || void 0 === t ? void 0 : t.text)
                        }), (0, v.MN)("".concat(null === (n = null == r ? void 0 : r[0]) || void 0 === n ? void 0 : n.gotoUrl))
                    }
                }, a.createElement("div", {
                    className: "".concat(m, "__title")
                }, o), a.createElement(u.z, {
                    className: "".concat(m, "__link"),
                    btnType: "link",
                    "aria-label": r[0].text || o,
                    href: r[0].gotoUrl,
                    onClick: function(e) {
                        e.stopPropagation(), c({
                            event: d[1],
                            tip: {
                                c: s,
                                d: 1
                            },
                            link: "".concat(r[0].gotoUrl),
                            elementName: "".concat(r[0].text)
                        })
                    }
                }, a.createElement(w.q, {
                    symbol: "view-more",
                    className: "".concat(m, "__icon")
                })))
            }
            var X = n(63845),
                ee = n(95186),
                te = n(86584),
                ne = n(7649),
                ae = n(52997),
                oe = n(64519),
                le = n(24002);

            function re(e) {
                var t, n = e.slides,
                    o = e.classModify,
                    r = e.otClick,
                    i = e.otModule,
                    c = (0, a.useRef)(null),
                    s = (0, a.useRef)(null);
                return a.createElement("div", {
                    className: l((t = {
                        "site-swiper": !0
                    }, t["site-swiper--".concat(o)] = !!o, t))
                }, a.createElement(oe.t, {
                    loop: !0,
                    speed: 600,
                    spaceBetween: 0,
                    slidesPerView: "auto",
                    effect: "fade",
                    fadeEffect: {
                        crossFade: !0
                    },
                    pagination: {
                        clickable: !0
                    },
                    autoplay: {
                        delay: 5e3,
                        disableOnInteraction: !1,
                        pauseOnMouseEnter: !0
                    },
                    simulateTouch: n.length > 1,
                    navigation: {
                        prevEl: c.current,
                        nextEl: s.current
                    }
                }, n.map((function(e, t) {
                    var n, o, l, c, s, m;
                    return e && a.createElement(le.o, {
                        key: t,
                        "data-ot-expose": JSON.stringify({
                            tip: {
                                c: i,
                                d: t + 1
                            },
                            link: "".concat(null === (n = e.buttons[0]) || void 0 === n ? void 0 : n.gotoUrl),
                            elementName: "".concat(null === (o = e.buttons[0]) || void 0 === o ? void 0 : o.text),
                            elementTitle: "".concat(e.title),
                            creativeSlot: t + 1
                        })
                    }, a.createElement("div", {
                        className: "site-swiper__slide",
                        role: "link",
                        tabIndex: 0,
                        onClick: function() {
                            var n, a, o, l;
                            (null === (n = e.buttons[0]) || void 0 === n ? void 0 : n.gotoUrl) && (r({
                                tip: {
                                    c: i,
                                    d: t + 1
                                },
                                link: "".concat(null === (a = e.buttons[0]) || void 0 === a ? void 0 : a.gotoUrl),
                                elementName: "".concat(null === (o = e.buttons[0]) || void 0 === o ? void 0 : o.text),
                                elementTitle: "".concat(e.title),
                                creativeSlot: t + 1
                            }), (0, v.MN)("".concat(null === (l = e.buttons[0]) || void 0 === l ? void 0 : l.gotoUrl)))
                        }
                    }, a.createElement("div", {
                        className: "site-swiper__slide-left"
                    }, a.createElement("img", {
                        className: "site-swiper__slide-left-img",
                        src: null === (c = null === (l = e.images[0]) || void 0 === l ? void 0 : l.src) || void 0 === c ? void 0 : c.widescreen,
                        alt: e.title
                    }), (null == e ? void 0 : e.playIcon) && a.createElement("img", {
                        className: "site-swiper__slide-left-icon",
                        src: "//i01.appmifile.com/webfile/globalimg/i18n/other/showPlayIcon.png",
                        alt: "Play Icon"
                    })), a.createElement("div", {
                        className: "site-swiper__slide-right"
                    }, a.createElement("div", {
                        className: "site-swiper__tag"
                    }, e.hashtags[0]), a.createElement("div", {
                        className: "site-swiper__title"
                    }, e.title), a.createElement("div", {
                        className: "site-swiper__subtitle"
                    }, e.subtitle), a.createElement("div", {
                        className: "site-swiper__operation"
                    }, a.createElement(u.z, {
                        className: "site-swiper__link",
                        withArrow: "enable",
                        btnType: "link",
                        href: null === (s = e.buttons[0]) || void 0 === s ? void 0 : s.gotoUrl,
                        onClick: function() {
                            var n, a;
                            return r({
                                tip: {
                                    c: i,
                                    d: t + 1
                                },
                                link: "".concat(null === (n = e.buttons[0]) || void 0 === n ? void 0 : n.gotoUrl),
                                elementName: "".concat(null === (a = e.buttons[0]) || void 0 === a ? void 0 : a.text),
                                elementTitle: "".concat(e.title),
                                creativeSlot: t + 1
                            })
                        }
                    }, null === (m = e.buttons[0]) || void 0 === m ? void 0 : m.text)))))
                })), a.createElement("div", {
                    className: "site-swiper__buttons"
                }, a.createElement("div", {
                    className: "site-swiper__button",
                    ref: c
                }, a.createElement(u.z, {
                    className: "site-swiper-left-icon",
                    btnType: "icon"
                }, a.createElement(w.q, {
                    symbol: "fill-arrow-left"
                }))), a.createElement("div", {
                    className: "site-swiper__button",
                    ref: s
                }, a.createElement(u.z, {
                    className: "site-swiper-right-icon",
                    btnType: "icon"
                }, a.createElement(w.q, {
                    symbol: "fill-arrow-right"
                }))))))
            }
            X.Z.use([ee.Z, te.Z, ne.Z, ae.Z]);
            var ie = function(e, t) {
                var n = "function" == typeof Symbol && e[Symbol.iterator];
                if (!n) return e;
                var a, o, l = n.call(e),
                    r = [];
                try {
                    for (;
                        (void 0 === t || t-- > 0) && !(a = l.next()).done;) r.push(a.value)
                } catch (i) {
                    o = {
                        error: i
                    }
                } finally {
                    try {
                        a && !a.done && (n = l.return) && n.call(l)
                    } finally {
                        if (o) throw o.error
                    }
                }
                return r
            };

            function ce(e) {
                var t = e.src,
                    n = e.isLoop,
                    o = void 0 === n || n,
                    l = e.muted,
                    r = void 0 === l || l,
                    i = e.poster,
                    c = e.isAutoplay,
                    s = void 0 === c || c,
                    u = e.isControls,
                    m = void 0 !== u && u,
                    d = e.playBtnImage,
                    v = e.className,
                    f = ie((0, a.useState)(!!d), 2),
                    p = f[0],
                    g = f[1],
                    _ = ie((0, a.useState)(m), 2),
                    b = _[0],
                    y = _[1],
                    E = (0, a.useRef)(null),
                    h = (0, C.a)();

                function N() {
                    var e;
                    null === (e = E.current) || void 0 === e || e.play(), g(!1), y(!0)
                }
                return a.createElement("section", {
                    className: "responsive-video ".concat(v || "")
                }, a.createElement("video", {
                    ref: E,
                    src: t,
                    muted: r,
                    autoPlay: s,
                    loop: o,
                    poster: "mobile" === h ? null == i ? void 0 : i.mobile : null == i ? void 0 : i.widescreen,
                    controls: b,
                    playsInline: !0
                }, a.createElement("track", {
                    kind: "captions",
                    src: ""
                })), p && a.createElement("img", {
                    className: "responsive-video__button",
                    src: d || "//i01.appmifile.com/webfile/globalimg/products/pc/mi11/play-btn.png",
                    onClick: N,
                    onKeyPress: N,
                    role: "button",
                    tabIndex: 0,
                    loading: "lazy",
                    alt: ""
                }))
            }
            var se;

            function ue(e) {
                var t, n, o, r, c, s, m, d, v = e.title,
                    f = e.buttons,
                    p = e.images,
                    g = e.videos,
                    _ = e.type,
                    b = e.classModify,
                    y = e.otClick,
                    E = e.otModule,
                    h = (_ === se[0] ? null === (n = null == p ? void 0 : p[0]) || void 0 === n ? void 0 : n.src.widescreen : null === (o = null == g ? void 0 : g[0]) || void 0 === o ? void 0 : o.url) || "",
                    N = ["view_promotion", "select_promotion"];
                return a.createElement("section", {
                    className: l((t = {
                        "site-video": !0
                    }, t["site-video--".concat(b)] = !!b, t)),
                    "data-ot-expose": JSON.stringify({
                        event: N[0],
                        tip: {
                            c: E
                        },
                        assetLink: h
                    })
                }, _ === se[0] ? a.createElement(i.t, {
                    className: "site-video__image",
                    alt: (null === (r = null == p ? void 0 : p[0]) || void 0 === r ? void 0 : r.alt) || v || "",
                    srcSet: (null === (c = null == p ? void 0 : p[0]) || void 0 === c ? void 0 : c.src) || []
                }) : a.createElement(ce, {
                    src: null === (s = null == g ? void 0 : g[0]) || void 0 === s ? void 0 : s.url,
                    poster: (null === (m = null == p ? void 0 : p[0]) || void 0 === m ? void 0 : m.src) || []
                }), a.createElement("div", {
                    className: "site-video__wrapper"
                }, a.createElement("div", {
                    className: "site-video__info"
                }, a.createElement("span", {
                    className: "site-video__title"
                }, v), a.createElement("div", {
                    className: "site-video_actions"
                }, f.filter((function(e) {
                    return e.text && e.gotoUrl
                })).map((function(e, t) {
                    return a.createElement(u.z, {
                        key: t,
                        className: "site-video__link",
                        btnType: "link",
                        withArrow: "enable",
                        href: e.gotoUrl,
                        onClick: function() {
                            return y({
                                event: N[1],
                                tip: {
                                    c: E,
                                    d: t + 1
                                },
                                link: "".concat(e.gotoUrl),
                                elementName: "".concat(e.text),
                                assetLink: h
                            })
                        }
                    }, e.text)
                }))), a.createElement("img", {
                    className: "site-video__icon",
                    src: "//i01.appmifile.com/webfile/globalimg/demo/site-video-icon.png",
                    alt: (null === (d = null == p ? void 0 : p[0]) || void 0 === d ? void 0 : d.alt) || v,
                    loading: "lazy"
                }))))
            }

            function me(e) {
                var t, n, o, r, i, c = e.subtitle,
                    s = e.buttons,
                    m = e.images,
                    d = e.otClick,
                    f = e.otModule,
                    p = "mobile" !== (0, C.a)();
                return a.createElement("section", {
                    className: l({
                        "site-service": !0,
                        "site-service--widescreen": p
                    }),
                    "data-ot-expose": JSON.stringify({
                        tip: {
                            c: f,
                            d: 1
                        },
                        link: "".concat(null === (t = null == s ? void 0 : s[0]) || void 0 === t ? void 0 : t.gotoUrl),
                        elementName: "".concat(null === (n = null == s ? void 0 : s[0]) || void 0 === n ? void 0 : n.text)
                    }),
                    role: "button",
                    tabIndex: 0,
                    onClick: function() {
                        var e, t, n, a;
                        (null === (e = null == s ? void 0 : s[0]) || void 0 === e ? void 0 : e.gotoUrl) && (d({
                            tip: {
                                c: f,
                                d: 1
                            },
                            link: "".concat(null === (t = null == s ? void 0 : s[0]) || void 0 === t ? void 0 : t.gotoUrl),
                            elementName: "".concat(null === (n = null == s ? void 0 : s[0]) || void 0 === n ? void 0 : n.text)
                        }), (0, v.MN)("".concat(null === (a = null == s ? void 0 : s[0]) || void 0 === a ? void 0 : a.gotoUrl)))
                    }
                }, a.createElement("div", {
                    className: "site-service__info"
                }, a.createElement("div", {
                    className: "site-service__title"
                }, s.filter((function(e) {
                    return e.text && e.gotoUrl
                })).map((function(e, t) {
                    return a.createElement(a.Fragment, {
                        key: t
                    }, a.createElement(u.z, {
                        className: "site-service__link",
                        btnType: "link",
                        href: e.gotoUrl,
                        withArrow: "pc-only",
                        onClick: function(n) {
                            n.stopPropagation(), d({
                                tip: {
                                    c: f,
                                    d: t + 1
                                },
                                link: "".concat(e.gotoUrl),
                                elementName: "".concat(e.text)
                            })
                        }
                    }, e.text))
                }))), !!c && a.createElement("span", {
                    className: "site-service__subtitle"
                }, c)), a.createElement("img", {
                    className: "site-service__image",
                    src: null === (r = null === (o = null == m ? void 0 : m[0]) || void 0 === o ? void 0 : o.src) || void 0 === r ? void 0 : r.widescreen,
                    alt: null === (i = null == m ? void 0 : m[0]) || void 0 === i ? void 0 : i.alt,
                    loading: "lazy"
                }))
            }! function(e) {
                e[e.images = 0] = "images", e[e.videos = 1] = "videos"
            }(se || (se = {}));
            var de = "site-entrance";

            function ve(e) {
                var t, n, o, r, i, c, s = e.subtitle,
                    m = e.buttons,
                    d = e.images,
                    v = e.otClick,
                    f = e.otModule,
                    p = "mobile" !== (0, C.a)();
                return a.createElement("section", {
                    className: l((t = {}, t[de] = !0, t["".concat(de, "--widescreen")] = p, t)),
                    "data-ot-expose": JSON.stringify({
                        tip: {
                            c: f
                        },
                        link: "".concat(null === (n = null == m ? void 0 : m[0]) || void 0 === n ? void 0 : n.gotoUrl),
                        elementName: "".concat(null === (o = null == m ? void 0 : m[0]) || void 0 === o ? void 0 : o.text)
                    })
                }, a.createElement("div", {
                    className: "".concat(de, "__info")
                }, a.createElement("div", {
                    className: "".concat(de, "__title")
                }, m.filter((function(e) {
                    return e.text && e.gotoUrl
                })).map((function(e, t) {
                    return a.createElement(a.Fragment, {
                        key: t
                    }, a.createElement(u.z, {
                        className: "".concat(de, "__link"),
                        btnType: "link",
                        href: e.gotoUrl,
                        onClick: function() {
                            return v({
                                tip: {
                                    c: f,
                                    d: 1
                                },
                                link: "".concat(e.gotoUrl),
                                elementName: "".concat(e.text)
                            })
                        }
                    }, e.text), p && a.createElement(w.q, {
                        symbol: "link-arrow"
                    }))
                }))), !!s && a.createElement("span", {
                    className: "".concat(de, "__subtitle")
                }, s)), a.createElement("img", {
                    className: "".concat(de, "__image"),
                    src: null === (i = null === (r = null == d ? void 0 : d[0]) || void 0 === r ? void 0 : r.src) || void 0 === i ? void 0 : i.widescreen,
                    alt: null === (c = null == d ? void 0 : d[0]) || void 0 === c ? void 0 : c.alt,
                    loading: "lazy"
                }))
            }
            var fe = "site-store-link-bar";

            function pe(e) {
                var t, n = e.buttons,
                    o = e.classModify,
                    r = e.extends,
                    i = e.otClick,
                    c = e.otModule,
                    s = "mobile" !== (0, C.a)();
                return a.createElement("section", {
                    className: l((t = {}, t["site-store-link-bar"] = !0, t["".concat(fe, "--").concat(o)] = !!o, t)),
                    "data-ot-expose": JSON.stringify({
                        tip: {
                            c
                        }
                    })
                }, a.createElement("div", {
                    className: "".concat(fe, "__link")
                }, n.map((function(e, t) {
                    return a.createElement("div", {
                        className: "".concat(fe, "__item"),
                        key: t
                    }, a.createElement(u.z, {
                        className: "".concat(fe, "__button"),
                        btnType: "link",
                        href: e.gotoUrl,
                        withArrow: "enable",
                        onClick: function() {
                            return i({
                                tip: {
                                    c,
                                    d: t
                                },
                                link: "".concat(e.gotoUrl),
                                elementName: "".concat(e.text)
                            })
                        }
                    }, e.text))
                }))), a.createElement("div", {
                    className: "".concat(fe, "__infos")
                }, Array.from(r.data || []).map((function(e, t) {
                    var n, o, r, u;
                    return a.createElement("div", {
                        className: "".concat(fe, "__info"),
                        key: "store-link-bar-".concat(t)
                    }, a.createElement("img", {
                        className: "".concat(fe, "__info-image"),
                        src: null === (r = null === (o = e.image) || void 0 === o ? void 0 : o.src) || void 0 === r ? void 0 : r.widescreen,
                        alt: null === (u = e.image) || void 0 === u ? void 0 : u.alt,
                        loading: "lazy"
                    }), a.createElement("article", {
                        className: "".concat(fe, "__info-text")
                    }, a.createElement("a", {
                        className: l("".concat(fe, "__info-title"), (n = {}, n["".concat(fe, "__info-title--link")] = !!e.link, n)),
                        onClick: function(n) {
                            return function(e, t, n) {
                                e.preventDefault();
                                var a = t.link,
                                    o = t.title;
                                a && (i({
                                    tip: {
                                        c,
                                        d: n + 1
                                    },
                                    link: a,
                                    elementName: o
                                }), (0, v.MN)(a))
                            }(n, e, t)
                        },
                        href: e.link,
                        tabIndex: 0
                    }, e.title), s && a.createElement("span", {
                        className: "".concat(fe, "__info-subtitle")
                    }, e.subTitle)))
                }))))
            }
            var ge = n(86690),
                _e = n(20786),
                be = function(e, t) {
                    var n = "function" == typeof Symbol && e[Symbol.iterator];
                    if (!n) return e;
                    var a, o, l = n.call(e),
                        r = [];
                    try {
                        for (;
                            (void 0 === t || t-- > 0) && !(a = l.next()).done;) r.push(a.value)
                    } catch (i) {
                        o = {
                            error: i
                        }
                    } finally {
                        try {
                            a && !a.done && (n = l.return) && n.call(l)
                        } finally {
                            if (o) throw o.error
                        }
                    }
                    return r
                };

            function ye(e) {
                var t, n = "site-more-operator",
                    o = e.title,
                    r = e.classModify,
                    i = e.otClick,
                    c = e.otModule,
                    s = e.extends,
                    u = void 0 === s ? [] : s,
                    m = e.images,
                    f = (0, d.YB)(),
                    p = be((0, a.useState)(!1), 2),
                    g = p[0],
                    _ = p[1],
                    b = be((0, a.useState)(""), 2),
                    y = b[0],
                    E = b[1];
                (0, a.useEffect)((function() {
                    g && (0, ge.otExpose)({
                        tip: {
                            c: "jump_pop",
                            d: 0,
                            e: 16756
                        },
                        elementName: "jump_pop",
                        link: y,
                        elementTitle: ""
                    })
                }), [g]);
                return a.createElement("section", {
                    className: l((t = {}, t[n] = !0, t["".concat(n, "--").concat(r)] = !!r, t)),
                    "data-ot-expose": JSON.stringify({
                        tip: {
                            c
                        }
                    })
                }, a.createElement("span", {
                    className: "".concat(n, "__title")
                }, o), a.createElement("div", {
                    className: "".concat(n, "__container")
                }, (null == m ? void 0 : m.length) && m.map((function(e, t) {
                    var o, l;
                    return e && (null === (o = u[t]) || void 0 === o ? void 0 : o.gotoUrl) && a.createElement("img", {
                        className: "".concat(n, "__image"),
                        key: "".concat(n, "-").concat(t),
                        onClick: function() {
                            var e;
                            ! function(e) {
                                i({
                                    tip: {
                                        c,
                                        d: 0
                                    },
                                    link: e,
                                    elementTitle: "",
                                    elementName: "more_operator"
                                }), E(e), _(!0)
                            }(null === (e = u[t]) || void 0 === e ? void 0 : e.gotoUrl)
                        },
                        src: null === (l = null == e ? void 0 : e.src) || void 0 === l ? void 0 : l.widescreen,
                        alt: null == e ? void 0 : e.alt,
                        loading: "lazy",
                        role: "link",
                        tabIndex: 0
                    })
                }))), a.createElement(_e.u, {
                    isModalShow: g,
                    closeModal: function() {
                        return _(!1)
                    },
                    isShowCloseIcon: !0,
                    confirmText: f.get("70d9be9b139893aa6c69b5e77e614311"),
                    cancelText: f.get("ea4788705e6873b424c65e91c2846b19"),
                    confirm: function() {
                        y && (i({
                            tip: {
                                c: "jump_pop",
                                d: 0
                            },
                            link: y,
                            elementTitle: "",
                            elementName: "confirm"
                        }), (0, v.MN)(y)), _(!1)
                    },
                    cancel: function() {
                        return _(!1)
                    }
                }, a.createElement("p", null, f.get("7577d3ade4b27ef13c575bdad8d3efad"))))
            }
            var Ee = function(e, t) {
                    var n = "function" == typeof Symbol && e[Symbol.iterator];
                    if (!n) return e;
                    var a, o, l = n.call(e),
                        r = [];
                    try {
                        for (;
                            (void 0 === t || t-- > 0) && !(a = l.next()).done;) r.push(a.value)
                    } catch (i) {
                        o = {
                            error: i
                        }
                    } finally {
                        try {
                            a && !a.done && (n = l.return) && n.call(l)
                        } finally {
                            if (o) throw o.error
                        }
                    }
                    return r
                },
                he = "site-carrier-product",
                Ne = "logo",
                ke = "see_more";

            function xe(e) {
                var t, n, o, r, i = e.extends,
                    c = e.classModify,
                    s = e.otClick,
                    u = e.otModule,
                    m = i || {},
                    v = m.carrier,
                    f = m.products,
                    p = (0, d.YB)(),
                    g = Ee((0, a.useState)(""), 2),
                    _ = g[0],
                    b = g[1],
                    y = Ee((0, a.useState)(!1), 2),
                    E = y[0],
                    h = y[1];
                (0, a.useEffect)((function() {
                    E && (0, ge.otExpose)({
                        tip: {
                            c: "jump_pop",
                            d: 0,
                            e: 16756
                        },
                        elementName: "jump_pop",
                        link: _,
                        elementTitle: ""
                    })
                }), [E]);
                var N = function(e, t) {
                    s({
                        tip: {
                            c: u,
                            d: 0,
                            e: 16719
                        },
                        elementTitle: "",
                        link: e,
                        elementName: t
                    }), b(e || ""), h(!0)
                };
                return a.createElement("section", {
                    className: l((t = {}, t["site-carrier-product"] = !0, t["".concat(he, "--").concat(c)] = !!c, t)),
                    "data-ot-expose": JSON.stringify({
                        tip: {
                            c: u
                        }
                    })
                }, a.createElement("img", {
                    className: "".concat(he, "__carrier"),
                    src: null === (o = null === (n = null == v ? void 0 : v.image) || void 0 === n ? void 0 : n.src) || void 0 === o ? void 0 : o.widescreen,
                    alt: null === (r = null == v ? void 0 : v.image) || void 0 === r ? void 0 : r.alt,
                    loading: "lazy",
                    onClick: function() {
                        return N(null == v ? void 0 : v.gotoUrl, Ne)
                    },
                    role: "link",
                    tabIndex: 0
                }), !!(null == f ? void 0 : f.length) && f.map((function(e, t) {
                    var n, o, l;
                    return a.createElement("div", {
                        key: "".concat(he, "-").concat(t),
                        className: "".concat(he, "__product")
                    }, a.createElement("article", {
                        className: "".concat(he, "__product-info")
                    }, a.createElement("h4", {
                        className: "".concat(he, "__product-name")
                    }, e.name), a.createElement("p", {
                        className: "".concat(he, "__product-desc"),
                        dangerouslySetInnerHTML: {
                            __html: e.desc
                        }
                    }), a.createElement("span", {
                        className: "".concat(he, "__product-button"),
                        onClick: function() {
                            return N(e.gotoUrl, ke)
                        },
                        role: "link",
                        tabIndex: 0
                    }, e.buttonText)), a.createElement("img", {
                        className: "".concat(he, "__product-image"),
                        src: null === (o = null === (n = e.image) || void 0 === n ? void 0 : n.src) || void 0 === o ? void 0 : o.widescreen,
                        alt: null === (l = e.image) || void 0 === l ? void 0 : l.alt,
                        loading: "lazy"
                    }))
                })), a.createElement(_e.u, {
                    isModalShow: E,
                    closeModal: function() {
                        return h(!1)
                    },
                    isShowCloseIcon: !0,
                    confirmText: p.get("70d9be9b139893aa6c69b5e77e614311"),
                    cancelText: p.get("ea4788705e6873b424c65e91c2846b19"),
                    confirm: function() {
                        _ && (s({
                            tip: {
                                c: "jump_pop",
                                d: 0,
                                e: 16719
                            },
                            link: _,
                            elementTitle: "",
                            elementName: "confirm"
                        }), window.open(_)), h(!1)
                    },
                    cancel: function() {
                        return h(!1)
                    }
                }, a.createElement("p", null, p.get("7577d3ade4b27ef13c575bdad8d3efad"))))
            }
            var Se = n(6658);

            function we(e) {
                var t, n = "store-partner-item",
                    o = "mobile" !== (0, C.a)(),
                    r = e.partnerInfoList,
                    i = e.partnerTypeDesc,
                    c = e.partnerTypeName,
                    s = e.onClick;
                return a.createElement("section", {
                    className: l((t = {}, t["".concat(n)] = !0, t["".concat(n, "--mobile")] = !o, t))
                }, a.createElement("h2", {
                    className: "".concat(n, "__title")
                }, c), a.createElement("p", {
                    className: "".concat(n, "__desc")
                }, i), !!(null == r ? void 0 : r.length) && a.createElement("div", {
                    className: "".concat(n, "__container")
                }, r.map((function(e, t) {
                    return a.createElement(a.Fragment, {
                        key: "".concat(n, "-").concat(t)
                    }, a.createElement("div", {
                        className: "".concat(n, "__item")
                    }, a.createElement("img", {
                        src: e.image,
                        alt: e.name,
                        loading: "lazy",
                        className: "".concat(n, "__image"),
                        onClick: function() {
                            return s(e.turnLink, t)
                        },
                        onKeyPress: function() {
                            return s(e.turnLink, t)
                        },
                        role: "button",
                        tabIndex: 0
                    }), a.createElement("p", {
                        className: "".concat(n, "__name")
                    }, e.name)))
                }))))
            }
            var Ce = function() {
                    return Ce = Object.assign || function(e) {
                        for (var t, n = 1, a = arguments.length; n < a; n++)
                            for (var o in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
                        return e
                    }, Ce.apply(this, arguments)
                },
                Te = function(e, t) {
                    var n = "function" == typeof Symbol && e[Symbol.iterator];
                    if (!n) return e;
                    var a, o, l = n.call(e),
                        r = [];
                    try {
                        for (;
                            (void 0 === t || t-- > 0) && !(a = l.next()).done;) r.push(a.value)
                    } catch (i) {
                        o = {
                            error: i
                        }
                    } finally {
                        try {
                            a && !a.done && (n = l.return) && n.call(l)
                        } finally {
                            if (o) throw o.error
                        }
                    }
                    return r
                },
                Oe = 2;

            function Ie(e) {
                var t = (0, d.oW)();
                return a.createElement(Se.J, {
                    siteConfig: t
                }, a.createElement(Me, Ce({}, e)))
            }

            function Me(e) {
                var t, n = e.classModify,
                    o = e.otClick,
                    r = e.skeletonData,
                    i = (0, a.useContext)(Se.N),
                    c = (0, d.YB)(),
                    s = "store-partner",
                    u = Te((0, a.useState)(""), 2),
                    m = u[0],
                    v = u[1],
                    f = Te((0, a.useState)(!1), 2),
                    p = f[0],
                    g = f[1];
                (0, a.useEffect)((function() {
                    !(null == r ? void 0 : r.length) && i.getService({
                        params: {
                            pageNum: 1,
                            pageSize: 1e3,
                            storeType: "1,2,3"
                        }
                    })
                }), []), (0, a.useEffect)((function() {
                    p && "function" == typeof ge.otExpose && (0, ge.otExpose)({
                        tip: {
                            c: "jump_pop",
                            d: 0,
                            e: 16756
                        },
                        elementName: "jump_pop",
                        link: m,
                        elementTitle: ""
                    })
                }), [p]);
                var _ = (0, a.useMemo)((function() {
                        var e;
                        return (r || (null === (e = i.data) || void 0 === e ? void 0 : e.partnerList) || []).filter((function(e) {
                            return e.type === Oe
                        }))
                    }), [i.ajaxStatus]),
                    b = function(e, t) {
                        v(e), g(!0)
                    };
                return a.createElement("section", {
                    className: l((t = {}, t["".concat(s)] = !0, t["".concat(s, "--").concat(n)] = !!n, t))
                }, !!(null == _ ? void 0 : _.length) && _.map((function(e, t) {
                    return a.createElement(we, Ce({
                        key: "".concat(s, "-").concat(t)
                    }, e, {
                        onClick: b
                    }))
                })), a.createElement(_e.u, {
                    isModalShow: p,
                    closeModal: function() {
                        return g(!1)
                    },
                    isShowCloseIcon: !0,
                    confirm: function() {
                        m && (o({
                            tip: {
                                c: "jump_pop",
                                d: 0,
                                e: 16719
                            },
                            link: m,
                            elementName: "confirm"
                        }), window.open(m)), g(!1)
                    },
                    cancel: function() {
                        return g(!1)
                    },
                    confirmText: c.get("70d9be9b139893aa6c69b5e77e614311"),
                    cancelText: c.get("ea4788705e6873b424c65e91c2846b19")
                }, a.createElement("p", null, c.get("7577d3ade4b27ef13c575bdad8d3efad"))))
            }

            function Ue(e) {
                var t, n = e.title,
                    o = e.classModify,
                    r = "store-breadcrumbs";
                return a.createElement("section", {
                    className: l((t = {}, t["".concat(r)] = !0, t["".concat(r, "--").concat(o)] = !!o, t))
                }, a.createElement("h4", {
                    className: "".concat(r, "__title")
                }, n))
            }
            var Pe = n(40666),
                Ae = n(37879);

            function Le(e) {
                var t = e.errorBoundaryClassName,
                    n = e.children,
                    o = e.fallback,
                    l = void 0 === o ? a.createElement(q.a, {
                        type: "inner"
                    }) : o,
                    r = (0, d.YB)();
                return (0, d.Sz)() ? l : a.createElement(Pe.S, {
                    renderDomCb: function() {
                        return a.createElement(Ae.Q, {
                            extClassNames: t,
                            errorMessage: r.get("a25c753ee3e4be15ec0daa5a40deb7b8"),
                            extraButtons: [{
                                type: "refresh"
                            }]
                        })
                    }
                }, a.createElement(a.Suspense, {
                    fallback: l
                }, n))
            }
            var De = function() {
                    return De = Object.assign || function(e) {
                        for (var t, n = 1, a = arguments.length; n < a; n++)
                            for (var o in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
                        return e
                    }, De.apply(this, arguments)
                },
                Fe = a.lazy((function() {
                    return Promise.all([n.e(8198), n.e(6236)]).then(n.bind(n, 86236))
                }));

            function je(e) {
                return a.createElement(Le, {
                    fallback: a.createElement(a.Fragment, null)
                }, a.createElement(Fe, De({}, e)))
            }
            var ze = n(27392),
                qe = n(89522);

            function Be(e) {
                var t = e.extends;
                return a.createElement("div", null, a.createElement(ze.h, {
                    cmsData: t
                }), a.createElement(qe.$, {
                    cmsData: t
                }))
            }

            function We(e) {
                var t, n, o, r, i, c, s = e.subtitle,
                    m = e.images,
                    d = e.buttons,
                    f = e.otClick,
                    p = e.otModule,
                    g = "mobile" === (0, C.a)();
                return a.createElement("section", {
                    className: l({
                        "store-carrier": !0,
                        "store-carrier--mobile": g
                    }),
                    "data-ot-expose": JSON.stringify({
                        tip: {
                            c: p
                        },
                        link: "".concat(null === (t = null == d ? void 0 : d[0]) || void 0 === t ? void 0 : t.gotoUrl)
                    }),
                    role: "button",
                    tabIndex: 0,
                    onClick: function() {
                        var e, t, n;
                        (null === (e = null == d ? void 0 : d[0]) || void 0 === e ? void 0 : e.gotoUrl) && (f({
                            tip: {
                                c: p,
                                d: 1
                            },
                            link: "".concat(null === (t = null == d ? void 0 : d[0]) || void 0 === t ? void 0 : t.gotoUrl)
                        }), (0, v.MN)("".concat(null === (n = null == d ? void 0 : d[0]) || void 0 === n ? void 0 : n.gotoUrl)))
                    }
                }, a.createElement("div", {
                    className: "store-carrier__wrapper"
                }, a.createElement("div", {
                    className: "store-carrier__info"
                }, a.createElement("div", {
                    className: "store-carrier__title"
                }, a.createElement(u.z, {
                    className: "store-carrier__link",
                    btnType: "link",
                    href: null === (n = null == d ? void 0 : d[0]) || void 0 === n ? void 0 : n.gotoUrl,
                    onClick: function(e) {
                        var t, n;
                        e.stopPropagation(), f({
                            tip: {
                                c: p,
                                d: 1
                            },
                            link: "".concat(null === (t = null == d ? void 0 : d[0]) || void 0 === t ? void 0 : t.gotoUrl),
                            elementName: "".concat(null === (n = null == d ? void 0 : d[0]) || void 0 === n ? void 0 : n.text)
                        })
                    }
                }, null === (o = null == d ? void 0 : d[0]) || void 0 === o ? void 0 : o.text)), !!s && a.createElement("span", {
                    className: "store-carrier__subtitle"
                }, s)), !g && a.createElement("img", {
                    className: "store-carrier__image",
                    src: null === (i = null === (r = null == m ? void 0 : m[0]) || void 0 === r ? void 0 : r.src) || void 0 === i ? void 0 : i.widescreen,
                    alt: null === (c = null == m ? void 0 : m[0]) || void 0 === c ? void 0 : c.alt,
                    loading: "lazy"
                })))
            }
            var Re = n(64457),
                Je = function() {
                    return Je = Object.assign || function(e) {
                        for (var t, n = 1, a = arguments.length; n < a; n++)
                            for (var o in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
                        return e
                    }, Je.apply(this, arguments)
                },
                Ge = function(e, t) {
                    var n = "function" == typeof Symbol && e[Symbol.iterator];
                    if (!n) return e;
                    var a, o, l = n.call(e),
                        r = [];
                    try {
                        for (;
                            (void 0 === t || t-- > 0) && !(a = l.next()).done;) r.push(a.value)
                    } catch (i) {
                        o = {
                            error: i
                        }
                    } finally {
                        try {
                            a && !a.done && (n = l.return) && n.call(l)
                        } finally {
                            if (o) throw o.error
                        }
                    }
                    return r
                };

            function Ye(e) {
                var t = (0, d.oW)();
                return a.createElement(Se.J, {
                    siteConfig: t
                }, a.createElement(Ve, Je({}, e)))
            }

            function Ve(e) {
                var t, n, o, r, c, s, f, p = e.buttons,
                    g = e.otClick,
                    _ = e.otExpose,
                    b = e.otModule,
                    y = e.skeletonData,
                    E = e.images,
                    h = (0, a.useContext)(m.__),
                    N = (0, a.useContext)(Se.N),
                    k = Ge((0, a.useState)(!1), 2),
                    x = k[0],
                    S = k[1],
                    w = "mobile" === (0, C.a)(),
                    T = (0, d.YB)(),
                    O = function(e) {
                        (null == y ? void 0 : y.storeTypeInfo) || N.getService({
                            params: {
                                lat: e.lat,
                                lon: e.lon,
                                pageNum: 1,
                                pageSize: 1,
                                storeType: "1,2,3"
                            }
                        })
                    },
                    I = function() {
                        var e;
                        (e = {
                            lat: 0,
                            lon: 0
                        }, new Promise((function(t) {
                            navigator.geolocation.getCurrentPosition((function(n) {
                                return e.lat = n.coords.latitude, e.lon = n.coords.longitude, t(e)
                            }))
                        }))).then((function(e) {
                            S(!!e.lat || !!e.lon), O(e)
                        }))
                    };
                (0, a.useEffect)((function() {
                    h.getServiceSuccess && (O({
                        lat: 0,
                        lon: 0
                    }), I())
                }), [h.getServiceSuccess]), (0, a.useEffect)((function() {
                    if (N.getServiceSuccess) {
                        var e = (0, ge.otExposeWith)({
                            isInfinite: !1,
                            exposeThreshold: .3,
                            targetNodeWrapper: document.querySelector(".store-shop"),
                            targetNodeSelector: "[data-ot-expose]"
                        }, (function(e, t) {
                            var n;
                            return "function" == typeof _ && _(e || {}, String((null === (n = null == e ? void 0 : e.tip) || void 0 === n ? void 0 : n.c) || ""))
                        }));
                        return function() {
                            e && e.disconnect()
                        }
                    }
                    return function() {
                        return null
                    }
                }), [N.getServiceSuccess]);
                var M = (null === (t = null == y ? void 0 : y.storeList) || void 0 === t ? void 0 : t[0]) || (null === (n = N.data.storeList) || void 0 === n ? void 0 : n[0]) || {},
                    U = function(e) {
                        var t, n;
                        return void 0 === e && (e = 0), {
                            tip: {
                                c: b,
                                d: e
                            },
                            elementTitle: null === (t = null == p ? void 0 : p[0]) || void 0 === t ? void 0 : t.text,
                            elementName: M.name,
                            link: "".concat(null === (n = null == p ? void 0 : p[0]) || void 0 === n ? void 0 : n.gotoUrl, "/detail/").concat(M.id)
                        }
                    };
                return a.createElement("section", {
                    className: l({
                        "store-shop": !0,
                        "store-shop--mobile": w
                    }),
                    "data-ot-expose": JSON.stringify(U())
                }, a.createElement("div", {
                    className: "store-shop__action"
                }, a.createElement(u.z, {
                    className: "store-shop__link",
                    withArrow: "enable",
                    btnType: "link",
                    href: null === (o = null == p ? void 0 : p[0]) || void 0 === o ? void 0 : o.gotoUrl,
                    onClick: function() {
                        var e, t, n, a;
                        (null === (e = null == p ? void 0 : p[0]) || void 0 === e ? void 0 : e.gotoUrl) && (g({
                            tip: {
                                c: b,
                                d: 0
                            },
                            link: "".concat(null === (t = null == p ? void 0 : p[0]) || void 0 === t ? void 0 : t.gotoUrl),
                            elementTitle: null === (n = null == p ? void 0 : p[0]) || void 0 === n ? void 0 : n.text,
                            elementName: "stores"
                        }), (0, v.MN)("".concat(null === (a = null == p ? void 0 : p[0]) || void 0 === a ? void 0 : a.gotoUrl)))
                    }
                }, null === (r = null == p ? void 0 : p[0]) || void 0 === r ? void 0 : r.text)), a.createElement("div", {
                    className: "store-shop__main",
                    role: "button",
                    tabIndex: 0,
                    onClick: function() {
                        var e, t;
                        (null === (e = null == p ? void 0 : p[0]) || void 0 === e ? void 0 : e.gotoUrl) && (g(U(1)), (0, v.MN)("".concat(null === (t = null == p ? void 0 : p[0]) || void 0 === t ? void 0 : t.gotoUrl, "/detail/").concat(M.id)))
                    }
                }, a.createElement(i.t, {
                    className: "store-shop__image",
                    alt: M.name || "",
                    srcSet: (null === (s = null === (c = null == E ? void 0 : E[0]) || void 0 === c ? void 0 : c.src) || void 0 === s ? void 0 : s.widescreen) ? null === (f = null == E ? void 0 : E[0]) || void 0 === f ? void 0 : f.src : {
                        widescreen: M.image
                    }
                }), a.createElement("div", {
                    className: "store-shop__info"
                }, M.name ? a.createElement(a.Fragment, null, a.createElement("span", {
                    className: "store-shop__title"
                }, M.name), !!M.address && a.createElement("span", {
                    className: "store-shop__desc"
                }, M.address), a.createElement("ul", {
                    className: "store-shop__tag"
                }, x && a.createElement(L.V, {
                    color: "orange",
                    tagName: "li"
                }, T.get("944ea1b95d0af5fe23ac45f9edae2197")), function() {
                    var e, t = (null == y ? void 0 : y.storeTypeInfo) || N.data.storeTypeInfo,
                        n = (null === (e = M.storeType) || void 0 === e ? void 0 : e.split(",")) || [];
                    return (x ? n.slice(0, 1) : n.slice(0, 2)).map((function(e) {
                        return !!t[+e] && a.createElement(L.V, {
                            key: e,
                            color: "orange",
                            tagName: "li"
                        }, t[+e])
                    }))
                }())) : a.createElement(q.a, {
                    type: "inner"
                }))))
            }
            var Ze = function() {
                    return Ze = Object.assign || function(e) {
                        for (var t, n = 1, a = arguments.length; n < a; n++)
                            for (var o in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
                        return e
                    }, Ze.apply(this, arguments)
                },
                He = a.lazy((function() {
                    return n.e(5265).then(n.bind(n, 65265))
                }));

            function Qe(e) {
                return a.createElement(Le, {
                    fallback: a.createElement(a.Fragment, null)
                }, a.createElement(He, Ze({}, e)))
            }
            var $e = ["start", "center", "end"];
            n(20172);

            function Ke(e) {
                var t, n = e.title,
                    o = e.style,
                    r = e.type,
                    i = e.otModule;
                return a.createElement("h2", {
                    className: l("store-title", (t = {}, t["store-title--".concat($e[o - 1] || "default")] = !!o, t["mi-".concat(r)] = !!r, t)),
                    "data-ot-expose": JSON.stringify({
                        tip: {
                            c: i
                        }
                    })
                }, n)
            }
            var Xe = n(86969);

            function et(e) {
                var t, n, o, r, c, s, m = e.title,
                    d = e.subtitle,
                    f = e.theme,
                    p = e.buttons,
                    g = e.extends,
                    _ = e.images,
                    b = e.classModify,
                    y = e.otClick,
                    E = e.otModule;
                return a.createElement("div", {
                    className: l((t = {
                        "site-store-event": !0
                    }, t["site-store-event--".concat(f)] = !!f, t["site-store-event--".concat(b)] = !!b, t)),
                    "data-ot-expose": JSON.stringify({
                        tip: {
                            c: E,
                            d: 0
                        },
                        link: "".concat(null === (o = null == p ? void 0 : p[0]) || void 0 === o ? void 0 : o.gotoUrl),
                        elementName: "".concat(null === (r = p[0]) || void 0 === r ? void 0 : r.text)
                    }),
                    role: "button",
                    tabIndex: -1,
                    onClick: function() {
                        var e, t, n, a;
                        (null === (e = null == p ? void 0 : p[0]) || void 0 === e ? void 0 : e.gotoUrl) && (y({
                            tip: {
                                c: E,
                                d: 1
                            },
                            link: "".concat(null === (t = null == p ? void 0 : p[0]) || void 0 === t ? void 0 : t.gotoUrl),
                            elementName: "".concat(null === (n = p[0]) || void 0 === n ? void 0 : n.text)
                        }), (0, v.MN)("".concat(null === (a = null == p ? void 0 : p[0]) || void 0 === a ? void 0 : a.gotoUrl)))
                    }
                }, !!_.length && a.createElement(i.t, {
                    className: "site-store-event__bg",
                    alt: (null === (c = _[0]) || void 0 === c ? void 0 : c.alt) || m || "",
                    srcSet: (null === (s = _[0]) || void 0 === s ? void 0 : s.src) || []
                }), a.createElement("div", {
                    className: "site-store-event__content"
                }, m && a.createElement("div", {
                    className: "site-store-event__title"
                }, m), d && a.createElement("div", {
                    className: "site-store-event__subtitle"
                }, d), a.createElement("div", {
                    className: l("site-store-event__actions", (n = {}, n["site-store-event__actions--hide"] = !!(null == g ? void 0 : g.hideButtons), n))
                }, p.filter((function(e) {
                    return e.text && e.gotoUrl
                })).map((function(e, t) {
                    return a.createElement(u.z, {
                        key: t,
                        btnType: "primary",
                        btnTheme: f,
                        className: "site-store-event__link",
                        href: (0, Xe.H)(e.gotoUrl),
                        onClick: function(n) {
                            n.stopPropagation(), y({
                                tip: {
                                    c: E,
                                    d: t + 1
                                },
                                link: "".concat(e.gotoUrl),
                                elementName: "".concat(e.text)
                            })
                        }
                    }, e.text)
                })))))
            }
            var tt = function() {
                    return tt = Object.assign || function(e) {
                        for (var t, n = 1, a = arguments.length; n < a; n++)
                            for (var o in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
                        return e
                    }, tt.apply(this, arguments)
                },
                nt = a.lazy((function() {
                    return n.e(6407).then(n.bind(n, 26407))
                }));

            function at(e) {
                return a.createElement(Le, {
                    fallback: a.createElement(a.Fragment, null)
                }, a.createElement(nt, tt({}, e)))
            }
            var ot = n(64342),
                lt = n(74825),
                rt = n(63438),
                it = n(55709),
                ct = function() {
                    return ct = Object.assign || function(e) {
                        for (var t, n = 1, a = arguments.length; n < a; n++)
                            for (var o in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
                        return e
                    }, ct.apply(this, arguments)
                },
                st = function(e, t) {
                    var n = "function" == typeof Symbol && e[Symbol.iterator];
                    if (!n) return e;
                    var a, o, l = n.call(e),
                        r = [];
                    try {
                        for (;
                            (void 0 === t || t-- > 0) && !(a = l.next()).done;) r.push(a.value)
                    } catch (i) {
                        o = {
                            error: i
                        }
                    } finally {
                        try {
                            a && !a.done && (n = l.return) && n.call(l)
                        } finally {
                            if (o) throw o.error
                        }
                    }
                    return r
                };

            function ut(e) {
                var t, n, o, l = (0, C.a)(),
                    r = st((0, a.useState)(0), 2),
                    i = r[0],
                    c = r[1],
                    s = (0, a.useRef)(),
                    m = "mobile" === l,
                    d = e.slides,
                    v = void 0 === d ? [] : d,
                    f = e.skeletonData,
                    g = void 0 !== f && f,
                    _ = e.otClick,
                    b = e.otModule,
                    y = e.layoutIndex,
                    E = (0, a.useRef)(null),
                    h = (0, a.useRef)(null),
                    N = st((0, ot.$)((function(e) {
                        return e.pipe((0, lt.p)(300), (0, rt.b)((function(e) {
                            var t, n;
                            "prev" === e ? null === (t = s.current) || void 0 === t || t.slidePrev() : null === (n = s.current) || void 0 === n || n.slideNext()
                        })), (0, it.U)((function() {})))
                    }), void 0), 1),
                    k = N[0];
                return a.createElement("div", {
                    className: "store-banner-site"
                }, a.createElement(oe.t, {
                    onSwiper: function(e) {
                        s.current = e
                    },
                    loop: v.length > 1,
                    spaceBetween: 0,
                    slidesPerView: "auto",
                    observer: !0,
                    observeParents: !0,
                    pagination: {
                        clickable: !0
                    },
                    autoplay: {
                        delay: 5e3,
                        disableOnInteraction: !1,
                        pauseOnMouseEnter: !0
                    },
                    simulateTouch: v.length > 1,
                    onSlideChange: function(e) {
                        c(e.realIndex)
                    },
                    className: "store-banner-site--".concat(null === (t = v[i]) || void 0 === t ? void 0 : t.theme)
                }, v.map((function(e, t) {
                    return e && a.createElement(le.o, {
                        key: t
                    }, a.createElement(p, ct({
                        otClick: _,
                        otModule: "".concat(b, "-").concat(t + 1)
                    }, e, {
                        goods: e.goods,
                        bannerType: (n = e.name, "banner-event" === n ? "event" : "normal"),
                        skeletonData: g,
                        layoutIndex: y
                    })));
                    var n
                })), !m && v.length > 1 && a.createElement(a.Fragment, null, a.createElement("div", {
                    ref: E
                }, a.createElement(u.z, {
                    className: "store-banner-left-icon",
                    btnType: "icon",
                    btnTheme: null === (n = v[i]) || void 0 === n ? void 0 : n.theme,
                    onClick: function() {
                        return k("prev")
                    }
                }, a.createElement(w.q, {
                    symbol: "fill-arrow-left"
                }))), a.createElement("div", {
                    ref: h
                }, a.createElement(u.z, {
                    className: "store-banner-right-icon",
                    btnType: "icon",
                    btnTheme: null === (o = v[i]) || void 0 === o ? void 0 : o.theme,
                    onClick: function() {
                        return k("next")
                    }
                }, a.createElement(w.q, {
                    symbol: "fill-arrow-right"
                }))))))
            }
            X.Z.use([ee.Z, ne.Z, ae.Z]);
            var mt = a.lazy((function() {
                return Promise.all([n.e(8986), n.e(7358), n.e(8654)]).then(n.bind(n, 8654))
            }));

            function dt() {
                return a.createElement(Le, null, a.createElement(mt, null))
            }
            var vt = n(31182),
                ft = n(98231),
                pt = n(28553),
                gt = function() {
                    return gt = Object.assign || function(e) {
                        for (var t, n = 1, a = arguments.length; n < a; n++)
                            for (var o in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
                        return e
                    }, gt.apply(this, arguments)
                },
                _t = function(e, t) {
                    var n = "function" == typeof Symbol && e[Symbol.iterator];
                    if (!n) return e;
                    var a, o, l = n.call(e),
                        r = [];
                    try {
                        for (;
                            (void 0 === t || t-- > 0) && !(a = l.next()).done;) r.push(a.value)
                    } catch (i) {
                        o = {
                            error: i
                        }
                    } finally {
                        try {
                            a && !a.done && (n = l.return) && n.call(l)
                        } finally {
                            if (o) throw o.error
                        }
                    }
                    return r
                };

            function bt(e) {
                var t = (0, d.oW)();
                return a.createElement(vt.d, {
                    siteConfig: t
                }, a.createElement(yt, gt({}, e)))
            }

            function yt(e) {
                var t, n, o = e.title,
                    r = e.subtitle,
                    i = e.classModify,
                    c = e.otModule,
                    s = e.otClick,
                    m = (0, C.a)(),
                    v = (0, d.YB)(),
                    f = (0, a.useContext)(ft.Pk),
                    p = f.state,
                    g = f.dispatch,
                    _ = _t((0, a.useState)(""), 2),
                    b = _[0],
                    y = _[1],
                    E = (0, a.useContext)(vt.S),
                    h = "new-product-title";

                function N(e) {
                    switch (e) {
                        case 1:
                            return [v.get("f2fe1a641d957aae9840739dae9f459e"), "collect"];
                        case 0:
                            return [v.get("3903aab323863bd2e9b68218a7a65ebd"), "collect"];
                        case -2:
                            return [v.get("a25c753ee3e4be15ec0daa5a40deb7b8"), "warning"];
                        default:
                            return [v.get("8524de963f07201e5c086830d370797f"), "more"]
                    }
                }
                return a.createElement("section", {
                    className: l((t = {}, t["".concat(h)] = !0, t["".concat(h, "--").concat(i)] = !!i, t))
                }, a.createElement("div", {
                    className: "".concat(h, "__container")
                }, a.createElement("h4", {
                    className: "".concat(h, "__title")
                }, o), !!r && a.createElement("p", {
                    className: "".concat(h, "__subtitle")
                }, r), a.createElement(u.z, {
                    className: l("".concat(h, "__button"), (n = {}, n["".concat(h, "__button--gray")] = 1 === p.newProductsFollowStatus, n)),
                    disabled: "loading" === E.ajaxStatus || [-1, -2].includes(p.newProductsFollowStatus),
                    btnType: "mobile" !== m ? "primary" : "icon",
                    onClick: function(e) {
                        return function(e, t) {
                            e.stopPropagation(), [0, 1].includes(t) && (s({
                                tip: {
                                    c,
                                    d: 1
                                },
                                elementTitle: o,
                                elementName: N(t)[0]
                            }), E.getService({
                                params: {
                                    follow: 0 === t ? 1 : 2,
                                    item_id: ""
                                }
                            }, (function(e) {
                                g({
                                    type: ft.Tm.SET_IS_FOLLOWED_NEW_PRODUCTS,
                                    payload: 0 === e.errNo ? 1 ^ t : t
                                }), 0 === e.errNo ? y(0 === t ? v.get("891d04e59c4d3d4e6bee6fe14daf75ad") : v.get("9ded1ba1a8231b70e8aee2f7ecd66322")) : -1 === e.errNo ? y(v.get("5ab2a936ac059748f9ea09f852e2e98d")) : y(e.errMsg || v.get("c3865f5e750f1bbbea180e1f263ea4d7"))
                            })))
                        }(e, p.newProductsFollowStatus)
                    },
                    "aria-label": N(p.newProductsFollowStatus)[0]
                }, a.createElement(a.Fragment, null, a.createElement(w.q, {
                    symbol: N(p.newProductsFollowStatus)[1]
                }), a.createElement("span", null, N(p.newProductsFollowStatus)[0])))), a.createElement(pt.F, {
                    msg: b,
                    callback: function() {
                        return y("")
                    }
                }))
            }
            var Et = function() {
                    return Et = Object.assign || function(e) {
                        for (var t, n = 1, a = arguments.length; n < a; n++)
                            for (var o in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
                        return e
                    }, Et.apply(this, arguments)
                },
                ht = a.lazy((function() {
                    return n.e(8291).then(n.bind(n, 58291))
                }));

            function Nt(e) {
                return a.createElement(Le, {
                    fallback: a.createElement(q.a, {
                        type: "inner"
                    })
                }, a.createElement(ht, Et({}, e)))
            }
            var kt = function() {
                    return kt = Object.assign || function(e) {
                        for (var t, n = 1, a = arguments.length; n < a; n++)
                            for (var o in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
                        return e
                    }, kt.apply(this, arguments)
                },
                xt = a.lazy((function() {
                    return n.e(3716).then(n.bind(n, 13716))
                }));

            function St(e) {
                return a.createElement(Le, {
                    fallback: a.createElement(a.Fragment, null)
                }, a.createElement(xt, kt({}, e)))
            }
            var wt = function() {
                    return wt = Object.assign || function(e) {
                        for (var t, n = 1, a = arguments.length; n < a; n++)
                            for (var o in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
                        return e
                    }, wt.apply(this, arguments)
                },
                Ct = a.lazy((function() {
                    return n.e(4097).then(n.bind(n, 14097))
                }));

            function Tt(e) {
                return a.createElement(Le, {
                    fallback: a.createElement(a.Fragment, null)
                }, a.createElement(Ct, wt({}, e)))
            }

            function Ot(e) {
                var t = e.extends;
                return a.createElement("div", {
                    className: "rich-text__body"
                }, a.createElement("div", {
                    className: "site-rich-text__content site-container",
                    dangerouslySetInnerHTML: {
                        __html: String((null == t ? void 0 : t.content) || "")
                    }
                }))
            }

            function It(e) {
                var t, n = e.className,
                    o = void 0 === n ? "" : n,
                    l = e.title,
                    i = e.children,
                    c = "support-block";
                return a.createElement("div", {
                    className: r()(c, (t = {}, t["".concat(o)] = !!o, t))
                }, a.createElement("div", {
                    className: "site-container ".concat(c, "__content")
                }, a.createElement("h1", {
                    className: "mi-h1 ".concat(c, "__title")
                }, l), i))
            }
            var Mt = n(4479),
                Ut = function(e, t) {
                    var n = "function" == typeof Symbol && e[Symbol.iterator];
                    if (!n) return e;
                    var a, o, l = n.call(e),
                        r = [];
                    try {
                        for (;
                            (void 0 === t || t-- > 0) && !(a = l.next()).done;) r.push(a.value)
                    } catch (i) {
                        o = {
                            error: i
                        }
                    } finally {
                        try {
                            a && !a.done && (n = l.return) && n.call(l)
                        } finally {
                            if (o) throw o.error
                        }
                    }
                    return r
                };

            function Pt(e) {
                var t, n, o = e.className,
                    l = void 0 === o ? "" : o,
                    i = e.tabData,
                    c = "tab-with-content",
                    s = Ut((0, a.useState)((null === (n = i[0]) || void 0 === n ? void 0 : n.key) || ""), 2),
                    u = s[0],
                    m = s[1];
                return a.createElement("div", {
                    className: r()(c, (t = {}, t["".concat(l)] = !!l, t))
                }, !!i.length && a.createElement(Mt.m, {
                    extraRootClass: "site-container ".concat(c, "__tab"),
                    activeId: u,
                    onTabClick: function(e) {
                        return m(e)
                    }
                }, i.map((function(e) {
                    return a.createElement(Mt.m.Pane, {
                        key: e.key,
                        tabId: e.key,
                        tabTitle: e.name
                    }, e.content)
                }))))
            }
            var At = n(28721);

            function Lt(e) {
                var t, n, o = e.title;
                return a.createElement(It, {
                    title: o
                }, a.createElement(Pt, {
                    className: "tab-with-rich-text",
                    tabData: function(e) {
                        return e.map((function(e) {
                            return {
                                key: e.key,
                                name: e.name,
                                content: a.createElement(Ot, {
                                    extends: {
                                        content: e.content
                                    }
                                })
                            }
                        }))
                    }((n = e.extends, void 0 === n && (n = {}), {
                        data: (t = n.data || [], void 0 === t && (t = []), Array.from(t || []).map((function(e) {
                            return {
                                key: String(e.key || (0, At.Z)()),
                                name: String(e.name || ""),
                                content: String(e.content || "")
                            }
                        })))
                    }).data)
                }))
            }
            var Dt = function(e, t) {
                var n = "function" == typeof Symbol && e[Symbol.iterator];
                if (!n) return e;
                var a, o, l = n.call(e),
                    r = [];
                try {
                    for (;
                        (void 0 === t || t-- > 0) && !(a = l.next()).done;) r.push(a.value)
                } catch (i) {
                    o = {
                        error: i
                    }
                } finally {
                    try {
                        a && !a.done && (n = l.return) && n.call(l)
                    } finally {
                        if (o) throw o.error
                    }
                }
                return r
            };

            function Ft(e) {
                var t = e.title,
                    n = e.subtitle,
                    o = e.buttons,
                    l = e.images,
                    r = Dt((0, a.useState)(""), 2),
                    i = r[0],
                    c = r[1],
                    s = (0, C.a)(),
                    m = "service-background-text";
                return (0, a.useEffect)((function() {
                    if (l.length > 0) {
                        var e = Object.keys(l[0].src).filter((function(e) {
                            return e === s
                        }));
                        c(l[0].src[e[0]] || "")
                    }
                }), [s, l]), a.createElement("div", {
                    className: m,
                    style: {
                        backgroundImage: "url(".concat(i, ")")
                    }
                }, a.createElement("h3", {
                    className: "mi-h3 ".concat(m, "__title")
                }, t), n && a.createElement("p", {
                    className: "".concat(m, "__content")
                }, n), o.length > 0 && o[0].text && a.createElement("div", {
                    className: "".concat(m, "__button-group")
                }, o.map((function(e, t) {
                    return a.createElement(u.z, {
                        key: t + e.gotoUrl,
                        className: "".concat(m, "__button"),
                        btnType: "primary",
                        btnTheme: "dark",
                        href: e.gotoUrl
                    }, e.text)
                }))))
            }
            var jt = function(e, t) {
                var n = "function" == typeof Symbol && e[Symbol.iterator];
                if (!n) return e;
                var a, o, l = n.call(e),
                    r = [];
                try {
                    for (;
                        (void 0 === t || t-- > 0) && !(a = l.next()).done;) r.push(a.value)
                } catch (i) {
                    o = {
                        error: i
                    }
                } finally {
                    try {
                        a && !a.done && (n = l.return) && n.call(l)
                    } finally {
                        if (o) throw o.error
                    }
                }
                return r
            };

            function zt(e) {
                var t, n = e.extends,
                    o = null == n ? void 0 : n.data,
                    l = window.location.hash.split("#")[1],
                    i = jt((0, a.useState)(""), 2),
                    c = i[0],
                    s = i[1],
                    u = (Array.isArray(o) ? o : []).map((function(e) {
                        return null == e ? void 0 : e.title
                    })),
                    m = {
                        chat: "message-smile",
                        phone: "phone",
                        mail: "support-mail",
                        office: "nav-office"
                    },
                    d = "support-country",
                    f = function(e) {
                        var t = e.link,
                            n = e.tag,
                            a = e.content;
                        return "mail" === n && (0, v.oP)(a) && !t
                    };
                return (0, a.useEffect)((function() {
                    window.location.hash ? s(l) : u[0] && s(u[0])
                }), [window.location.hash]), a.createElement("div", {
                    className: d
                }, (null == n ? void 0 : n.showTab) && u.length > 0 && a.createElement("div", {
                    className: "".concat(d, "__nav")
                }, u.map((function(e, t) {
                    return a.createElement("a", {
                        key: e + t,
                        className: r()("nav__item", {
                            "nav__item--active": e === c
                        }),
                        href: "#".concat(e),
                        onClick: function() {
                            return s(e)
                        }
                    }, e)
                }))), a.createElement("div", {
                    className: "".concat(d, "__list-wrapper")
                }, a.createElement("div", {
                    className: r()("site-container", "".concat(d, "__list"), (t = {}, t["".concat(d, "__list--compact")] = null == n ? void 0 : n.compactMode, t))
                }, (Array.isArray(o) ? o : []).map((function(e, t) {
                    return a.createElement("div", {
                        key: (null == e ? void 0 : e.title) + t,
                        className: "".concat(d, "__group")
                    }, a.createElement("a", {
                        id: null == e ? void 0 : e.title,
                        className: "group__anchor"
                    }), a.createElement("h3", {
                        className: "group__title"
                    }, null == e ? void 0 : e.title), a.createElement("div", {
                        className: "group__list"
                    }, (Array.isArray(null == e ? void 0 : e.children) ? null == e ? void 0 : e.children : []).map((function(e, t) {
                        return a.createElement("div", {
                            key: (null == e ? void 0 : e.title) + t,
                            className: "group__item"
                        }, (null == e ? void 0 : e.titleLink) ? a.createElement("h4", {
                            className: "item__title"
                        }, a.createElement("a", {
                            className: "item__link",
                            href: e.titleLink
                        }, null == e ? void 0 : e.title)) : a.createElement("h4", {
                            className: "item__title"
                        }, null == e ? void 0 : e.title), !!(null == e ? void 0 : e.desc) && a.createElement("span", {
                            className: "item__detail"
                        }, e.desc), Array.from((null == e ? void 0 : e.items) || []).filter((function(e) {
                            return !!(null == e ? void 0 : e.content)
                        })).map((function(e, t) {
                            return a.createElement("span", {
                                key: (null == e ? void 0 : e.tag) + t,
                                className: r()("item__detail", {
                                    "item__detail--separator": 0 === t
                                })
                            }, m[null == e ? void 0 : e.tag] && a.createElement(w.q, {
                                className: "item__icon",
                                symbol: m[null == e ? void 0 : e.tag]
                            }), "phone" === (null == e ? void 0 : e.tag) ? e.content : a.createElement("a", {
                                className: "item__link",
                                href: f(e) ? "mailto:".concat(e.content) : (null == e ? void 0 : e.link) || ""
                            }, e.content))
                        })))
                    }))))
                })))))
            }
            var qt = function(e, t) {
                var n = "function" == typeof Symbol && e[Symbol.iterator];
                if (!n) return e;
                var a, o, l = n.call(e),
                    r = [];
                try {
                    for (;
                        (void 0 === t || t-- > 0) && !(a = l.next()).done;) r.push(a.value)
                } catch (i) {
                    o = {
                        error: i
                    }
                } finally {
                    try {
                        a && !a.done && (n = l.return) && n.call(l)
                    } finally {
                        if (o) throw o.error
                    }
                }
                return r
            };

            function Bt(e) {
                var t, n = e.siftList,
                    r = (0, C.a)(),
                    i = (0, o.k6)(),
                    c = qt((0, a.useState)(!1), 2),
                    s = c[0],
                    u = c[1],
                    m = (0, o.UO)(),
                    d = qt((0, a.useState)(m.tag || (null === (t = n[0]) || void 0 === t ? void 0 : t.path)), 2),
                    v = d[0],
                    f = d[1],
                    p = function(e) {
                        f(e),
                            function(e, t) {
                                if ("".concat(v) === "".concat(e)) return;
                                i.push(function(e) {
                                    return "/support/".concat(e)
                                }(e))
                            }(e), u(!1)
                    };
                return a.createElement("div", {
                    className: "support-select"
                }, a.createElement("div", {
                    className: "support-select__series"
                }, a.createElement("span", {
                    className: "mi-h1 support-select__title",
                    role: "button",
                    tabIndex: 0,
                    onClick: function() {
                        u(!s)
                    }
                }, function(e) {
                    var t;
                    return (null === (t = null == n ? void 0 : n.filter((function(t) {
                        return t.path === e
                    }))[0]) || void 0 === t ? void 0 : t.title) || ""
                }(v), n.length > 1 && "mobile" === r && s && a.createElement(w.q, {
                    symbol: "up",
                    className: "support-select__title-arrow-up--mobile"
                }), n.length > 1 && "mobile" === r && !s && a.createElement(w.q, {
                    symbol: "down",
                    className: "support-select__title-arrow-down--mobile"
                }), n.length > 1 && "mobile" !== r && a.createElement(w.q, {
                    symbol: "up",
                    className: "support-select__title-arrow-up"
                }), n.length > 1 && "mobile" !== r && a.createElement(w.q, {
                    symbol: "down",
                    className: "support-select__title-arrow-down"
                })), n.length > 1 && a.createElement("ul", {
                    style: s ? {
                        display: "block"
                    } : {},
                    role: "menu",
                    className: l({
                        "support-select--hover": !0,
                        "support-select--hover-mobile": "mobile" === r,
                        "support-select--hover-pc": "mobile" !== r
                    })
                }, n.map((function(e) {
                    return a.createElement("li", {
                        key: e.path,
                        className: l({
                            "support-select--li": !0,
                            "li--active": e.path === v
                        }),
                        onClick: function() {
                            return p(e.path)
                        },
                        role: "menuitem",
                        tabIndex: 0
                    }, e.title)
                })))))
            }

            function Wt(e) {
                var t, n = e.title,
                    o = e.subtitle,
                    r = e.classModify,
                    i = e.otModule,
                    c = e.extends,
                    s = Array.from((null == c ? void 0 : c.data) || []);
                return a.createElement("section", {
                    className: l((t = {
                        "small-icon-text": !0
                    }, t["small-icon-text--".concat(r)] = !!r, t)),
                    "data-ot-expose": JSON.stringify({
                        tip: {
                            c: i
                        }
                    })
                }, a.createElement("div", {
                    className: "small-icon-text__info",
                    role: "main"
                }, !!n && a.createElement("h3", {
                    className: "small-icon-text__title"
                }, n), !!o && a.createElement("p", {
                    className: "small-icon-text__subtitle"
                }, o)), a.createElement("ul", {
                    className: "small-icon-text__list",
                    role: "tree"
                }, s.map((function(e, t) {
                    return a.createElement("li", {
                        className: "small-icon-text__item",
                        key: t,
                        role: "row"
                    }, (null == e ? void 0 : e.iconTag) && a.createElement("div", {
                        className: "small-icon-text__item-icon"
                    }, a.createElement(w.q, {
                        symbol: null == e ? void 0 : e.iconTag
                    })), (null == e ? void 0 : e.title) && a.createElement("div", {
                        className: "small-icon-text__item-title"
                    }, null == e ? void 0 : e.title), (null == e ? void 0 : e.desc) && a.createElement("div", {
                        className: "small-icon-text__item-desc"
                    }, null == e ? void 0 : e.desc))
                }))))
            }
            var Rt = n(80941);

            function Jt(e) {
                return void 0 === e && (e = {}), {
                    text: String(e.text || ""),
                    link: String(e.link || "")
                }
            }

            function Gt(e) {
                var t, n, o = e.title,
                    l = function(e) {
                        return e.length ? a.createElement("div", {
                            className: "table__grid"
                        }, e.map((function(e, t) {
                            return a.createElement("div", {
                                key: "".concat(e.text, "-").concat(t),
                                className: "table__item"
                            }, a.createElement(Rt.I, {
                                className: "table__link",
                                href: e.link
                            }, e.text))
                        }))) : null
                    };
                return a.createElement(It, {
                    title: o
                }, a.createElement(Pt, {
                    className: "tab-with-table",
                    tabData: function(e) {
                        return e.map((function(e) {
                            return {
                                key: e.key,
                                name: e.name,
                                content: l(e.content)
                            }
                        }))
                    }((n = e.extends, void 0 === n && (n = {}), {
                        data: (t = n.data || [], void 0 === t && (t = []), Array.from(t || []).map((function(e) {
                            return {
                                key: String(e.key || (0, At.Z)()),
                                name: String(e.name || ""),
                                content: Array.from(e.content || []).length ? Array.from(e.content || []).map((function(e) {
                                    return Jt(e)
                                })) : [Jt({})]
                            }
                        })))
                    }).data)
                }))
            }
            var Yt = n(74535);

            function Vt(e) {
                return void 0 === e && (e = {}), {
                    data: Array.from(e.data || []).map((function(e) {
                        return function(e) {
                            void 0 === e && (e = {});
                            return {
                                key: String(e.key || (0, At.Z)()),
                                question: String(e.question || ""),
                                answer: String(e.answer || "")
                            }
                        }(e || {})
                    }))
                }
            }

            function Zt(e) {
                var t = e.title,
                    n = Vt(e.extends).data,
                    o = [],
                    l = "__".concat((0, At.Z)(), "__");
                return n.forEach((function(e) {
                    o.push({
                        title: e.question,
                        children: a.createElement(Ot, {
                            extends: {
                                content: e.answer
                            }
                        })
                    }), o.push({
                        title: l,
                        children: null
                    })
                })), a.createElement(It, {
                    className: "accordion-block",
                    title: t
                }, a.createElement(Yt.U, {
                    type: "custom",
                    data: o,
                    autoFold: !1,
                    showMoreIcon: "down",
                    showLessIcon: "up",
                    dividerName: l
                }))
            }
            var Ht = n(3839),
                Qt = n(85785);

            function $t() {
                return a.createElement("div", {
                    className: "search-block"
                }, a.createElement(Ht.l, null))
            }

            function Kt(e) {
                var t = (0, d.oW)();
                return a.createElement(Qt.Su, {
                    siteConfig: t
                }, a.createElement($t, null))
            }
            var Xt = "service-product-info";

            function en(e) {
                var t, n, o, l = e.extends,
                    r = e.title,
                    i = e.subtitle,
                    c = e.images,
                    s = e.buttons,
                    m = e.tips;
                return a.createElement("div", {
                    className: "service-product"
                }, a.createElement("h3", {
                    className: "mi-h2 service-product__title"
                }, String((null == l ? void 0 : l.headLine) || "")), a.createElement("div", {
                    className: "service-product-info"
                }, a.createElement("div", {
                    className: "".concat(Xt, "__image")
                }, a.createElement("img", {
                    className: "".concat(Xt, "__picture"),
                    src: (null === (n = null === (t = c[0]) || void 0 === t ? void 0 : t.src) || void 0 === n ? void 0 : n.widescreen) || "",
                    alt: (null === (o = c[0]) || void 0 === o ? void 0 : o.alt) || r || ""
                })), a.createElement("div", {
                    className: "".concat(Xt, "__right")
                }, a.createElement("div", null, a.createElement("h3", {
                    className: "mi-h2 ".concat(Xt, "__title")
                }, r), a.createElement("p", {
                    className: "mi-text ".concat(Xt, "__subtitle")
                }, i)), a.createElement("div", null, !!s.length && a.createElement(u.z, {
                    className: "".concat(Xt, "__btn"),
                    btnType: "primary",
                    href: s[0].gotoUrl
                }, s[0].text), s.length > 1 && a.createElement("div", {
                    className: "".concat(Xt, "__related")
                }, s.slice(1).map((function(e, t) {
                    return (null == e ? void 0 : e.text) || (null == e ? void 0 : e.gotoUrl) ? a.createElement(u.z, {
                        className: "".concat(Xt, "__link"),
                        btnType: "link",
                        key: t,
                        href: e.gotoUrl
                    }, e.text) : a.createElement(a.Fragment, null)
                })))))), m && a.createElement("p", {
                    className: "service-product__tip"
                }, m))
            }

            function tn(e) {
                var t, n = e.slides,
                    o = e.classModify,
                    r = e.title;
                return a.createElement("div", {
                    className: l((t = {
                        "support-small-btn": !0
                    }, t["support-small-btn--".concat(o)] = !!o, t))
                }, a.createElement("h3", {
                    className: "support-small-btn__title"
                }, r || ""), a.createElement("div", {
                    className: l({
                        "support-small-btn__link": !0,
                        "support-small-btn__link--special": [1, 4, 5].includes(n.length)
                    })
                }, n.map((function(e, t) {
                    var n, o;
                    return a.createElement("div", {
                        className: "support-small-btn__item",
                        key: t
                    }, a.createElement(u.z, {
                        className: "support-small-btn__button",
                        btnType: "link",
                        href: null === (n = e.buttons[0]) || void 0 === n ? void 0 : n.gotoUrl
                    }, a.createElement(w.q, {
                        className: "support-small-btn__image",
                        symbol: e.type
                    }), null === (o = e.buttons[0]) || void 0 === o ? void 0 : o.text))
                }))))
            }
            var nn = "support-button";

            function an(e) {
                var t, n, o, r, i = e.subtitle,
                    c = e.buttons,
                    s = e.images,
                    m = e.classModify,
                    d = e.otModule,
                    v = e.otClick,
                    f = "mobile" !== (0, C.a)();
                return a.createElement("section", {
                    className: l((t = {}, t["support-button"] = !0, t["".concat(nn, "--").concat(m)] = !!m, t)),
                    onClick: function() {
                        return e = null == c ? void 0 : c[0], v({
                            event: "click",
                            tip: {
                                c: d,
                                d: 0
                            },
                            link: e.gotoUrl,
                            elementName: "repair_service",
                            elementTitle: e.text
                        }), void(window.location.href = e.gotoUrl);
                        var e
                    },
                    role: "presentation"
                }, a.createElement("div", {
                    className: "".concat(nn, "__wrapper")
                }, a.createElement("div", {
                    className: "".concat(nn, "__info")
                }, a.createElement("div", {
                    className: "".concat(nn, "__title")
                }, c.filter((function(e) {
                    return e.text && e.gotoUrl
                })).map((function(e, t) {
                    return a.createElement(a.Fragment, {
                        key: t
                    }, a.createElement(u.z, {
                        className: "".concat(nn, "__link"),
                        btnType: "link",
                        href: e.gotoUrl
                    }, e.text), f && a.createElement(w.q, {
                        symbol: "link-arrow"
                    }))
                }))), !!i && a.createElement("span", {
                    className: "".concat(nn, "__subtitle")
                }, i)), a.createElement("img", {
                    className: "".concat(nn, "__image"),
                    src: null === (o = null === (n = null == s ? void 0 : s[0]) || void 0 === n ? void 0 : n.src) || void 0 === o ? void 0 : o.widescreen,
                    alt: null === (r = null == s ? void 0 : s[0]) || void 0 === r ? void 0 : r.alt,
                    loading: "lazy"
                })))
            }
            var on = n(16607),
                ln = n(96625),
                rn = function(e, t) {
                    var n = "function" == typeof Symbol && e[Symbol.iterator];
                    if (!n) return e;
                    var a, o, l = n.call(e),
                        r = [];
                    try {
                        for (;
                            (void 0 === t || t-- > 0) && !(a = l.next()).done;) r.push(a.value)
                    } catch (i) {
                        o = {
                            error: i
                        }
                    } finally {
                        try {
                            a && !a.done && (n = l.return) && n.call(l)
                        } finally {
                            if (o) throw o.error
                        }
                    }
                    return r
                },
                cn = (0, on.o)(mn),
                sn = (0, a.createContext)(cn);

            function un(e) {
                var t = e.siteConfig,
                    n = e.isAutoFetch,
                    o = e.children,
                    l = rn((0, a.useState)(cn), 2),
                    r = l[0],
                    i = l[1];

                function c(e) {
                    var t = e.data,
                        n = e.errmsg,
                        a = e.errno;
                    return {
                        data: mn(t),
                        errMsg: String(n),
                        errNo: Number(a)
                    }
                }
                var s = {
                    url: "".concat(t.goSite, "/v2/cms/support/high-frequency"),
                    method: "GET",
                    withCredentials: !0,
                    retryOptions: {
                        maxRetryAttempts: 3,
                        scalingDuration: 3e3
                    }
                };
                return a.createElement(ln.h, {
                    context: sn,
                    setState: i,
                    defaultValue: cn,
                    adapterError: function(e) {
                        return c(e)
                    },
                    adapter: c,
                    value: r,
                    siteConfig: t,
                    isAutoFetch: !0 === n,
                    ajaxConfig: s
                }, o)
            }

            function mn(e) {
                return {
                    items: dn(e.items) || []
                }
            }

            function dn(e) {
                return void 0 === e && (e = []), Array.from(e || []).map((function(e) {
                    return {
                        articlepublicnumber: e.articlepublicnumber || "",
                        title: e.title || "",
                        description: e.description || "",
                        content: e.content || "",
                        new_highfrequencyfaq: e.new_highfrequencyfaq || !1,
                        createdon: e.createdon || 0,
                        modifiedon: e.modifiedon || 0,
                        uri: e.uri || "",
                        page_type: e.page_type || ""
                    }
                }))
            }
            var vn = function() {
                    return vn = Object.assign || function(e) {
                        for (var t, n = 1, a = arguments.length; n < a; n++)
                            for (var o in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
                        return e
                    }, vn.apply(this, arguments)
                },
                fn = function(e, t) {
                    var n = "function" == typeof Symbol && e[Symbol.iterator];
                    if (!n) return e;
                    var a, o, l = n.call(e),
                        r = [];
                    try {
                        for (;
                            (void 0 === t || t-- > 0) && !(a = l.next()).done;) r.push(a.value)
                    } catch (i) {
                        o = {
                            error: i
                        }
                    } finally {
                        try {
                            a && !a.done && (n = l.return) && n.call(l)
                        } finally {
                            if (o) throw o.error
                        }
                    }
                    return r
                };

            function pn(e) {
                var t = (0, d.oW)();
                return a.createElement(un, {
                    siteConfig: t
                }, a.createElement(gn, vn({}, e)))
            }

            function gn(e) {
                var t = (0, d.YB)(),
                    n = a.useContext(sn),
                    o = e.extends,
                    l = fn(a.useState([]), 2),
                    r = l[0],
                    i = l[1],
                    c = e.buttons;
                return a.useEffect((function() {
                    n.getService({
                        params: {
                            page_type: o.page_type ? o.page_type : "faq",
                            content_type: o.content_type ? o.content_type : "phone"
                        }
                    }, (function(e) {
                        0 === e.errNo && i(e.data.items)
                    }))
                }), []), a.createElement("div", {
                    className: "height-faq"
                }, a.createElement("div", {
                    className: "height-faq__top"
                }, a.createElement("h2", {
                    className: "mi-h2 height-faq__title"
                }, o.page_type && "faq" !== o.page_type ? t.get("56955274f7c3e0cda19fae97f7f21569") : t.get("1eafd418211b7a28fe14f11b4e561c07")), c.filter((function(e) {
                    return e.text && e.gotoUrl
                })).map((function(e, t) {
                    return a.createElement(a.Fragment, {
                        key: t
                    }, a.createElement(u.z, {
                        className: "height-faq__icon",
                        btnType: "link",
                        href: e.gotoUrl
                    }, e.text, " >"))
                }))), a.createElement("div", {
                    className: "height-faq__content"
                }, r && r.map((function(e) {
                    return a.createElement("a", {
                        className: "height-faq__text",
                        href: e.uri,
                        key: e.modifiedon
                    }, e.title)
                }))))
            }

            function _n(e) {
                var t, n = e.title,
                    o = e.subtitle,
                    r = e.classModify,
                    i = e.otModule;
                return a.createElement("section", {
                    className: l((t = {
                        "support-title": !0
                    }, t["support-title--".concat(r)] = !!r, t)),
                    "data-ot-expose": JSON.stringify({
                        tip: {
                            c: i
                        }
                    })
                }, a.createElement("div", {
                    className: "support-title__info"
                }, a.createElement("h3", {
                    className: "mi-h3 support-title__title"
                }, n), !!o && a.createElement("p", {
                    className: "support-title__subtitle"
                }, o)))
            }
            var bn = function(e, t) {
                var n = "function" == typeof Symbol && e[Symbol.iterator];
                if (!n) return e;
                var a, o, l = n.call(e),
                    r = [];
                try {
                    for (;
                        (void 0 === t || t-- > 0) && !(a = l.next()).done;) r.push(a.value)
                } catch (i) {
                    o = {
                        error: i
                    }
                } finally {
                    try {
                        a && !a.done && (n = l.return) && n.call(l)
                    } finally {
                        if (o) throw o.error
                    }
                }
                return r
            };

            function yn(e) {
                var t, n, o, l = e.title,
                    r = e.images,
                    c = e.videos,
                    s = bn((0, a.useState)(!1), 2),
                    u = s[0],
                    m = s[1],
                    d = "support-video",
                    v = function(e) {
                        m(e)
                    };
                return a.createElement("div", {
                    className: "support-video"
                }, !!r.length && a.createElement(i.t, {
                    className: "".concat(d, "__image"),
                    alt: (null === (t = r[0]) || void 0 === t ? void 0 : t.alt) || l || "",
                    srcSet: (null === (n = r[0]) || void 0 === n ? void 0 : n.src) || []
                }), a.createElement("div", {
                    className: "".concat(d, "__wrapper")
                }, a.createElement("div", {
                    className: "".concat(d, "__title")
                }, l), a.createElement("img", {
                    className: "".concat(d, "__button"),
                    onClick: function() {
                        return v(!0)
                    },
                    alt: "play",
                    role: "button",
                    src: "//i05.appmifile.com/172_operator_es/21/10/2022/bfdf9b095156748808a07e4ebd65bb4a.png"
                })), a.createElement(_e.u, {
                    extraClassName: "".concat(d, "__modal"),
                    isModalShow: u,
                    isShowCloseIcon: !0,
                    shouldCloseOnOverlayClick: !1,
                    closeModal: function() {
                        v(!1)
                    }
                }, a.createElement("iframe", {
                    src: null === (o = c[0]) || void 0 === o ? void 0 : o.url,
                    title: l,
                    frameBorder: "0",
                    allow: "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture",
                    allowFullScreen: !0
                })))
            }
            var En = "site-phone-list";

            function hn(e) {
                var t, n, o, l, r, i, c = e.buttons,
                    s = e.images,
                    m = e.title;
                return a.createElement("section", {
                    className: En
                }, a.createElement("div", {
                    className: "".concat(En, "__info")
                }, a.createElement("h3", {
                    className: "".concat(En, "__title")
                }, m), a.createElement("img", {
                    className: "".concat(En, "__badge"),
                    src: null === (n = null === (t = null == s ? void 0 : s[1]) || void 0 === t ? void 0 : t.src) || void 0 === n ? void 0 : n.widescreen,
                    alt: null === (o = null == s ? void 0 : s[1]) || void 0 === o ? void 0 : o.alt,
                    loading: "lazy"
                }), c.filter((function(e) {
                    return e.text && e.gotoUrl
                })).map((function(e, t) {
                    return a.createElement(a.Fragment, {
                        key: t
                    }, a.createElement(u.z, {
                        className: "".concat(En, "__link"),
                        btnType: "link",
                        href: e.gotoUrl
                    }, e.text, " >"))
                }))), a.createElement("div", {
                    className: "".concat(En, "__gap")
                }), a.createElement("img", {
                    className: "".concat(En, "__image"),
                    src: null === (r = null === (l = null == s ? void 0 : s[0]) || void 0 === l ? void 0 : l.src) || void 0 === r ? void 0 : r.widescreen,
                    alt: null === (i = null == s ? void 0 : s[0]) || void 0 === i ? void 0 : i.alt,
                    loading: "lazy"
                }))
            }

            function Nn(e) {
                var t, n, o, l, i = e.title,
                    c = e.images,
                    s = e.subtitle,
                    u = e.style,
                    m = "site-image-description";
                return a.createElement("div", {
                    className: r()(m, (t = {}, t["".concat(m, "--reverse")] = 2 === u, t))
                }, a.createElement("img", {
                    className: "".concat(m, "__image"),
                    src: null === (o = null === (n = null == c ? void 0 : c[0]) || void 0 === n ? void 0 : n.src) || void 0 === o ? void 0 : o.widescreen,
                    alt: null === (l = null == c ? void 0 : c[0]) || void 0 === l ? void 0 : l.alt
                }), a.createElement("div", {
                    className: "".concat(m, "__content")
                }, a.createElement("h2", {
                    className: "mi-h3 ".concat(m, "__title")
                }, i), a.createElement("p", {
                    className: "".concat(m, "__text")
                }, s)))
            }
            var kn = ["#F7F7F7", "#FFFFFF"],
                xn = "site-service-share";

            function Sn(e) {
                var t, n, o, r, i = e.buttons,
                    c = e.images,
                    s = e.style;
                return a.createElement("section", {
                    className: l((t = {}, t["site-service-share"] = !0, t))
                }, a.createElement("div", {
                    className: "".concat(xn, "__info"),
                    style: {
                        backgroundColor: kn[s - 1]
                    }
                }, a.createElement("img", {
                    className: "".concat(xn, "__image"),
                    src: null === (o = null === (n = null == c ? void 0 : c[0]) || void 0 === n ? void 0 : n.src) || void 0 === o ? void 0 : o.widescreen,
                    alt: null === (r = null == c ? void 0 : c[0]) || void 0 === r ? void 0 : r.alt,
                    loading: "lazy"
                }), a.createElement("div", {
                    className: "".concat(xn, "__title")
                }, i.filter((function(e) {
                    return e.text && e.gotoUrl
                })).map((function(e, t) {
                    return a.createElement(a.Fragment, {
                        key: t
                    }, a.createElement("div", {
                        className: "".concat(xn, "__link")
                    }, "".concat(e.text, " >")))
                })))))
            }

            function wn(e) {
                var t, n, o = e.title,
                    l = e.subtitle,
                    r = e.images,
                    i = e.buttons,
                    c = (0, d.YB)();
                return a.createElement("section", {
                    className: "support-article"
                }, a.createElement("div", {
                    className: "support-article__wrapper",
                    role: "button",
                    tabIndex: 0,
                    onClick: function(e) {
                        var t, n;
                        e.stopPropagation(), (null === (t = i[0]) || void 0 === t ? void 0 : t.gotoUrl) && (0, v.MN)("".concat(null === (n = i[0]) || void 0 === n ? void 0 : n.gotoUrl))
                    }
                }, a.createElement("div", {
                    className: "support-article__wrapper-left"
                }, a.createElement("div", {
                    className: "support-article__tag"
                }, c.get("5e2f8ee473fdebc99fef4dc9e7ee3146")), a.createElement("div", {
                    className: "support-article__title"
                }, o), a.createElement("div", {
                    className: "support-article__subtitle"
                }, l)), a.createElement("div", {
                    className: "support-article__wrapper-right"
                }, a.createElement("img", {
                    className: "support-article__image",
                    src: null === (n = null === (t = r[0]) || void 0 === t ? void 0 : t.src) || void 0 === n ? void 0 : n.widescreen,
                    alt: o
                }))))
            }
            var Cn = n(1128),
                Tn = n(74018),
                On = function(e, t) {
                    var n = "function" == typeof Symbol && e[Symbol.iterator];
                    if (!n) return e;
                    var a, o, l = n.call(e),
                        r = [];
                    try {
                        for (;
                            (void 0 === t || t-- > 0) && !(a = l.next()).done;) r.push(a.value)
                    } catch (i) {
                        o = {
                            error: i
                        }
                    } finally {
                        try {
                            a && !a.done && (n = l.return) && n.call(l)
                        } finally {
                            if (o) throw o.error
                        }
                    }
                    return r
                };

            function In(e) {
                var t = e.contactData,
                    n = (0, Cn.Nr)(),
                    o = (0, d.YB)(),
                    l = (0, d.oW)(),
                    r = "mobile" === (0, C.a)(),
                    i = function() {
                        (0, ge.otClick)({
                            tip: "16.107.1.0.28644",
                            pageType: "support",
                            elementName: "contact",
                            elementTitle: n ? "tickets_login" : "tickets_visitor",
                            link: "".concat(l.wwwSite.pc, "/support"),
                            isOpenGA: !0
                        }), window.location.assign("".concat(l.wwwSite.pc, "/support/offline-form"))
                    };
                return a.createElement(a.Fragment, null, a.createElement("div", null, a.createElement("div", {
                    className: "support-contact__title"
                }, o.get("02d4482d332e1aef3437cd61c9bcc624")), a.createElement("ul", {
                    className: "support-contact__list",
                    role: "menu"
                }, !!(null == t ? void 0 : t.length) && t.map((function(e, t) {
                    return 1 === e.type ? a.createElement("li", {
                        key: e.title,
                        className: "support-contact__item",
                        role: "menuitem"
                    }, a.createElement(Tn.k, {
                        linkUrl: e.desc
                    })) : 0 === e.type ? a.createElement(Mn, {
                        key: t,
                        title: e.title,
                        desc: e.desc
                    }) : 2 === e.type ? a.createElement("li", {
                        key: "from",
                        className: "support-contact__item",
                        role: "menuitem",
                        onClick: i
                    }, a.createElement("div", {
                        className: "support-contact__content support-contact__submit-ticket"
                    }, a.createElement("div", {
                        className: "support-contact__subtit"
                    }, o.get("27e38dd3571d45f53060d74ff352ccdc"))), r && a.createElement(w.q, {
                        symbol: "link-arrow"
                    })) : 3 === e.type ? a.createElement("a", {
                        key: e.title,
                        className: "support-contact__item",
                        href: "mailto:".concat(e.desc)
                    }, a.createElement("div", {
                        className: "support-contact__content support-cursor"
                    }, a.createElement("div", {
                        className: "support-contact__subtit"
                    }, e.desc)), r && a.createElement(w.q, {
                        symbol: "link-arrow"
                    })) : null
                })))))
            }

            function Mn(e) {
                var t, n = e.desc,
                    o = e.title,
                    r = (0, d.YB)(),
                    i = "mobile" === (0, C.a)(),
                    c = On((0, a.useState)(!1), 2),
                    s = c[0],
                    u = c[1],
                    m = On((0, a.useState)(!1), 2),
                    v = m[0],
                    f = m[1];
                return a.createElement("li", {
                    key: o,
                    className: "support-contact__item"
                }, a.createElement("div", {
                    className: "support-contact__content"
                }, a.createElement("div", {
                    className: "support-contact__subtit"
                }, r.get("68e05a95037802db0b58d16ddb39cfc3"), ":"), a.createElement("div", {
                    className: "support-contact__text"
                }, o), !i && a.createElement("div", {
                    className: "support-contact__note micon micon-warning-fill",
                    onMouseEnter: function() {
                        (0, ge.otExpose)({
                            tip: {
                                c: "support_contact",
                                e: 17013
                            },
                            elementName: "worktime",
                            isOpenGA: !0
                        }), f(!0)
                    },
                    onMouseLeave: function() {
                        return f(!1)
                    }
                }, a.createElement("div", {
                    className: l((t = {}, t["support-contact__pop"] = !0, t["is-active"] = v, t))
                }, n))), i && a.createElement("div", {
                    className: "support-contact__note micon micon-warning-fill",
                    role: "button",
                    tabIndex: 0,
                    onClick: function() {
                        (0, ge.otClick)({
                            tip: {
                                c: "support_contact",
                                e: 17013
                            },
                            elementName: "worktime",
                            isOpenGA: !0
                        }), u(!0)
                    }
                }), i && a.createElement(_e.u, {
                    isModalShow: s,
                    closeModal: function() {
                        return u(!1)
                    },
                    extraClassName: "support-contact-pop-modal",
                    isShowCloseIcon: !0
                }, a.createElement("div", {
                    className: "support-contact__pop"
                }, n)))
            }

            function Un(e) {
                var t = e.termsData,
                    n = "mobile" === (0, C.a)(),
                    o = (0, d.YB)(),
                    l = (0, d.oW)(),
                    r = "".concat(l.wwwSite.pc, "/support/terms-policy"),
                    i = function() {
                        (0, ge.otClick)({
                            tip: {
                                a: 16,
                                b: 107,
                                c: "support_terms",
                                d: 0,
                                e: 17013
                            },
                            elementName: "view_more",
                            elementTitle: o.get("b24344b6a2c4a94c9b0d0ebd4602aeca"),
                            link: r,
                            isOpenGA: !0
                        })
                    };
                return a.createElement("div", {
                    className: "support-terms"
                }, a.createElement("div", {
                    className: "support-terms__header"
                }, a.createElement(u.z, {
                    className: "support-terms__title",
                    withArrow: "pc-only",
                    btnType: "link",
                    href: r,
                    onClick: function() {
                        return i()
                    }
                }, o.get("3b6c2b4caaf4f14f8d7feeddc4ac3f4d")), n && a.createElement(u.z, {
                    className: "support-terms__more",
                    withArrow: "m-only",
                    btnType: "link",
                    href: r,
                    onClick: function() {
                        return i()
                    }
                }, o.get("b24344b6a2c4a94c9b0d0ebd4602aeca"))), a.createElement("ul", {
                    className: "support-terms__list"
                }, t.map((function(e) {
                    return a.createElement("li", {
                        key: e.hash,
                        className: "support-terms__item",
                        role: "button",
                        tabIndex: 0,
                        onClick: function() {
                            var t, n;
                            t = e.title, n = e.hash, (0, ge.otClick)({
                                tip: {
                                    a: 16,
                                    b: 107,
                                    c: "support_terms",
                                    d: 0,
                                    e: 17013
                                },
                                elementName: n,
                                elementTitle: t,
                                link: "".concat(r, "#").concat(n),
                                isOpenGA: !0
                            }), window.location.assign("".concat(r, "#").concat(n))
                        }
                    }, a.createElement("div", {
                        className: "support-terms__text"
                    }, e.title || e.hash), n && a.createElement(w.q, {
                        symbol: "link-arrow"
                    }))
                }))))
            }
            var Pn = n(68673),
                An = n(72988),
                Ln = n(90063),
                Dn = function() {
                    return Dn = Object.assign || function(e) {
                        for (var t, n = 1, a = arguments.length; n < a; n++)
                            for (var o in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
                        return e
                    }, Dn.apply(this, arguments)
                };

            function Fn(e) {
                var t = e.extends,
                    n = t.consumer_service,
                    o = void 0 === n ? [] : n,
                    l = t.terms_category,
                    r = void 0 === l ? [] : l;
                return a.createElement("div", {
                    className: "support-contact__wrapper",
                    "data-ot-expose": JSON.stringify({
                        tip: {
                            c: 1
                        },
                        pageType: "support",
                        elementName: "contact",
                        isOpenGA: !0
                    })
                }, a.createElement("div", {
                    className: "support-contact"
                }, a.createElement(In, {
                    contactData: o
                })), a.createElement("div", {
                    className: "support-term"
                }, a.createElement(Un, {
                    termsData: r
                })))
            }

            function jn(e) {
                var t = (0, d.oW)();
                return a.createElement(Ln._, {
                    siteConfig: t
                }, a.createElement(An.s, {
                    siteConfig: t
                }, a.createElement(Pn.$, {
                    siteConfig: t
                }, a.createElement(Fn, Dn({}, e)))))
            }
            var zn = function(e, t) {
                var n = "function" == typeof Symbol && e[Symbol.iterator];
                if (!n) return e;
                var a, o, l = n.call(e),
                    r = [];
                try {
                    for (;
                        (void 0 === t || t-- > 0) && !(a = l.next()).done;) r.push(a.value)
                } catch (i) {
                    o = {
                        error: i
                    }
                } finally {
                    try {
                        a && !a.done && (n = l.return) && n.call(l)
                    } finally {
                        if (o) throw o.error
                    }
                }
                return r
            };

            function qn(e) {
                var t, n, o, r = e.title,
                    i = e.subtitle,
                    c = e.images,
                    s = e.videos,
                    u = e.otModule,
                    m = e.classModify,
                    d = zn((0, a.useState)(!1), 2),
                    v = d[0],
                    f = d[1],
                    p = "service-video",
                    g = (0, a.useRef)(null),
                    _ = function(e) {
                        var t, n;
                        f(e), e ? null === (t = g.current) || void 0 === t || t.play() : null === (n = g.current) || void 0 === n || n.load()
                    };
                return a.createElement("section", {
                    className: l((t = {
                        "service-video": !0
                    }, t["service-video--".concat(m)] = !!m, t)),
                    "data-ot-expose": JSON.stringify({
                        tip: {
                            c: u
                        }
                    }),
                    style: (null === (n = c[0]) || void 0 === n ? void 0 : n.src.widescreen) ? {
                        backgroundImage: "url('".concat(null === (o = c[0]) || void 0 === o ? void 0 : o.src.widescreen, "')")
                    } : {}
                }, a.createElement("div", {
                    className: "".concat(p, "__wrapper")
                }, a.createElement("img", {
                    className: "".concat(p, "__button"),
                    src: "//i05.appmifile.com/172_operator_es/21/10/2022/bfdf9b095156748808a07e4ebd65bb4a.png",
                    alt: "play",
                    role: "button",
                    tabIndex: 0,
                    onClick: function(e) {
                        e.stopPropagation(), _(!0)
                    }
                }), a.createElement("div", {
                    className: "service-video__content"
                }, a.createElement("div", {
                    className: "".concat(p, "__title")
                }, r), a.createElement("div", {
                    className: "".concat(p, "__subtitle")
                }, i))), a.createElement(_e.u, {
                    extraClassName: "".concat(p, "__modal"),
                    isModalShow: v,
                    isShowCloseIcon: !0,
                    shouldCloseOnOverlayClick: !1,
                    closeModal: function() {
                        _(!1)
                    }
                }, a.createElement("video", {
                    loop: !0,
                    muted: !0,
                    preload: "auto",
                    autoPlay: !0,
                    playsInline: !0,
                    controls: !0
                }, a.createElement("source", {
                    src: s[0].url
                }))))
            }

            function Bn(e) {
                var t, n, o, l = e.title,
                    i = e.subtitle,
                    c = e.tips,
                    s = e.images,
                    u = e.style,
                    m = "image-with-desc";
                return a.createElement("div", {
                    className: r()(m, (t = {}, t["".concat(m, "--reverse")] = 2 === u, t))
                }, a.createElement("img", {
                    className: "".concat(m, "__image"),
                    src: null === (o = null === (n = null == s ? void 0 : s[0]) || void 0 === n ? void 0 : n.src) || void 0 === o ? void 0 : o.widescreen,
                    alt: ""
                }), a.createElement("div", {
                    className: "".concat(m, "__spacer")
                }), a.createElement("div", {
                    className: "".concat(m, "__caption")
                }, a.createElement("h3", {
                    className: "".concat(m, "__title")
                }, l), a.createElement("h4", {
                    className: "".concat(m, "__subtitle")
                }, i), a.createElement("p", {
                    className: "".concat(m, "__description")
                }, c)))
            }

            function Wn(e) {
                var t, n, o = e.images;
                return a.createElement("div", {
                    className: "service-background-img"
                }, a.createElement(i.t, {
                    className: "service-background__image",
                    alt: null === (t = o[0]) || void 0 === t ? void 0 : t.alt,
                    srcSet: (null === (n = o[0]) || void 0 === n ? void 0 : n.src) || []
                }))
            }

            function Rn(e) {
                var t = e.siftList,
                    n = (0, o.k6)(),
                    l = (0, o.UO)(),
                    i = "bubble-switcher";
                return t.length ? a.createElement("div", {
                    className: i
                }, t.map((function(e, t) {
                    var o;
                    return a.createElement(u.z, {
                        key: "".concat(e.path, "-").concat(t),
                        className: r()("".concat(i, "__button"), (o = {}, o["".concat(i, "__button--current")] = l.pathname ? l.pathname === e.path : "" === e.path, o)),
                        onClick: function() {
                            return n.push("/about".concat("index" === e.path ? "" : "/".concat(e.path)))
                        }
                    }, e.title)
                }))) : a.createElement(a.Fragment, null)
            }
            var Jn = ["large", "medium", "small"];

            function Gn(e) {
                var t, n = e.style;
                return a.createElement("div", {
                    className: l("block-blank", (t = {}, t["block-blank--".concat(Jn[n - 1] || "default")] = !!n, t))
                })
            }
            var Yn = function() {
                return Yn = Object.assign || function(e) {
                    for (var t, n = 1, a = arguments.length; n < a; n++)
                        for (var o in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
                    return e
                }, Yn.apply(this, arguments)
            };

            function Vn(e) {
                return a.createElement(p, Yn({}, e, {
                    tips: "",
                    type: "default",
                    bannerType: "flex",
                    goods: [],
                    buttons: []
                }))
            }

            function Zn(e) {
                var t, n = e.title,
                    o = e.tips,
                    r = e.otModule,
                    i = e.classModify;
                return a.createElement("div", {
                    className: l((t = {
                        "text-note": !0
                    }, t["text-note--".concat(i)] = !!i, t)),
                    "data-ot-expose": JSON.stringify({
                        tip: {
                            c: r
                        }
                    })
                }, o ? a.createElement(Rt.I, {
                    className: "text-note__content text-note__link",
                    href: o,
                    target: "_blank"
                }, n) : a.createElement("p", {
                    className: "text-note__content"
                }, n))
            }
            var Hn = function() {
                return Hn = Object.assign || function(e) {
                    for (var t, n = 1, a = arguments.length; n < a; n++)
                        for (var o in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
                    return e
                }, Hn.apply(this, arguments)
            };

            function Qn(e) {
                return a.createElement(p, Hn({}, e, {
                    goods: [],
                    tips: "",
                    type: "image",
                    bannerType: "links"
                }))
            }
            var $n = function() {
                    return $n = Object.assign || function(e) {
                        for (var t, n = 1, a = arguments.length; n < a; n++)
                            for (var o in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
                        return e
                    }, $n.apply(this, arguments)
                },
                Kn = a.lazy((function() {
                    return Promise.all([n.e(8198), n.e(5720)]).then(n.bind(n, 65720))
                }));

            function Xn(e) {
                return a.createElement(Le, {
                    fallback: a.createElement(q.a, {
                        type: "inner"
                    })
                }, a.createElement(Kn, $n({}, e)))
            }
            var ea = function() {
                    return ea = Object.assign || function(e) {
                        for (var t, n = 1, a = arguments.length; n < a; n++)
                            for (var o in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
                        return e
                    }, ea.apply(this, arguments)
                },
                ta = a.lazy((function() {
                    return Promise.all([n.e(7595), n.e(2959)]).then(n.bind(n, 15714))
                }));

            function na(e) {
                return a.createElement(Le, {
                    fallback: a.createElement(a.Fragment, null)
                }, a.createElement(ta, ea({}, e)))
            }
            var aa = "about-years";

            function oa(e) {
                var t = e.title,
                    n = e.subtitle,
                    o = (0, d.YB)();
                return a.createElement("div", {
                    className: "about-years"
                }, a.createElement("span", {
                    className: "".concat(aa, "__background")
                }, t), a.createElement("span", {
                    className: "".concat(aa, "__main")
                }, t), a.createElement("div", {
                    className: "".concat(aa, "-line-group")
                }, a.createElement("div", {
                    className: "".concat(aa, "__line")
                }), a.createElement("span", {
                    className: "".concat(aa, "__text")
                }, o.get("e4a00407f4e14849a66f076123f38494")), a.createElement("div", {
                    className: "".concat(aa, "__line")
                })), a.createElement("span", {
                    className: "".concat(aa, "__content")
                }, n))
            }
            var la = n(13845),
                ra = n(48651),
                ia = n(21102),
                ca = n(25729),
                sa = n(39116),
                ua = (0, Cn.Nr)();

            function ma(e) {
                var t = e.stepInfo,
                    n = e.otModule,
                    o = e.otClick,
                    l = e.reportOtEvent,
                    r = (0, ra.v)(!1, !0),
                    i = (0, a.useContext)(ca.IW).dispatch,
                    c = (0, a.useContext)(sa.kn).state,
                    s = ua ? c.companyStatus === ia.S.PENDING ? "auditing" : "upgrade_account" : "sign_in";
                if (!(null == t ? void 0 : t.length)) return null;

                function m(e) {
                    e.stopPropagation(), l("click", s), i({
                        type: ca.gJ.SET_IS_SHOW_BUSINESS_MODAL,
                        payload: !0
                    })
                }
                return a.createElement("div", {
                    className: "site-process__steps"
                }, a.createElement("ul", {
                    className: "step__list"
                }, t.map((function(e, t) {
                    return a.createElement("li", {
                        key: "".concat(e.stepDesc, "-").concat(t),
                        className: "step__item",
                        role: "presentation",
                        onClick: function() {
                            return e.stepUrl && function(e, t, a) {
                                o({
                                    tip: {
                                        c: n,
                                        d: t + 1
                                    },
                                    elementTitle: "shopping_introduce",
                                    elementName: a,
                                    link: e,
                                    isOpenGA: !0
                                }), window.open(e, "_blank")
                            }(null == e ? void 0 : e.stepUrl, t, e.stepDesc)
                        }
                    }, a.createElement("img", {
                        className: "step__image",
                        src: e.imageUrl,
                        alt: e.imageAlt
                    }), a.createElement("span", {
                        className: "step__desc"
                    }, e.stepDesc), e.showBusinessLogin && r && a.createElement(u.z, {
                        btnType: "link",
                        className: "step__business-login",
                        onClick: m,
                        withArrow: "enable",
                        "data-ot-expose": JSON.stringify({
                            tip: {
                                c: n
                            },
                            elementTitle: "shopping_introduce",
                            elementName: s,
                            isOpenGA: !0
                        })
                    }, a.createElement("span", {
                        className: "step__business-login--text"
                    }, r)))
                }))))
            }
            var da = n(99548),
                va = n(1159),
                fa = ["#ffffff", "#f7f7f7"],
                pa = function(e, t) {
                    var n = "function" == typeof Symbol && e[Symbol.iterator];
                    if (!n) return e;
                    var a, o, l = n.call(e),
                        r = [];
                    try {
                        for (;
                            (void 0 === t || t-- > 0) && !(a = l.next()).done;) r.push(a.value)
                    } catch (i) {
                        o = {
                            error: i
                        }
                    } finally {
                        try {
                            a && !a.done && (n = l.return) && n.call(l)
                        } finally {
                            if (o) throw o.error
                        }
                    }
                    return r
                };

            function ga(e) {
                var t, n, o, l, i, c, s = e.title,
                    u = e.subtitle,
                    m = e.classModify,
                    f = e.otModule,
                    p = e.otClick,
                    g = e.extends,
                    _ = e.images,
                    b = e.style,
                    y = "site-process",
                    E = (0, d.YB)(),
                    h = (0, d.oW)(),
                    N = (0, C.a)(),
                    k = (0, da.A)(),
                    x = "mobile" === N,
                    S = (0, v.VL)(va.LH.get("topNotified")),
                    T = pa((0, a.useState)(""), 2),
                    O = T[0],
                    I = T[1],
                    M = pa((0, a.useState)(!0), 2),
                    U = M[0],
                    P = M[1],
                    A = pa((0, a.useState)("success"), 2),
                    L = A[0],
                    D = A[1],
                    F = (0, a.useMemo)((function() {
                        return _.map((function(e, t) {
                            var n, a, o;
                            return {
                                imageUrl: e.src.widescreen || "",
                                imageAlt: e.alt || "",
                                stepDesc: (null === (n = null == g ? void 0 : g.steps) || void 0 === n ? void 0 : n[t]) || "",
                                stepUrl: (null === (a = null == g ? void 0 : g.stepsUrl) || void 0 === a ? void 0 : a[t]) || "",
                                showBusinessLogin: k && !!(null === (o = null == g ? void 0 : g.stepsShowBusinessLogin) || void 0 === o ? void 0 : o[t]) || !1
                            }
                        }))
                    }), [_, g]);

                function j(e, t) {
                    var n = {
                        isOpenGA: !0,
                        tip: {
                            c: f,
                            e: "expose" === e ? 16756 : 16719
                        },
                        elementTitle: "shopping_introduce",
                        elementName: t
                    };
                    "expose" === e ? (0, ge.otExpose)(n) : (0, ge.otClick)(n)
                }
                return (0, a.useEffect)((function() {
                    var e = !S || JSON.parse(va.LH.get("topNotified") || "").topNotified;
                    P(e)
                }), []), a.createElement("section", {
                    className: r()((t = {}, t[y] = !0, t["".concat(y, "--").concat(m)] = !!m, t["".concat(y, "--mobile")] = x, t["".concat(y, "--folded")] = !U, t)),
                    "data-ot-expose": JSON.stringify({
                        tip: {
                            c: f
                        },
                        elementTitle: "shopping_introduce"
                    }),
                    style: {
                        backgroundColor: fa[b - 1]
                    }
                }, a.createElement("i", {
                    className: "micon micon-up arrow-up",
                    onClick: function() {
                        return function() {
                            if (U || j("expose"), j("click", U ? "close" : "open"), P(!U), k) {
                                var e = !0;
                                if (S) {
                                    var t = JSON.parse(va.LH.get("topNotified") || "");
                                    e = void 0 === t.indexRibbonAds || t.indexRibbonAds
                                }
                                var n = {
                                    topNotified: !1,
                                    businessProcess: !U,
                                    indexRibbonAds: e
                                };
                                va.LH.set("required", "topNotified", JSON.stringify(n), {
                                    expires: 1,
                                    path: "/" + h.local,
                                    domain: h.stat.cookieDomain
                                })
                            }
                        }()
                    },
                    role: "button",
                    tabIndex: 0
                }), a.createElement("h3", {
                    className: "mi-h3 ".concat(y, "__title")
                }, s), a.createElement("p", {
                    className: "".concat(y, "__subtitle")
                }, u), (null === (o = null == g ? void 0 : g.terms) || void 0 === o ? void 0 : o.title) && (null === (l = null == g ? void 0 : g.terms) || void 0 === l ? void 0 : l.url) && a.createElement(Rt.I, {
                    className: "".concat(y, "__terms"),
                    href: null === (i = null == g ? void 0 : g.terms) || void 0 === i ? void 0 : i.url,
                    withArrow: "enable",
                    target: "_blank"
                }, null === (c = null == g ? void 0 : g.terms) || void 0 === c ? void 0 : c.title), a.createElement(ma, {
                    stepInfo: F,
                    otModule: f,
                    otClick: p,
                    reportOtEvent: j
                }), a.createElement("div", {
                    className: "".concat(y, "__contact")
                }, (null == g ? void 0 : g.email) && a.createElement("div", {
                    className: "contact__info"
                }, a.createElement(w.q, {
                    symbol: "message-smile",
                    className: "contact__icon"
                }), a.createElement("a", {
                    className: r()("".concat(y, "__contact-email"), (n = {}, n["".concat(y, "__contact-email--line")] = null == g ? void 0 : g.phoneNum, n)),
                    href: "mailto:".concat(g.email),
                    onClick: function() {
                        return j("click", "email")
                    }
                }, g.email)), (null == g ? void 0 : g.phoneNum) && a.createElement("div", {
                    className: "contact__info"
                }, a.createElement(w.q, {
                    symbol: "phone",
                    className: "contact__icon"
                }), a.createElement(la.Z, {
                    successCopy: function() {
                        D("success"), I(E.get("a588b1abc58b8b758c4b34b69b9e10bb"))
                    },
                    errorCopy: function() {
                        D("error"), I(E.get("5496a81d145ee0c172e6c616cabbf89c"))
                    },
                    copyValue: g.phoneNum.replace("-", "") || "",
                    onClick: function() {
                        return j("click", "telephone")
                    }
                }, E.get("b38ea4c5ced87aceb03ff86cec9dda93", {
                    phone: g.phoneNum
                })), a.createElement(pt.F, {
                    type: L,
                    msg: O,
                    callback: function() {
                        return I("")
                    }
                }))))
            }

            function _a(e) {
                var t, n = e.type;
                return a.createElement("div", {
                    className: l((t = {
                        "page-gray-scale": !0
                    }, t["page-gray-scale--".concat(n)] = !!n, t))
                }, "color" !== n && a.createElement("style", {
                    dangerouslySetInnerHTML: {
                        __html: "body #root aside, body #root header, body #root main, body #root footer { filter: grayscale(1) }"
                    }
                }))
            }
            var ba = n(85319);

            function ya(e) {
                var t, n = e.otModule,
                    o = e.classModify,
                    r = e.extends.dataList;
                return a.createElement("div", {
                    className: l("official-intro-steps", (t = {}, t["official-intro-steps--".concat(o)] = !!o, t))
                }, a.createElement(oe.t, {
                    className: "official-intro-steps__swiper",
                    slidesPerView: "auto",
                    pagination: {
                        clickable: !0
                    }
                }, r.map((function(e, t) {
                    var o, l;
                    return a.createElement(le.o, {
                        className: "official-intro-steps__slide",
                        key: t
                    }, a.createElement("div", {
                        className: "official-intro-steps__content",
                        onClick: function() {
                            return function(e, t) {
                                (0, ge.otClick)({
                                    tip: {
                                        c: n,
                                        d: t + 1,
                                        e: 16719
                                    },
                                    elementName: e.titleWeb,
                                    link: e.url,
                                    isOpenGA: !0
                                }), (0, v.MN)(e.url)
                            }(e, t)
                        },
                        "aria-hidden": !0,
                        role: "button",
                        "data-ot-expose": JSON.stringify({
                            tip: {
                                c: n,
                                d: t + 1,
                                e: 16756
                            },
                            elementName: e.titleWeb,
                            isOpenGA: !0
                        })
                    }, a.createElement("img", {
                        src: null === (l = null === (o = e.images[0]) || void 0 === o ? void 0 : o.src) || void 0 === l ? void 0 : l.widescreen,
                        alt: "",
                        className: "official-intro-steps__icon"
                    }), a.createElement("div", {
                        className: "official-intro-steps__title"
                    }, a.createElement(ba.i, {
                        className: "official-intro-steps__link",
                        href: e.url
                    }, e.titleWeb))))
                }))))
            }
            X.Z.use([ae.Z]);
            var Ea = function() {
                    return Ea = Object.assign || function(e) {
                        for (var t, n = 1, a = arguments.length; n < a; n++)
                            for (var o in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
                        return e
                    }, Ea.apply(this, arguments)
                },
                ha = function(e, t) {
                    var n = "function" == typeof Symbol && e[Symbol.iterator];
                    if (!n) return e;
                    var a, o, l = n.call(e),
                        r = [];
                    try {
                        for (;
                            (void 0 === t || t-- > 0) && !(a = l.next()).done;) r.push(a.value)
                    } catch (i) {
                        o = {
                            error: i
                        }
                    } finally {
                        try {
                            a && !a.done && (n = l.return) && n.call(l)
                        } finally {
                            if (o) throw o.error
                        }
                    }
                    return r
                };

            function Na(e) {
                var t, n = e.classModify,
                    o = e.skeletonData,
                    r = e.title,
                    i = e.buttons,
                    c = e.extends,
                    s = c.participants,
                    u = c.level,
                    m = c.endTime,
                    v = e.otModule,
                    f = e.otClick,
                    p = (0, d.aU)(),
                    g = (0, d.oW)(),
                    _ = (0, Cn.Jb)(),
                    b = ha((0, a.useState)(!1), 2),
                    y = b[0],
                    E = b[1];

                function h(e) {
                    va.LH.set("required", "index_popup", JSON.stringify({
                        prevDay: (new Date).getDate(),
                        prevType: e,
                        level: u
                    }), {
                        expires: new Date(m),
                        path: "/" + p,
                        domain: g.stat.cookieDomain
                    })
                }

                function N(e, t) {
                    e.stopPropagation(), E(!1),
                        function(e) {
                            var t;
                            f({
                                tip: {
                                    c: v
                                },
                                event: 1 === e ? "click" : "select_promotion",
                                elementName: 1 === e ? "pop_up_cancel" : "pop_up",
                                elementTitle: r || (null === (t = null == i ? void 0 : i[0]) || void 0 === t ? void 0 : t.text) || ""
                            })
                        }(t), h(1 === t ? "close" : "open")
                }

                function k(e) {
                    window.location.href = i[0].gotoUrl, N(e, 2)
                }
                return (0, a.useEffect)((function() {
                    var e, t;
                    e = y, t = document.getElementsByTagName("body")[0].style, e ? (t.height = "100%", t.overflow = "hidden") : (t.height = "", t.overflow = "")
                }), [y]), (0, a.useEffect)((function() {
                    ("allusers" === s || "loginusers" === s && _ || "unloginusers" === s && !_) && function() {
                        var e = va.LH.get("index_popup") || "";
                        if ("hasShowed" === e) return va.LH.remove("index_popup", {
                            path: "/" + p,
                            domain: g.stat.cookieDomain
                        }), !0;
                        if (e) {
                            var t = JSON.parse(e);
                            return "open" === t.prevType && t.prevDay !== (new Date).getDate() && "p0" === t.level
                        }
                        return !0
                    }() && (E(!0), h("close"))
                }), []), a.createElement("div", {
                    className: l((t = {
                        "store-popup": !0
                    }, t["store-popup--".concat(n)] = !!n, t))
                }, o ? a.createElement("div", {
                    className: "store-popup__edit"
                }, a.createElement(ka, Ea({}, e, {
                    goPopup: k
                }))) : y && a.createElement("div", {
                    role: "button",
                    tabIndex: 0,
                    className: "store-popup__mask",
                    onClick: function(e) {
                        N(e, 1)
                    }
                }, a.createElement(ka, Ea({}, e, {
                    goPopup: k
                })), a.createElement("div", {
                    role: "button",
                    tabIndex: 0,
                    className: "store-popup__close",
                    onClick: function(e) {
                        N(e, 1)
                    }
                }, a.createElement("i", {
                    className: "micon micon-close"
                }))))
            }

            function ka(e) {
                var t, n, o = e.skeletonData,
                    r = e.theme,
                    c = e.title,
                    s = e.subtitle,
                    u = e.buttons,
                    m = e.extends,
                    d = m.description,
                    v = m.hideButtons,
                    f = e.images,
                    p = e.otModule,
                    g = e.otExpose,
                    _ = e.goPopup;
                return (0, a.useEffect)((function() {
                    var e, t;
                    if ("function" == typeof g && !o) {
                        var n = g({
                            event: "view_promotion",
                            tip: {
                                c: p
                            },
                            elementName: "pop_up",
                            elementTitle: c || (null === (e = null == u ? void 0 : u[0]) || void 0 === e ? void 0 : e.text) || "",
                            link: (null === (t = null == u ? void 0 : u[0]) || void 0 === t ? void 0 : t.gotoUrl) || ""
                        }, p);
                        (0, ge.otEcommerce)(n)
                    }
                }), []), a.createElement("div", {
                    role: "button",
                    tabIndex: 0,
                    className: l({
                        "store-popup__wrapper": !0,
                        "text-dark": "light" === r
                    }),
                    onClick: function(e) {
                        return _(e)
                    }
                }, !!f.length && a.createElement(i.t, {
                    className: "store-popup__image",
                    alt: c,
                    srcSet: (null === (t = f[0]) || void 0 === t ? void 0 : t.src) || [],
                    lazyLoading: !1
                }), a.createElement("div", {
                    className: "store-popup__content"
                }, a.createElement("div", {
                    className: "store-popup-content__subtitle"
                }, s), a.createElement("div", {
                    className: "store-popup-content__title"
                }, c), a.createElement("div", {
                    className: "store-popup-content__describe"
                }, d), !v && !!(null === (n = null == u ? void 0 : u[0]) || void 0 === n ? void 0 : n.text) && a.createElement("div", {
                    className: l({
                        "store-popup-content__button": !0,
                        "btn-dark": "light" === r
                    })
                }, u[0].text)))
            }

            function xa(e) {
                return a.createElement(Pe.S, {
                    renderDomCb: function() {
                        return a.createElement(a.Fragment, null)
                    }
                }, a.createElement(Na, Ea({}, e)))
            }
            var Sa = function(e, t) {
                    var n = "function" == typeof Symbol && e[Symbol.iterator];
                    if (!n) return e;
                    var a, o, l = n.call(e),
                        r = [];
                    try {
                        for (;
                            (void 0 === t || t-- > 0) && !(a = l.next()).done;) r.push(a.value)
                    } catch (i) {
                        o = {
                            error: i
                        }
                    } finally {
                        try {
                            a && !a.done && (n = l.return) && n.call(l)
                        } finally {
                            if (o) throw o.error
                        }
                    }
                    return r
                },
                wa = (0, on.o)(Oa),
                Ca = (0, a.createContext)(wa);

            function Ta(e) {
                var t = e.siteConfig,
                    n = e.isAutoFetch,
                    o = e.children,
                    l = Sa((0, a.useState)(wa), 2),
                    r = l[0],
                    i = l[1];

                function c(e) {
                    var t = e.data,
                        n = e.errmsg,
                        a = e.errno;
                    return {
                        data: t,
                        errMsg: String(n),
                        errNo: Number(a)
                    }
                }
                var s = {
                    url: "".concat(t.goSite, "/getcoupon/draw"),
                    method: "GET",
                    params: {
                        from: "",
                        act_no: "",
                        coupon_type_id: "",
                        tax_id: "",
                        g_token: ""
                    },
                    withCredentials: !0
                };
                return a.createElement(ln.h, {
                    context: Ca,
                    setState: i,
                    defaultValue: wa,
                    adapterError: function(e) {
                        return c(e)
                    },
                    adapter: c,
                    value: r,
                    siteConfig: t,
                    isAutoFetch: !0 === n,
                    ajaxConfig: s
                }, o)
            }

            function Oa(e) {
                return e
            }
            var Ia = function(e, t) {
                    var n = "function" == typeof Symbol && e[Symbol.iterator];
                    if (!n) return e;
                    var a, o, l = n.call(e),
                        r = [];
                    try {
                        for (;
                            (void 0 === t || t-- > 0) && !(a = l.next()).done;) r.push(a.value)
                    } catch (i) {
                        o = {
                            error: i
                        }
                    } finally {
                        try {
                            a && !a.done && (n = l.return) && n.call(l)
                        } finally {
                            if (o) throw o.error
                        }
                    }
                    return r
                },
                Ma = (0, on.o)(Aa),
                Ua = (0, a.createContext)(Ma);

            function Pa(e) {
                var t = e.siteConfig,
                    n = e.isAutoFetch,
                    o = e.children,
                    l = Ia((0, a.useState)(Ma), 2),
                    r = l[0],
                    i = l[1];

                function c(e) {
                    var t = e.data,
                        n = e.errmsg,
                        a = e.errno;
                    return {
                        data: Aa(t),
                        errMsg: String(n),
                        errNo: Number(a)
                    }
                }
                var s = {
                    url: "".concat(t.goSite, "/activity/getcoupon-detail"),
                    method: "GET",
                    params: {
                        act_no: "",
                        skeletonData: ""
                    },
                    withCredentials: !0
                };
                return a.createElement(ln.h, {
                    context: Ua,
                    setState: i,
                    defaultValue: Ma,
                    adapterError: function(e) {
                        return c(e)
                    },
                    adapter: c,
                    value: r,
                    siteConfig: t,
                    isAutoFetch: !0 === n,
                    ajaxConfig: s
                }, o)
            }

            function Aa(e) {
                return {
                    list: La(Array.from(e || []))
                }
            }

            function La(e) {
                return void 0 === e && (e = []), Array.from(e || []).map((function(e) {
                    return {
                        couponTypeId: e.coupon_type_id || 0,
                        couponTypeName: e.coupon_type_name || "",
                        rangeDesc: e.range_desc || "",
                        validStartTimeStr: e.valid_start_time_str || "",
                        validEndTimeStr: e.valid_end_time_str || "",
                        valueDesc: e.value_desc || "",
                        stock: e.stock || 0,
                        validStartTime: e.valid_start_time || 0,
                        isGet: e.is_get || 0,
                        isRisk: e.is_risk || 0,
                        validDays: e.valid_days || 0,
                        validType: e.valid_type || 0,
                        startTime: e.start_time || 0,
                        endTime: e.end_time || 0,
                        startTimeStr: e.start_time_str || ""
                    }
                }))
            }
            var Da = n(30570),
                Fa = function() {
                    return Fa = Object.assign || function(e) {
                        for (var t, n = 1, a = arguments.length; n < a; n++)
                            for (var o in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
                        return e
                    }, Fa.apply(this, arguments)
                },
                ja = function(e, t) {
                    var n = "function" == typeof Symbol && e[Symbol.iterator];
                    if (!n) return e;
                    var a, o, l = n.call(e),
                        r = [];
                    try {
                        for (;
                            (void 0 === t || t-- > 0) && !(a = l.next()).done;) r.push(a.value)
                    } catch (i) {
                        o = {
                            error: i
                        }
                    } finally {
                        try {
                            a && !a.done && (n = l.return) && n.call(l)
                        } finally {
                            if (o) throw o.error
                        }
                    }
                    return r
                },
                za = "new-user";

            function qa(e) {
                var t = (0, d.oW)();
                return a.createElement(Pa, {
                    siteConfig: t
                }, a.createElement(Ta, {
                    siteConfig: t
                }, a.createElement(Ba, Fa({}, e))))
            }

            function Ba(e) {
                var t = e.otModule,
                    n = e.otClick,
                    o = e.buttons,
                    l = e.extends,
                    i = l.dataList,
                    c = l.group,
                    s = l.styleLink,
                    m = e.skeletonData,
                    v = (0, a.useContext)(Ca),
                    f = (0, a.useContext)(Ua),
                    p = (0, Cn.Jb)(),
                    g = (0, d.YB)(),
                    _ = (0, d.oW)(),
                    b = ja((0, a.useState)(!1), 2),
                    y = b[0],
                    E = b[1],
                    h = ja((0, a.useState)(!1), 2),
                    N = h[0],
                    k = h[1],
                    x = (0, a.useRef)(0),
                    S = ja((0, a.useState)(""), 2),
                    w = S[0],
                    T = S[1],
                    O = ja((0, a.useState)(i), 2),
                    I = O[0],
                    M = O[1],
                    U = "mobile" === (0, C.a)();
                return (0, a.useEffect)((function() {
                    return (null == c ? void 0 : c.endTime) > (new Date).getTime() / 1e3 && f.getService({
                            params: {
                                act_no: c.actNo,
                                skeletonData: !!m
                            }
                        }, (function(e) {
                            var t, n, a, o;
                            M(e.data.list), E(0 !== (null === (t = null == e ? void 0 : e.data) || void 0 === t ? void 0 : t.list.length)), (null === (n = null == e ? void 0 : e.data) || void 0 === n ? void 0 : n.list) && (null === (o = null === (a = null == e ? void 0 : e.data) || void 0 === a ? void 0 : a.list.filter((function(e) {
                                return 1 === (null == e ? void 0 : e.isRisk)
                            }))) || void 0 === o ? void 0 : o.length) > 0 && 0 === document.querySelectorAll(".google-captcha").length && k(!0)
                        })),
                        function() {}
                }), []), a.createElement("div", {
                    className: "big-box",
                    "data-ot-expose": JSON.stringify({
                        tip: {
                            c: t
                        },
                        elementTitle: "coupon_claim",
                        elementName: "coupon_claim",
                        isOpenGA: !0
                    })
                }, a.createElement("div", {
                    className: r()({
                        "new-user new-user--full": 1 === Number(s),
                        "new-user new-user--half": 2 === Number(s),
                        "new-user new-user--trisection": 8 === Number(s)
                    })
                }, Array.from(I || []).map((function(e, o) {
                    return a.createElement("div", {
                        className: "content",
                        key: o
                    }, a.createElement("div", {
                        className: "".concat(za, "__left")
                    }, a.createElement("div", {
                        className: "".concat(za, "__left-textbox")
                    }, a.createElement("p", {
                        className: r()({
                            "new-user__left-textbox-title--gray": 0 === e.stock && e.isGet >= 0,
                            "new-user__left-textbox-title": !0
                        })
                    }, e.couponTypeName), a.createElement("p", {
                        className: r()({
                            "new-user__left-textbox-subtitle": !0,
                            "new-user__left-textbox-subtitle--gray": 0 === e.stock && e.isGet >= 0
                        })
                    }, 1 === e.validType ? a.createElement("label", null, g.get("87e9ee269b4d3cbf7727ce4f37011e40", {
                        n: e.validDays
                    })) : a.createElement("label", null, g.get("6dc8368033b050eb8c77c81d5c0aba53", {
                        validStartTime: e.validStartTimeStr,
                        validEndTime: e.validEndTimeStr
                    }))), "" !== e.rangeDesc && a.createElement(Wa, {
                        itemLi: e
                    })), a.createElement("span", {
                        className: "top-right"
                    }), a.createElement("span", {
                        className: "bottom-right"
                    })), a.createElement("div", {
                        className: "".concat(za, "__right")
                    }, a.createElement("div", {
                        className: "right-box"
                    }, a.createElement("p", {
                        className: r()({
                            "new-user__right-price": !0,
                            "new-user__right-price--gray": 0 === e.stock && e.isGet >= 0
                        })
                    }, e.valueDesc), a.createElement("button", {
                        className: r()({
                            "new-user__right-link": !0,
                            "new-user__right-link--white": e.stock >= 0 && 1 === e.isGet,
                            "new-user__right-link--gray": 0 === e.stock && e.isGet >= 0
                        }),
                        onClick: function() {
                            return function(e, a) {
                                p ? (n({
                                    tip: {
                                        c: t,
                                        d: a
                                    },
                                    elementTitle: "collect",
                                    elementName: "coupon_claim",
                                    coupon_list: e
                                }), 1 === e.isRisk ? (x.current = e.couponTypeId, document.querySelectorAll(".google-captcha")[0].classList.add("google-captcha--show")) : e.startTime > (new Date).getTime() / 1e3 ? T(g.get("6e02104f04edc64118ce1a74f8b6fd9c", {
                                    startTimeStr: e.startTimeStr
                                })) : e.endTime < (new Date).getTime() / 1e3 ? T(g.get("eaad5f344da3b7674d4ad536f4a8fd20")) : v.getService({
                                    params: {
                                        act_no: c.actNo,
                                        coupon_type_id: e.couponTypeId,
                                        from: U ? "mobile" : "pc",
                                        tax_id: "",
                                        g_token: ""
                                    }
                                }, (function(e) {
                                    0 === (null == e ? void 0 : e.errNo) && (T(g.get("e79b9103f826cac2f7f5c2fadc216d7c")), f.getService({
                                        params: {
                                            act_no: c.actNo,
                                            skeletonData: !!m
                                        }
                                    }, (function(e) {
                                        M(e.data.list)
                                    })))
                                }))) : (0, Cn.XR)({
                                    siteConfig: _
                                })
                            }(e, o)
                        }
                    }, 1 === e.isGet && e.stock >= 0 ? g.get("ac5bb077c33753116b5e91ff1766e7bc") : null, 0 === e.stock && 0 === e.isGet ? g.get("e990b6285ed2a575c561235378a5e691") : null, 0 === e.isGet && e.stock > 0 ? g.get("e7ca851922b13f555127b04b70435ca9") : null))))
                })), N && a.createElement(Da.S, {
                    siteKey: "6Le2lq4ZAAAAAICguqzsVnvy9ZTCNYzl3fZyJJ9Q",
                    callback: function(e) {
                        return function(e) {
                            var t;
                            document.querySelectorAll(".google-captcha")[0].classList.remove("google-captcha--show"), null === (t = window.grecaptcha) || void 0 === t || t.reset(document.querySelectorAll(".google-captcha")[0]), v.getService({
                                params: {
                                    from: U ? "mobile" : "pc",
                                    act_no: c.actNo,
                                    coupon_type_id: x.current,
                                    tax_id: "",
                                    g_token: e
                                }
                            }, (function(e) {
                                0 === (null == e ? void 0 : e.errNo) ? (T(g.get("e79b9103f826cac2f7f5c2fadc216d7c")), f.getService({
                                    params: {
                                        act_no: c.actNo,
                                        skeletonData: !!m
                                    }
                                }, (function(e) {
                                    M(e.data.list)
                                }))) : T(g.get("eaad5f344da3b7674d4ad536f4a8fd20"))
                            }))
                        }(e)
                    },
                    scmGoogleConfig: _.google
                }), a.createElement(pt.F, {
                    msg: w,
                    callback: function() {
                        return T("")
                    }
                })), y && o.filter((function(e) {
                    return e.text && e.gotoUrl
                })).map((function(e, t) {
                    return a.createElement(a.Fragment, {
                        key: t
                    }, a.createElement(u.z, {
                        btnType: "link",
                        href: e.gotoUrl,
                        className: "tan-btn--one"
                    }, e.text))
                })))
            }

            function Wa(e) {
                var t = e.itemLi,
                    n = ja((0, a.useState)(!1), 2),
                    o = n[0],
                    l = n[1];
                return a.createElement("div", {
                    className: "tips-div"
                }, a.createElement("div", {
                    className: r()({
                        "new-user__left-textbox-tips": !0,
                        "new-user__left-textbox-tips--gray": 0 === t.stock && t.isGet >= 0
                    })
                }, t.rangeDesc, a.createElement(a.Fragment, null, a.createElement(_e.u, {
                    isModalShow: o,
                    closeModal: function() {
                        return l(!1)
                    },
                    isShowCloseIcon: !0,
                    extraClassName: "tips-modal"
                }, a.createElement("p", {
                    className: "tan"
                }, t.rangeDesc)))), a.createElement("span", {
                    className: r()({
                        "tips-popover--gray": 0 === t.stock && t.isGet >= 0,
                        "tips-popover": !0
                    }),
                    role: "presentation",
                    onClick: function() {
                        l(!0)
                    }
                }, a.createElement(w.q, {
                    symbol: "question",
                    className: r()({
                        "icon-gray": 0 === t.stock && t.isGet >= 0,
                        "icon-orange": !0
                    })
                })))
            }
            var Ra = function(e, t) {
                    var n = "function" == typeof Symbol && e[Symbol.iterator];
                    if (!n) return e;
                    var a, o, l = n.call(e),
                        r = [];
                    try {
                        for (;
                            (void 0 === t || t-- > 0) && !(a = l.next()).done;) r.push(a.value)
                    } catch (i) {
                        o = {
                            error: i
                        }
                    } finally {
                        try {
                            a && !a.done && (n = l.return) && n.call(l)
                        } finally {
                            if (o) throw o.error
                        }
                    }
                    return r
                },
                Ja = (0, on.o)(Va),
                Ga = (0, a.createContext)(Ja);

            function Ya(e) {
                var t = e.siteConfig,
                    n = e.isAutoFetch,
                    o = e.children,
                    l = Ra((0, a.useState)(Ja), 2),
                    r = l[0],
                    i = l[1];

                function c(e) {
                    var t = e.data,
                        n = e.errmsg,
                        a = e.errno;
                    return {
                        data: Va(t),
                        errMsg: String(n),
                        errNo: Number(a)
                    }
                }
                var s = {
                    url: "".concat(t.goSite, "/user/extend-info"),
                    method: "GET",
                    params: {
                        type: "is_new_user"
                    },
                    withCredentials: !0
                };
                return a.createElement(ln.h, {
                    context: Ga,
                    setState: i,
                    defaultValue: Ja,
                    adapterError: function(e) {
                        return c(e)
                    },
                    adapter: c,
                    value: r,
                    siteConfig: t,
                    isAutoFetch: !0 === n,
                    ajaxConfig: s
                }, o)
            }

            function Va(e) {
                return {
                    isNewUser: e.is_new_user || ""
                }
            }
            var Za = function() {
                    return Za = Object.assign || function(e) {
                        for (var t, n = 1, a = arguments.length; n < a; n++)
                            for (var o in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
                        return e
                    }, Za.apply(this, arguments)
                },
                Ha = function(e, t) {
                    var n = "function" == typeof Symbol && e[Symbol.iterator];
                    if (!n) return e;
                    var a, o, l = n.call(e),
                        r = [];
                    try {
                        for (;
                            (void 0 === t || t-- > 0) && !(a = l.next()).done;) r.push(a.value)
                    } catch (i) {
                        o = {
                            error: i
                        }
                    } finally {
                        try {
                            a && !a.done && (n = l.return) && n.call(l)
                        } finally {
                            if (o) throw o.error
                        }
                    }
                    return r
                };

            function Qa(e) {
                var t = (0, d.oW)();
                return a.createElement(Ya, {
                    siteConfig: t
                }, a.createElement($a, Za({}, e)))
            }

            function $a(e) {
                var t, n, o, r = e.classModify,
                    i = e.skeletonData,
                    c = e.buttons,
                    s = e.title,
                    m = e.tips,
                    d = a.useContext(Ga),
                    v = Ha(a.useState(!1), 2),
                    f = v[0],
                    p = v[1],
                    g = (0, Cn.Jb)();
                return a.useEffect((function() {
                    return !i && g && d.getService({
                            params: {
                                type: "is_new_user"
                            }
                        }, (function(e) {
                            p(!("true" === (null == e ? void 0 : e.data.isNewUser)))
                        })),
                        function() {}
                }), []), a.createElement("div", {
                    className: l((t = {
                        "new-user-module": !0
                    }, t["new-user-module--".concat(r)] = !!r, t))
                }, a.createElement(_e.u, {
                    isModalShow: f,
                    closeModal: function() {
                        return !1
                    },
                    isShowCloseIcon: !1
                }, a.createElement("h3", null, s), a.createElement("p", null, m), a.createElement("div", {
                    className: "tan-box"
                }, a.createElement(u.z, {
                    btnType: "link",
                    href: null === (n = c[0]) || void 0 === n ? void 0 : n.gotoUrl,
                    className: "tan-btn"
                }, null === (o = c[0]) || void 0 === o ? void 0 : o.text))))
            }
            var Ka = a.lazy((function() {
                return Promise.all([n.e(8986), n.e(51)]).then(n.bind(n, 20051))
            }));

            function Xa() {
                return a.createElement(Le, null, a.createElement(Ka, null))
            }

            function eo(e) {
                var t, n, o = e.extends,
                    r = e.classModify,
                    i = e.otModule,
                    c = e.otClick,
                    s = o.dataList,
                    u = void 0 === s ? [] : s,
                    m = o.skeletonData,
                    f = (null === (n = u[0]) || void 0 === n ? void 0 : n.title) ? u : m,
                    p = (0, d.YB)();
                return a.createElement("div", {
                    className: "support-quick"
                }, a.createElement("div", {
                    className: "support-quick-title"
                }, p.get("5afcfb2bc1df9072db7003bc60cb108b")), a.createElement("div", {
                    className: l((t = {
                        "support-quick-enter": !0
                    }, t["official-intro-steps--".concat(r)] = !!r, t))
                }, f.map((function(e, t) {
                    return a.createElement("div", {
                        key: t,
                        className: "support-quick-enter-item",
                        "aria-hidden": !0,
                        role: "button",
                        "data-ot-expose": JSON.stringify({
                            tip: {
                                c: "".concat(i, "|").concat(t + 1),
                                d: 0
                            },
                            elementName: "support",
                            elementTitle: e.title
                        }),
                        onClick: function() {
                            return function(e, t) {
                                c({
                                    tip: {
                                        c: "".concat(i, "|").concat(t + 1),
                                        d: 0
                                    },
                                    elementName: "support",
                                    elementTitle: e.title
                                }), (0, v.MN)(e.url, "blank")
                            }(e, t)
                        }
                    }, a.createElement("div", {
                        className: "support-quick-enter-item__icon"
                    }, a.createElement(w.q, {
                        symbol: e.type
                    })), a.createElement("div", {
                        className: "support-quick-enter-item__title"
                    }, a.createElement(ba.i, {
                        href: e.url
                    }, e.title)), a.createElement("div", {
                        className: "support-quick-enter-item__describe"
                    }, e.subtitle))
                }))))
            }
            var to = function(e, t) {
                var n = "function" == typeof Symbol && e[Symbol.iterator];
                if (!n) return e;
                var a, o, l = n.call(e),
                    r = [];
                try {
                    for (;
                        (void 0 === t || t-- > 0) && !(a = l.next()).done;) r.push(a.value)
                } catch (i) {
                    o = {
                        error: i
                    }
                } finally {
                    try {
                        a && !a.done && (n = l.return) && n.call(l)
                    } finally {
                        if (o) throw o.error
                    }
                }
                return r
            };

            function no(e) {
                var t = e.dataList,
                    n = e.otModule,
                    o = e.layoutIndex,
                    r = e.otClick,
                    c = (0, d.YB)(),
                    s = to((0, a.useState)(!1), 2),
                    u = s[0],
                    m = s[1],
                    v = to((0, a.useState)(""), 2),
                    f = v[0],
                    p = v[1],
                    g = to((0, a.useState)(""), 2),
                    _ = g[0],
                    b = g[1],
                    y = (0, a.useRef)(),
                    E = function(e, t) {
                        var a = e.type,
                            o = e.title,
                            l = e.gotoUrl,
                            i = void 0 === l ? "" : l,
                            c = e.images,
                            s = void 0 === c ? {} : c;
                        i && ("page" === a ? window.open(i) : (m(!0), b(s[0].src.widescreen), p(i)), r({
                            tip: {
                                c: n,
                                d: t + 1
                            },
                            elementName: "explore",
                            elementTitle: "".concat("video" === a ? "video" : "image", "_").concat(o)
                        }))
                    };
                return a.createElement("div", {
                    className: "explore-pc"
                }, a.createElement("div", {
                    className: "explore-header"
                }, a.createElement("div", {
                    className: "explore-header-pc"
                }, a.createElement("div", {
                    className: "explore-header-pc__title"
                }, c.get("855aea4360d427bf7065ebfc78ffb3ad")), a.createElement("div", {
                    className: "explore-header-pc__button"
                }, ["left", "right"].map((function(e) {
                    return a.createElement(w.q, {
                        key: e,
                        className: "explore-header-pc__button-".concat(e),
                        symbol: "fill-arrow-".concat(e),
                        onClick: function() {
                            var t, n;
                            "left" === e ? null === (t = null == y ? void 0 : y.current) || void 0 === t || t.slidePrev() : null === (n = null == y ? void 0 : y.current) || void 0 === n || n.slideNext()
                        }
                    })
                }))))), a.createElement(oe.t, {
                    onSwiper: function(e) {
                        y.current = e
                    },
                    loop: !0,
                    slidesPerView: "auto",
                    centeredSlides: !0,
                    autoplay: {
                        delay: 6e3,
                        disableOnInteraction: !1
                    }
                }, null == t ? void 0 : t.map((function(e, t) {
                    var r, s, u, m, d, v, f = e.title,
                        p = e.type,
                        g = e.subtitle,
                        _ = e.images,
                        b = void 0 === _ ? {} : _,
                        y = e.gotoUrl,
                        h = void 0 === y ? "" : y;
                    return a.createElement(le.o, {
                        key: t,
                        className: "explore-pc__slide"
                    }, a.createElement("div", {
                        "data-ot-expose": JSON.stringify({
                            tip: {
                                c: n,
                                d: t + 1
                            },
                            elementName: "explore",
                            elementTitle: "".concat("video" === p ? "video" : "image", "_").concat(f)
                        })
                    }, a.createElement("div", {
                        className: "explore-pc__slide-img",
                        role: "button",
                        tabIndex: 0,
                        onClick: function() {
                            E(e, t)
                        }
                    }, a.createElement(i.t, {
                        className: "explore-pc__slide-discover-img",
                        alt: (null === (r = b[0]) || void 0 === r ? void 0 : r.alt) || "",
                        srcSet: {
                            desktop: (null === (s = b[0]) || void 0 === s ? void 0 : s.src.widescreen) || "",
                            laptop: (null === (u = b[0]) || void 0 === u ? void 0 : u.src.widescreen) || "",
                            mobile: (null === (m = b[0]) || void 0 === m ? void 0 : m.src.widescreen) || "",
                            tablet: (null === (d = b[0]) || void 0 === d ? void 0 : d.src.widescreen) || "",
                            widescreen: (null === (v = b[0]) || void 0 === v ? void 0 : v.src.widescreen) || ""
                        },
                        lazyLoading: o > 2
                    }), a.createElement("div", {
                        className: "explore-pc__slide-discover-play"
                    }, "video" === p && a.createElement(w.q, {
                        symbol: "play-square-filled"
                    }))), a.createElement("div", {
                        className: "explore-pc__slide-info"
                    }, a.createElement("div", {
                        className: l({
                            "explore-pc__slide-info-title": !0
                        })
                    }, "video" === p ? f : a.createElement(ba.i, {
                        href: h
                    }, f)), a.createElement("div", {
                        className: l({
                            "explore-pc__slide-info-content": !0
                        })
                    }, a.createElement("div", {
                        className: l({
                            "explore-pc__slide-info-subtitle": !0,
                            "explore-pc__slide-info-subtitle-hover": h
                        })
                    }, g), h && a.createElement("div", {
                        className: l({
                            "explore-pc__slide-info-button": !0,
                            "explore-pc__slide-info-button-hover": h
                        }),
                        role: "button",
                        tabIndex: 0,
                        onClick: function() {
                            E(e, t)
                        }
                    }, "video" === p ? c.get("061bc8eb5a55c300d852edc9af89a288") : c.get("d59048f21fd887ad520398ce677be586"))))))
                }))), a.createElement(_e.u, {
                    isModalShow: u,
                    extraClassName: "mi-modal-video",
                    closeModal: function() {
                        m(!1)
                    },
                    isShowCloseIcon: !1
                }, a.createElement("video", {
                    src: f,
                    className: "modal-video",
                    autoPlay: !0,
                    loop: !0,
                    poster: _,
                    controls: !0
                })))
            }

            function ao(e) {
                var t = (e || {}).style;
                return a.createElement("div", {
                    className: "exclusive-offers-empty",
                    style: t
                }, a.createElement("div", {
                    className: "exclusive-offers-empty__img"
                }), a.createElement("div", {
                    className: "exclusive-offers-empty__title"
                }), a.createElement("div", {
                    className: "exclusive-offers-empty__subtitle"
                }))
            }
            X.Z.use([ee.Z, ne.Z]);
            var oo = function(e, t) {
                var n = "function" == typeof Symbol && e[Symbol.iterator];
                if (!n) return e;
                var a, o, l = n.call(e),
                    r = [];
                try {
                    for (;
                        (void 0 === t || t-- > 0) && !(a = l.next()).done;) r.push(a.value)
                } catch (i) {
                    o = {
                        error: i
                    }
                } finally {
                    try {
                        a && !a.done && (n = l.return) && n.call(l)
                    } finally {
                        if (o) throw o.error
                    }
                }
                return r
            };

            function lo(e) {
                var t = e.dataList,
                    n = e.otClick,
                    o = e.otModule,
                    r = e.getPageContent,
                    c = e.skeletonData,
                    s = void 0 !== c && c,
                    u = e.layoutIndex,
                    m = oo((0, a.useState)(!1), 2),
                    v = m[0],
                    f = m[1],
                    p = oo((0, a.useState)(""), 2),
                    g = p[0],
                    _ = p[1],
                    b = oo((0, a.useState)(""), 2),
                    y = b[0],
                    E = b[1],
                    h = (0, d.YB)(),
                    N = function(e, t) {
                        var a = e.type,
                            l = e.title,
                            r = e.gotoUrl,
                            i = void 0 === r ? "" : r,
                            c = e.images,
                            s = void 0 === c ? {} : c;
                        i && ("page" === a ? window.open(i) : (f(!0), E(s[0].src.widescreen), _(i)), n({
                            tip: {
                                c: o,
                                d: t + 1
                            },
                            pageType: "index",
                            elementName: "explore",
                            elementTitle: "".concat("video" === a ? "video" : "image", "_").concat(l)
                        }))
                    };
                return a.createElement("div", {
                    className: "explore-mobile"
                }, a.createElement("div", {
                    className: "explore-mobile__header"
                }, a.createElement("div", {
                    className: "explore-mobile__header-title"
                }, h.get("855aea4360d427bf7065ebfc78ffb3ad"))), r || s ? a.createElement(oe.t, {
                    loop: !0,
                    slidesPerView: "auto",
                    centeredSlides: !0,
                    watchSlidesProgress: !0,
                    spaceBetween: 14,
                    pagination: {
                        clickable: !0
                    }
                }, null == t ? void 0 : t.map((function(e, t) {
                    var n, r, c = e.title,
                        s = e.type,
                        m = e.images,
                        d = void 0 === m ? {} : m;
                    return a.createElement(le.o, {
                        key: t
                    }, a.createElement("div", {
                        className: "explore-mobile__slide",
                        "data-ot-expose": JSON.stringify({
                            tip: {
                                c: o,
                                d: t + 1
                            },
                            elementName: "explore",
                            elementTitle: "".concat("video" === s ? "video" : "image", "_").concat(c)
                        })
                    }, a.createElement("div", {
                        className: "explore-mobile__slide-img",
                        role: "button",
                        tabIndex: 0,
                        onClick: function() {
                            N(e, t)
                        }
                    }, a.createElement(i.t, {
                        className: "explore-mobile__slide-discover-img",
                        alt: (null === (n = d[0]) || void 0 === n ? void 0 : n.alt) || "",
                        srcSet: (null === (r = d[0]) || void 0 === r ? void 0 : r.src) || [],
                        lazyLoading: u > 2
                    }), "video" === s && a.createElement("div", {
                        className: "discover-mobile__slide-discover-play"
                    }, a.createElement("img", {
                        src: "//i01.appmifile.com/webfile/globalimg/i18n/other/showPlayIcon.png",
                        alt: "Play Icon"
                    }))), a.createElement("div", {
                        className: l({
                            "explore-mobile__slide-title": !0
                        }),
                        role: "button",
                        tabIndex: 0,
                        onClick: function() {
                            N(e, t)
                        }
                    }, c)))
                }))) : a.createElement(ao, {
                    style: {
                        height: 270
                    }
                }), a.createElement(_e.u, {
                    isModalShow: v,
                    extraClassName: "mi-modal-mobile-video",
                    closeModal: function() {
                        f(!1)
                    },
                    isShowCloseIcon: !1
                }, a.createElement("video", {
                    src: g,
                    className: "modal-video",
                    autoPlay: !0,
                    loop: !0,
                    poster: y,
                    controls: !0
                })))
            }

            function ro(e) {
                var t = e.dataList,
                    n = e.otModule,
                    o = e.otClick,
                    l = e.getPageContent,
                    r = e.skeletonData,
                    i = e.layoutIndex;
                return a.createElement("div", {
                    className: "explore"
                }, a.createElement(lo, {
                    getPageContent: l,
                    dataList: t,
                    otModule: n,
                    skeletonData: r,
                    layoutIndex: i,
                    otClick: o
                }), a.createElement(no, {
                    dataList: t,
                    otModule: n,
                    layoutIndex: i,
                    otClick: o
                }))
            }

            function io(e) {
                var t, n, o = (0, a.useContext)(m.__),
                    l = e.extends,
                    r = e.otModule,
                    i = e.layoutIndex,
                    c = e.otClick,
                    s = l || {},
                    u = s.skeletonData,
                    d = void 0 === u ? [] : u,
                    v = s.dataList,
                    f = void 0 === v ? [] : v,
                    p = (null === (t = f[0]) || void 0 === t ? void 0 : t.title) ? f : d;
                return a.createElement(ro, {
                    getPageContent: ["unsent", "success"].includes(o.ajaxStatus),
                    dataList: p,
                    otModule: r,
                    otClick: c,
                    skeletonData: !(null === (n = f[0]) || void 0 === n ? void 0 : n.title),
                    layoutIndex: i
                })
            }

            function co(e) {
                return a.createElement("div", {
                    className: "carousel-banner-normal-site"
                }, a.createElement("img", {
                    className: "preview-image",
                    src: "//cdn.alsgp0.fds.api.mi-img.com/xiaomi-b2c-i18n-upload/i18n/images/demo/block-thumbnail/block-thumbnail-carousel-banner-normal.png",
                    alt: "preview of layer to be exported"
                }))
            }

            function so(e) {
                var t, n = e.classModify;
                return a.createElement("div", {
                    className: r()((t = {
                        "carousel-banner-important": !0
                    }, t["carousel-banner-important--".concat(n)] = !!n, t))
                }, a.createElement("img", {
                    className: "preview-image",
                    src: "//cdn.alsgp0.fds.api.mi-img.com/xiaomi-b2c-i18n-upload/i18n/images/demo/block-thumbnail/block-thumbnail-carousel-banner-important.png",
                    alt: "preview of layer to be exported"
                }))
            }

            function uo(e) {
                var t, n = e.classModify;
                return a.createElement("div", {
                    className: l((t = {
                        "site-official-service": !0
                    }, t["site-official-service--".concat(n)] = !!n, t))
                }, a.createElement("div", {
                    style: {
                        padding: "10px 0"
                    }
                }, a.createElement("img", {
                    className: "preview-image",
                    src: "//cdn.alsgp0.fds.api.mi-img.com/xiaomi-b2c-i18n-upload/i18n/images/demo/block-thumbnail/block-thumbnail-official-service.png",
                    alt: "preview of layer to be exported"
                })))
            }
            var mo = function() {
                    return mo = Object.assign || function(e) {
                        for (var t, n = 1, a = arguments.length; n < a; n++)
                            for (var o in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
                        return e
                    }, mo.apply(this, arguments)
                },
                vo = a.lazy((function() {
                    return n.e(792).then(n.bind(n, 60537))
                }));

            function fo(e) {
                return a.createElement(Le, {
                    fallback: a.createElement(a.Fragment, null)
                }, a.createElement(vo, mo({}, e)))
            }

            function po(e) {
                var t, n = e.classModify;
                return a.createElement("div", {
                    className: r()((t = {
                        "login-guide": !0
                    }, t["login-guide--".concat(n)] = !!n, t))
                }, a.createElement("div", {
                    style: {
                        padding: "10px 0"
                    }
                }, a.createElement("img", {
                    className: "preview-image",
                    src: "//cdn.alsgp0.fds.api.mi-img.com/xiaomi-b2c-i18n-upload/i18n/images/demo/block-thumbnail/block-thumbnail-login-guide.png",
                    alt: "preview of layer to be exported"
                })))
            }

            function go(e) {
                var t, n = e.classModify;
                return a.createElement("div", {
                    className: r()((t = {
                        recommended: !0
                    }, t["recommended--".concat(n)] = !!n, t))
                }, a.createElement("div", {
                    style: {
                        padding: "10px 0"
                    }
                }, a.createElement("img", {
                    className: "preview-image",
                    src: "//cdn.alsgp0.fds.api.mi-img.com/xiaomi-b2c-i18n-upload/i18n/images/demo/block-thumbnail/block-thumbnail-recommended.png",
                    alt: "preview of layer to be exported"
                })))
            }

            function _o(e) {
                var t, n = e.classModify;
                return a.createElement("div", {
                    className: r()((t = {
                        "event-page-module": !0
                    }, t["event-page-module--".concat(n)] = !!n, t))
                }, a.createElement("div", {
                    style: {
                        padding: "10px 0"
                    }
                }, a.createElement("img", {
                    className: "preview-image",
                    src: "//cdn.alsgp0.fds.api.mi-img.com/xiaomi-b2c-i18n-upload/i18n/images/demo/block-thumbnail/block-thumbnail-event-page-module.png",
                    alt: "preview of layer to be exported"
                })))
            }

            function bo(e) {
                var t, n = e.classModify;
                return a.createElement("div", {
                    className: r()((t = {
                        "daily-picks-app": !0
                    }, t["daily-picks-app--".concat(n)] = !!n, t))
                }, a.createElement("img", {
                    className: "preview-image",
                    src: "//cdn.alsgp0.fds.api.mi-img.com/xiaomi-b2c-i18n-upload/i18n/images/demo/block-thumbnail/block-thumbnail-dailypicks-app.png",
                    alt: "preview of layer to be exported"
                }))
            }

            function yo(e) {
                var t, n = e.classModify;
                return a.createElement("div", {
                    className: r()((t = {
                        "banner-h364": !0
                    }, t["banner-h364--".concat(n)] = !!n, t))
                }, a.createElement("img", {
                    className: "preview-image",
                    src: "//cdn.alsgp0.fds.api.mi-img.com/xiaomi-b2c-i18n-upload/i18n/images/demo/block-thumbnail/block-thumbnail-banner-h364.png",
                    alt: "preview of layer to be exported"
                }))
            }

            function Eo() {
                return a.createElement("div", {
                    className: r()({
                        "new-product-app": !0
                    })
                }, a.createElement("div", {
                    style: {
                        padding: "10px 0"
                    }
                }, a.createElement("img", {
                    className: "preview-image",
                    src: "//cdn.alsgp0.fds.api.mi-img.com/xiaomi-b2c-i18n-upload/i18n/images/demo/block-thumbnail/block-thumbnail-new-product-app.png",
                    alt: "preview of layer to be exported"
                })))
            }
            var ho = function(e, t) {
                var n = "function" == typeof Symbol && e[Symbol.iterator];
                if (!n) return e;
                var a, o, l = n.call(e),
                    r = [];
                try {
                    for (;
                        (void 0 === t || t-- > 0) && !(a = l.next()).done;) r.push(a.value)
                } catch (i) {
                    o = {
                        error: i
                    }
                } finally {
                    try {
                        a && !a.done && (n = l.return) && n.call(l)
                    } finally {
                        if (o) throw o.error
                    }
                }
                return r
            };

            function No(e) {
                var t = e.layoutIndex,
                    n = e.isVisible,
                    o = e.isPaused,
                    l = e.isInsideOPX,
                    c = e.videoInfo,
                    s = e.videoPoster,
                    u = e.toggleCurrentSlidePlay,
                    d = (0, C.a)(),
                    v = (0, a.useRef)(null),
                    f = (0, a.useRef)("mobile" === d ? "mobile" : "desktop"),
                    p = ho((0, a.useState)(!1), 2),
                    g = p[0],
                    _ = p[1],
                    b = ho((0, a.useState)(!1), 2),
                    y = b[0],
                    E = b[1],
                    h = (0, a.useContext)(m.__).getServiceSuccess;

                function N() {
                    var e, t;
                    null === (t = null === (e = null == v ? void 0 : v.current) || void 0 === e ? void 0 : e.play()) || void 0 === t || t.catch((function() {
                        return console.log("=== pause right after video started playing, abort")
                    }))
                }
                return (0, a.useEffect)((function() {
                    var e, t = "mobile" === d ? "mobile" : "desktop";
                    f.current !== t && v.current && (v.current.src = ("mobile" === d ? c.mUrl : c.url) || "", null === (e = v.current) || void 0 === e || e.load(), N(), f.current = t)
                }), [d]), (0, a.useEffect)((function() {
                    n && v.current && (v.current.currentTime = 0, _(!1))
                }), [n]), (0, a.useEffect)((function() {
                    n && v.current && (l || h) && (v.current.src = ("mobile" === d ? c.mUrl : c.url) || "", N())
                }), [n, v, h]), (0, a.useEffect)((function() {
                    n && v.current && (l || h) && (o ? v.current.pause() : g || N())
                }), [n, o, v, g, h]), a.createElement(a.Fragment, null, a.createElement(i.t, {
                    className: r()("slide__background", "slide__background--image", {
                        "slide__background--hide": y
                    }),
                    alt: s.alt,
                    srcSet: {
                        widescreen: s.src.widescreen,
                        mobile: s.src.mobile
                    },
                    lazyLoading: t > 2
                }), a.createElement("video", {
                    className: "slide__background slide__background--video",
                    muted: !0,
                    playsInline: !0,
                    ref: v,
                    onPlaying: function() {
                        var e;
                        E(!0), o ? null === (e = v.current) || void 0 === e || e.pause() : u(!0)
                    },
                    onEnded: function() {
                        _(!0)
                    }
                }))
            }
            var ko = n(32582),
                xo = "mi-footnote-label";

            function So(e) {
                var t, n = e.className,
                    o = void 0 === n ? "" : n,
                    l = e.index;
                return l <= 0 ? null : a.createElement("sup", {
                    className: r()(xo, (t = {}, t[o] = !!o, t))
                }, a.createElement(ko.fO, {
                    className: "".concat(xo, "__link"),
                    to: "#footnote-".concat(l),
                    onClick: function(e) {
                        return e.stopPropagation()
                    }
                }, l))
            }
            var wo = {
                title: function(e) {
                    var t = e.textItem;
                    return t.pcSvg && t.mSvg ? a.createElement(a.Fragment, null, a.createElement("img", {
                        className: "slide__svg slide__svg--desktop slide__title--svg",
                        src: t.pcSvg,
                        alt: t.text || ""
                    }), a.createElement("img", {
                        className: "slide__svg slide__svg--mobile slide__title--svg",
                        src: t.mSvg,
                        alt: t.text || ""
                    })) : t.text ? a.createElement("h3", {
                        className: "slide__title"
                    }, t.text) : null
                },
                "extra-svg": function(e) {
                    var t = e.textItem;
                    return t.pcSvg && t.mSvg ? a.createElement(a.Fragment, null, a.createElement("img", {
                        className: "slide__svg slide__svg--desktop",
                        src: t.pcSvg,
                        alt: t.text || ""
                    }), a.createElement("img", {
                        className: "slide__svg slide__svg--mobile",
                        src: t.mSvg,
                        alt: t.text || ""
                    })) : null
                },
                subtitle: function(e) {
                    var t = e.textItem;
                    return t.text ? a.createElement("h4", {
                        className: "slide__subtitle"
                    }, t.text, a.createElement(So, {
                        className: "slide__footnote-label",
                        index: t.footnote.index
                    })) : null
                },
                description: function(e) {
                    var t = e.textItem;
                    return t.text ? a.createElement("p", {
                        className: "slide__description"
                    }, t.text, a.createElement(So, {
                        className: "slide__footnote-label",
                        index: t.footnote.index
                    })) : null
                }
            };

            function Co(e) {
                var t = e.textItem,
                    n = wo[t.type];
                return a.createElement(n, {
                    textItem: t
                })
            }
            var To = n(40024),
                Oo = n(27484),
                Io = "banner-spu",
                Mo = "banner-custom",
                Uo = 1,
                Po = 2,
                Ao = ["title", "extra-svg", "subtitle", "description"],
                Lo = {
                    LEARN_MORE: 0,
                    BUY_NOW: 1
                };

            function Do(e) {
                return void 0 === e && (e = []), Array.from(e || []).filter((function(e) {
                    return Ao.includes(null == e ? void 0 : e.type)
                })).map((function(e) {
                    var t, n;
                    return {
                        type: String(e.type),
                        text: String(e.text || ""),
                        pcSvg: String(e.pcSvg || ""),
                        mSvg: String(e.mSvg || ""),
                        footnote: {
                            text: String((null === (t = e.footnote) || void 0 === t ? void 0 : t.text) || ""),
                            index: Number((null === (n = e.footnote) || void 0 === n ? void 0 : n.index) || 0)
                        }
                    }
                }))
            }
            var Fo = function(e, t) {
                var n = "function" == typeof Symbol && e[Symbol.iterator];
                if (!n) return e;
                var a, o, l = n.call(e),
                    r = [];
                try {
                    for (;
                        (void 0 === t || t-- > 0) && !(a = l.next()).done;) r.push(a.value)
                } catch (i) {
                    o = {
                        error: i
                    }
                } finally {
                    try {
                        a && !a.done && (n = l.return) && n.call(l)
                    } finally {
                        if (o) throw o.error
                    }
                }
                return r
            };
            X.Z.use([ne.Z, To.Z]);
            var jo = "carousel-banner",
                zo = 0,
                qo = 1,
                Bo = 2,
                Wo = 1,
                Ro = 2;

            function Jo(e) {
                var t, n = e.slides,
                    o = e.skeletonData,
                    l = void 0 !== o && o,
                    v = e.otModule,
                    f = e.layoutIndex,
                    p = e.otClick,
                    g = e.otExpose,
                    _ = (0, d.YB)(),
                    b = (0, d.oW)(),
                    y = (0, a.useRef)(),
                    E = (0, C.a)(),
                    h = (0, d.Sz)(),
                    N = (0, a.useRef)("mobile" === E ? "mobile" : "desktop"),
                    k = (0, a.useRef)(Array.from({
                        length: n.length
                    }, (function() {
                        return !1
                    }))),
                    x = (0, a.useRef)(null),
                    S = (0, a.useMemo)((function() {
                        return 1 === n.length
                    }), [n]),
                    T = Fo((0, a.useState)(0), 2),
                    O = T[0],
                    I = T[1],
                    M = Fo((0, a.useState)(!1), 2),
                    U = M[0],
                    P = M[1],
                    A = Fo((0, a.useState)(!1), 2),
                    L = A[0],
                    D = A[1],
                    F = Fo((0, a.useState)(!1), 2),
                    j = F[0],
                    z = F[1],
                    q = Fo((0, a.useState)((null === (t = null == n ? void 0 : n[0]) || void 0 === t ? void 0 : t.theme) || "light"), 2),
                    B = q[0],
                    R = q[1],
                    J = (0, a.useContext)(m.__),
                    G = J.getServiceSuccess,
                    Y = J.ajaxStatus;

                function V(e) {
                    return e ? l ? P(e) : void(G && P(e)) : P(e)
                }

                function Z(e, t, n, a) {
                    var o, l, r, i, c;
                    e.stopPropagation();
                    var s = (null === (o = null == t ? void 0 : t.buttons) || void 0 === o ? void 0 : o[Lo[a]]) || {};
                    p({
                        event: t.name === Mo ? "select_promotion" : "select_item",
                        tip: {
                            c: v,
                            d: n + 1
                        },
                        link: "".concat(s.gotoUrl),
                        elementName: "banner",
                        elementTitle: "".concat(t.style === Uo ? "image" : "video", "_").concat(t.title || (null === (r = null === (l = t.images) || void 0 === l ? void 0 : l[0]) || void 0 === r ? void 0 : r.alt), "_").concat("BUY_NOW" === a ? "buy-now" : "learn-more"),
                        itemName: null === (c = null === (i = null == t ? void 0 : t.goods) || void 0 === i ? void 0 : i[0]) || void 0 === c ? void 0 : c.name
                    }), window.location.assign(s.gotoUrl)
                }
                var H = Fo((0, ot.$)((function(e) {
                        return e.pipe((0, lt.p)(300), (0, rt.b)((function(e) {
                            var t, n;
                            "prev" === e ? null === (t = y.current) || void 0 === t || t.slidePrev() : null === (n = y.current) || void 0 === n || n.slideNext()
                        })), (0, it.U)((function() {})))
                    }), void 0), 1),
                    Q = H[0];
                return (0, a.useEffect)((function() {
                    var e;
                    Number((null === (e = null == n ? void 0 : n[0]) || void 0 === e ? void 0 : e.style) || Uo) === Uo && V(!0)
                }), [G]), (0, a.useEffect)((function() {
                    var e, t = "mobile" === E ? "mobile" : "desktop";
                    N.current !== t && (null === (e = null == y ? void 0 : y.current) || void 0 === e || e.slideNext(), N.current = t)
                }), [E]), (0, a.useEffect)((function() {
                    var e;
                    return !l && G && (e = (0, ge.otExposeWith)({
                            targetNodeWrapper: x.current || void 0,
                            targetNodeSelector: "[data-ot-expose-custom]",
                            targetNodeDataAttr: "data-ot-expose-custom"
                        }, (function(e) {
                            var t;
                            return "function" == typeof g ? g(e || {}, String((null === (t = null == e ? void 0 : e.tip) || void 0 === t ? void 0 : t.c) || "")) : e
                        }), {
                            beforeReport: function(e) {
                                var t, n = Number((null === (t = null == e ? void 0 : e.tip) || void 0 === t ? void 0 : t.d) || 0) - 1;
                                return !k.current[n]
                            },
                            afterReport: function(e) {
                                var t, n = Number((null === (t = null == e ? void 0 : e.tip) || void 0 === t ? void 0 : t.d) || 0) - 1;
                                k.current[n] = !0
                            }
                        })),
                        function() {
                            e && e.disconnect()
                        }
                }), [l, G]), a.createElement("div", {
                    className: r()(jo, "".concat(jo, "--").concat(B)),
                    ref: x
                }, a.createElement("div", {
                    className: "".concat(jo, "__swiper"),
                    onMouseEnter: function() {
                        D(!0), !S && V(!1)
                    },
                    onMouseLeave: function() {
                        D(!1), !j && V(!0)
                    }
                }, a.createElement(oe.t, {
                    onSwiper: function(e) {
                        y.current = e
                    },
                    loop: n.length > 1,
                    spaceBetween: 0,
                    slidesPerView: "auto",
                    observer: !0,
                    observeParents: !0,
                    watchSlidesVisibility: !0,
                    simulateTouch: n.length > 1,
                    keyboard: !0,
                    onSlideChange: function(e) {
                        var t = e.realIndex,
                            a = n[t];
                        I(t), R(a.theme || "light"), a.style !== Uo || L || j || V(!0)
                    }
                }, n.map((function(e, t) {
                    var n, o = function(e) {
                            var t, n, a, o, l;
                            return void 0 === e && (e = {}), {
                                sortContent: Do((null == e ? void 0 : e.sortContent) || []),
                                position: {
                                    horizontal: Number((null === (t = e.position) || void 0 === t ? void 0 : t.contentPosition) || 0) % 3,
                                    vertical: Math.floor(Number((null === (n = e.position) || void 0 === n ? void 0 : n.contentPosition) || 0) / 3),
                                    mobileVertical: Number((null === (a = e.position) || void 0 === a ? void 0 : a.mobileContentPosition) || 0),
                                    textAlign: Number((null === (o = e.position) || void 0 === o ? void 0 : o.textAlign) || 0)
                                },
                                countdown: {
                                    start: 0,
                                    end: null === (l = e.countdown) || void 0 === l ? void 0 : l.end
                                }
                            }
                        }(e.extends || {}),
                        m = o.sortContent.some((function(e) {
                            return "title" === e.type ? !!e.text || e.pcSvg && e.mSvg : "extra-svg" === e.type ? e.pcSvg && e.mSvg : !!e.text
                        })),
                        d = (null === (n = o.countdown) || void 0 === n ? void 0 : n.end) - Oo(Date.now()).unix(),
                        p = e.theme,
                        g = e.name === Io && b.isToC;
                    return a.createElement(le.o, {
                        key: t
                    }, (function(n) {
                        var y, E, N, k, x, C, T, O, I, M, U, P, A, D, F, z, q = n.isVisible;
                        return a.createElement("div", {
                            className: r()("".concat(jo, "__slide"), "".concat(jo, "__slide--").concat(p || "light")),
                            role: "button",
                            tabIndex: m ? -1 : 0,
                            "data-ot-expose-custom": JSON.stringify({
                                event: e.name === Mo ? "view_promotion" : "view_item_list",
                                tip: {
                                    c: v,
                                    d: t + 1
                                },
                                elementName: "banner",
                                elementTitle: "".concat(e.style === Uo ? "image" : "video", "_").concat(e.title || (null === (E = null === (y = e.images) || void 0 === y ? void 0 : y[0]) || void 0 === E ? void 0 : E.alt)),
                                itemName: null === (k = null === (N = e.goods) || void 0 === N ? void 0 : N[0]) || void 0 === k ? void 0 : k.name
                            }),
                            onClick: function(n) {
                                return Z(n, e, t, "LEARN_MORE")
                            }
                        }, e.style === Po ? a.createElement(No, {
                            layoutIndex: f,
                            isVisible: q,
                            isPaused: !S && (L || j),
                            isInsideOPX: l,
                            videoInfo: (null === (x = null == e ? void 0 : e.videos) || void 0 === x ? void 0 : x[0]) || {
                                url: "",
                                mUrl: ""
                            },
                            videoPoster: e.images[0],
                            toggleCurrentSlidePlay: V
                        }) : a.createElement(i.t, {
                            className: "slide__background slide__background--image",
                            alt: (null === (C = e.images[0]) || void 0 === C ? void 0 : C.alt) || e.title || "",
                            srcSet: (null === (T = e.images[0]) || void 0 === T ? void 0 : T.src) || {},
                            lazyLoading: f > 2
                        }), (m || d > 0) && a.createElement("div", {
                            className: r()("slide__content", {
                                "slide__content--horizontal-center": o.position.horizontal === Wo,
                                "slide__content--end": o.position.horizontal === Ro,
                                "slide__content--vertical-center": o.position.vertical === qo,
                                "slide__content--bottom": o.position.vertical === Bo,
                                "slide__content--mobile-top": o.position.mobileVertical === zo,
                                "slide__content--mobile-vertical-center": o.position.mobileVertical === qo,
                                "slide__content--mobile-bottom": o.position.mobileVertical === Bo
                            })
                        }, a.createElement("div", {
                            className: r()("slide__info", {
                                "slide__info--center": o.position.textAlign === Wo
                            })
                        }, m && a.createElement("div", {
                            className: "slide__info-group slide__info-group--upper"
                        }, o.sortContent.map((function(e, t) {
                            return a.createElement(Co, {
                                key: "".concat(e.type, "-").concat(t),
                                textItem: e
                            })
                        }))), a.createElement("div", {
                            className: "slide__info-group slide__info-group--lower"
                        }, m && a.createElement(a.Fragment, null, e.name === Io && b.isToC && a.createElement(s.n, {
                            className: "slide__price",
                            salePrice: String(null === (O = e.goods[0]) || void 0 === O ? void 0 : O.salePrice),
                            delPrice: String(null === (I = e.goods[0]) || void 0 === I ? void 0 : I.originPrice),
                            isShowFrom: !(null === (M = e.goods[0]) || void 0 === M ? void 0 : M.salePriceIsEQ),
                            isShowBlank: h || !l && "success" !== Y
                        }), a.createElement(c.Y, {
                            className: "slide__energy",
                            theme: p,
                            energyInfo: null === (P = null === (U = null == e ? void 0 : e.goods) || void 0 === U ? void 0 : U[0]) || void 0 === P ? void 0 : P.energyInfo
                        }), a.createElement("div", {
                            className: "slide__action"
                        }, g && a.createElement(u.z, {
                            className: "slide__action-button",
                            btnType: "primary",
                            btnTheme: p,
                            href: null === (D = null === (A = e.buttons) || void 0 === A ? void 0 : A[Lo.BUY_NOW]) || void 0 === D ? void 0 : D.gotoUrl,
                            onClick: function(n) {
                                return Z(n, e, t, "BUY_NOW")
                            }
                        }, _.get("eeceac1af4e7620894d6d2083921bb73")), a.createElement(u.z, {
                            className: "slide__action-button",
                            btnType: g ? "link-default" : "primary",
                            btnTheme: p,
                            href: null === (z = null === (F = e.buttons) || void 0 === F ? void 0 : F[Lo.LEARN_MORE]) || void 0 === z ? void 0 : z.gotoUrl,
                            onClick: function(n) {
                                return Z(n, e, t, "LEARN_MORE")
                            }
                        }, a.createElement("span", {
                            className: "mi-btn__text"
                        }, _.get("f5395c9793af8a11b406ca7c1ac70da9")), g && a.createElement(w.q, {
                            symbol: "arrow-right-outlined",
                            className: "slide__action-icon"
                        })))), d > 0 && a.createElement(W.i, {
                            time: d,
                            dataType: "timeWithDaysIcon",
                            textColor: p
                        })))))
                    }))
                })))), !S && a.createElement(a.Fragment, null, a.createElement("div", {
                    className: "".concat(jo, "__swiper-navigator ").concat(jo, "__swiper-navigator--prev")
                }, a.createElement("button", {
                    className: "controller__button navigator__button navigator__button--prev with-transition",
                    onClick: function() {
                        return Q("prev")
                    }
                }, a.createElement(w.q, {
                    symbol: "fill-arrow-left",
                    className: "navigator__icon with-transition mirror"
                }))), a.createElement("div", {
                    className: "".concat(jo, "__swiper-navigator ").concat(jo, "__swiper-navigator--next")
                }, a.createElement("button", {
                    className: "controller__button navigator__button navigator__button--next with-transition",
                    onClick: function() {
                        return Q("next")
                    }
                }, a.createElement(w.q, {
                    symbol: "fill-arrow-right",
                    className: "navigator__icon with-transition mirror"
                }))), a.createElement("div", {
                    className: "".concat(jo, "__swiper-controller-wrapper")
                }, a.createElement("div", {
                    className: "".concat(jo, "__swiper-controller site-container")
                }, n.map((function(e, t) {
                    return a.createElement("button", {
                        key: t,
                        className: r()("controller__button", "controller__bar", {
                            "controller__bar--current": O === t,
                            "controller__bar--playing": U
                        }, "with-transition"),
                        onClick: function() {
                            var e;
                            t !== O && (null === (e = null == y ? void 0 : y.current) || void 0 === e || e.slideToLoop(t))
                        }
                    }, a.createElement("span", {
                        className: "controller__indicator-container with-transition"
                    }, a.createElement("span", {
                        className: "controller__indicator",
                        onAnimationEnd: function() {
                            var e;
                            return null === (e = null == y ? void 0 : y.current) || void 0 === e ? void 0 : e.slideNext()
                        }
                    })))
                })), a.createElement("button", {
                    className: "controller__button controller__icon-container with-transition",
                    onClick: function() {
                        j || p({
                            tip: {
                                c: v
                            },
                            elementName: "banner",
                            elementTitle: "stop"
                        }), V(j), z(!j)
                    }
                }, a.createElement(w.q, {
                    symbol: U ? "pause" : "play-solid",
                    className: "controller__icon with-transition"
                }))))))
            }
            var Go = function(e, t) {
                    var n = "function" == typeof Symbol && e[Symbol.iterator];
                    if (!n) return e;
                    var a, o, l = n.call(e),
                        r = [];
                    try {
                        for (;
                            (void 0 === t || t-- > 0) && !(a = l.next()).done;) r.push(a.value)
                    } catch (i) {
                        o = {
                            error: i
                        }
                    } finally {
                        try {
                            a && !a.done && (n = l.return) && n.call(l)
                        } finally {
                            if (o) throw o.error
                        }
                    }
                    return r
                },
                Yo = (0, on.o)(Ho),
                Vo = (0, a.createContext)(Yo);

            function Zo(e) {
                var t = e.siteConfig,
                    n = e.isAutoFetch,
                    o = e.children,
                    l = Go((0, a.useState)(Yo), 2),
                    r = l[0],
                    i = l[1];

                function c(e) {
                    var t = e.data,
                        n = e.errmsg,
                        a = e.errno;
                    return {
                        data: Ho(t || {}),
                        errMsg: String(n),
                        errNo: Number(a)
                    }
                }
                var s = {
                    url: "".concat(t.goSite, "/tradein/products"),
                    method: "GET",
                    withCredentials: !0,
                    retryOptions: {
                        maxRetryAttempts: 3,
                        scalingDuration: 3e3
                    }
                };
                return a.createElement(ln.h, {
                    context: Vo,
                    setState: i,
                    defaultValue: Yo,
                    adapterError: function(e) {
                        return c(e)
                    },
                    adapter: c,
                    value: r,
                    siteConfig: t,
                    isAutoFetch: !0 === n,
                    ajaxConfig: s
                }, o)
            }

            function Ho(e) {
                return void 0 === e && (e = {}), {
                    productList: Qo(e.list || [])
                }
            }

            function Qo(e) {
                return void 0 === e && (e = []), Array.from(e || []).map((function(e) {
                    return {
                        productName: String(e.product_name || ""),
                        productId: Number(e.product_id || 0),
                        productImage: String(e.product_image || ""),
                        productStationUrl: e.product_station_url || "",
                        originPrice: e.origin_price || "",
                        salePrice: e.sales_price || "",
                        bonus: e.bonus || ""
                    }
                }))
            }
            var $o = function() {
                    return $o = Object.assign || function(e) {
                        for (var t, n = 1, a = arguments.length; n < a; n++)
                            for (var o in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
                        return e
                    }, $o.apply(this, arguments)
                },
                Ko = function(e, t) {
                    var n = "function" == typeof Symbol && e[Symbol.iterator];
                    if (!n) return e;
                    var a, o, l = n.call(e),
                        r = [];
                    try {
                        for (;
                            (void 0 === t || t-- > 0) && !(a = l.next()).done;) r.push(a.value)
                    } catch (i) {
                        o = {
                            error: i
                        }
                    } finally {
                        try {
                            a && !a.done && (n = l.return) && n.call(l)
                        } finally {
                            if (o) throw o.error
                        }
                    }
                    return r
                };

            function Xo(e) {
                var t, n = e.otModule,
                    o = e.classModify,
                    l = e.otClick,
                    i = (0, d.YB)(),
                    c = (0, C.a)(),
                    m = (0, d.oW)(),
                    v = Ko((0, a.useState)(!0), 2),
                    f = v[0],
                    p = v[1],
                    g = Ko((0, a.useState)(Array(5).fill(0)), 2),
                    _ = g[0],
                    b = g[1],
                    y = (0, a.useContext)(Vo);

                function E(e, t) {
                    "more" === t && h(e), window.location.href = e
                }

                function h(e) {
                    l({
                        tip: {
                            a: 16,
                            b: 107,
                            c: "more_product",
                            d: 0,
                            e: 29507
                        },
                        elementTitle: "learn_more",
                        elementName: "more_product",
                        link: e
                    })
                }
                return (0, a.useEffect)((function() {
                    y.getService({}, (function(e) {
                        e.errNo || (p(!1), b(e.data.productList))
                    }))
                }), []), _.length ? a.createElement("div", {
                    className: r()((t = {
                        "trade-in-sku": !0
                    }, t["trade-in-sku--".concat(o)] = !!o, t)),
                    "data-ot-expose": JSON.stringify({
                        tip: {
                            c: n
                        }
                    })
                }, a.createElement("h3", {
                    className: "trade-in-sku__title"
                }, i.get("150bd42085312ab95d106e47928fc851")), a.createElement("div", {
                    className: r()("trade-in-sku__list", {
                        "trade-in-sku__list--loading": f
                    })
                }, _.map((function(e, t) {
                    return a.createElement("div", {
                        className: "trade-in-sku__item trade-in-sku__product-wrapper",
                        key: t,
                        onClick: function() {
                            return "mobile" === c && E(e.productStationUrl)
                        },
                        role: "button",
                        tabIndex: t
                    }, a.createElement("div", {
                        className: "trade-in-sku__product"
                    }, a.createElement("img", {
                        className: "trade-in-sku__product-img",
                        src: e.productImage + "?width=400&height=400",
                        alt: e.productName
                    }), a.createElement("div", {
                        className: "trade-in-sku__product-info"
                    }, a.createElement("span", {
                        className: "product-title"
                    }, e.productName), a.createElement(s.n, {
                        className: "product-price",
                        salePrice: e.salePrice,
                        delPrice: e.originPrice
                    }), f || !f && e.bonus && a.createElement("span", {
                        className: "trade-in-bonus"
                    }, i.get("cc06a80cce9770748c8645aaf346fcfa", {
                        price: e.bonus
                    })), "mobile" !== c && a.createElement(u.z, {
                        className: "product-link",
                        btnType: "primary",
                        href: e.productStationUrl
                    }, i.get("d59048f21fd887ad520398ce677be586")))))
                })), a.createElement("div", {
                    className: "trade-in-sku__item trade-in-sku__more",
                    onClick: function() {
                        return E("".concat(m.wwwSite.pc, "/phone"), "more")
                    },
                    role: "button",
                    tabIndex: -1
                }, a.createElement("span", {
                    className: "trade-in-sku__more-title"
                }, i.get("9ac1415677cf30073bb6affad46fc279")), a.createElement(w.q, {
                    symbol: "arrow-right-outlined",
                    className: "trade-in-sku__more-icon",
                    onClick: function() {
                        return h("".concat(m.wwwSite.pc, "/phone"))
                    }
                })))) : a.createElement(a.Fragment, null)
            }

            function el(e) {
                var t = (0, d.oW)();
                return a.createElement(Zo, {
                    siteConfig: t
                }, a.createElement(Xo, $o({}, e)))
            }

            function tl() {
                return a.createElement("div", {
                    className: "exclusive-offers-empty"
                }, a.createElement("div", {
                    className: "exclusive-offers-empty__img"
                }), a.createElement("div", {
                    className: "exclusive-offers-empty__title"
                }), a.createElement("div", {
                    className: "exclusive-offers-empty__subtitle"
                }))
            }
            var nl = n(55342);

            function al(e) {
                var t = e.title,
                    n = e.isGoods,
                    o = void 0 !== n && n,
                    r = e.subtitle,
                    i = e.tag,
                    c = (0, d.YB)(),
                    s = "exclusive-offers-footer-bar";
                return a.createElement("div", {
                    className: l("".concat(s))
                }, a.createElement("div", {
                    className: l("".concat(s, "__title"))
                }, a.createElement(nl.b, {
                    inputStr: t.replace(/({{|}})/g, "#@icon@#")
                })), a.createElement("div", {
                    className: l("".concat(s, "__content"))
                }, a.createElement("div", {
                    className: l("".concat(s, "__content-desc"))
                }, o ? a.createElement("div", null, a.createElement("div", {
                    className: l("".concat(s, "__content-desc-title"))
                }, r), a.createElement("div", {
                    className: l("".concat(s, "__content-desc-tag"))
                }, i)) : r), a.createElement("div", {
                    className: l("".concat(s, "__content-button"))
                }, c.get("f5395c9793af8a11b406ca7c1ac70da9", {
                    ns: "translation"
                }))))
            }

            function ol(e) {
                var t = e.isOpx,
                    n = e.opxData,
                    o = e.otModule,
                    r = e.otClick,
                    c = e.getDataIsSuccess,
                    s = e.index,
                    u = e.layoutIndex,
                    m = n.title,
                    v = void 0 === m ? "" : m,
                    f = n.subtitle,
                    p = n.buttons,
                    g = "activity-customize",
                    _ = (0, d.oW)();
                return a.createElement("div", {
                    className: l("".concat(g))
                }, t || c ? a.createElement("div", {
                    role: "button",
                    tabIndex: 0,
                    onClick: function() {
                        var e, t = (null === (e = null == p ? void 0 : p[0]) || void 0 === e ? void 0 : e.gotoUrl) || "".concat(_.wwwSite.pc, "/store");
                        r({
                            event: "select_promotion",
                            tip: {
                                c: "".concat(o, "|").concat(s + 1)
                            },
                            elementName: "exclusive",
                            elementTitle: v,
                            link: t
                        }), window.open(t)
                    },
                    "data-ot-expose": JSON.stringify({
                        event: "view_promotion",
                        tip: {
                            c: "".concat(o, "|").concat(s + 1)
                        },
                        elementName: "exclusive",
                        elementTitle: v
                    })
                }, a.createElement("div", {
                    className: l("".concat(g, "__content"))
                }, a.createElement(i.t, {
                    className: l("".concat(g, "__content-background")),
                    alt: v,
                    srcSet: {
                        desktop: "",
                        laptop: "",
                        mobile: n.images[0].src.mobile || "",
                        tablet: "",
                        widescreen: n.images[0].src.widescreen || ""
                    },
                    lazyLoading: u > 2
                })), a.createElement(al, {
                    title: v,
                    subtitle: f
                })) : a.createElement(tl, null))
            }
            var ll = function(e, t) {
                var n = "function" == typeof Symbol && e[Symbol.iterator];
                if (!n) return e;
                var a, o, l = n.call(e),
                    r = [];
                try {
                    for (;
                        (void 0 === t || t-- > 0) && !(a = l.next()).done;) r.push(a.value)
                } catch (i) {
                    o = {
                        error: i
                    }
                } finally {
                    try {
                        a && !a.done && (n = l.return) && n.call(l)
                    } finally {
                        if (o) throw o.error
                    }
                }
                return r
            };

            function rl(e, t) {
                var n = e.includes(".appmifile.com/");
                if (t && n) return e.replace(/(.*)\.(\w+)/, "$1!".concat(t, ".$2"));
                if (t) {
                    var a = ll(t.split("x"), 2),
                        o = a[0],
                        l = a[1];
                    return "".concat(e, "?thumb=1&w=").concat(o, "&h=").concat(l)
                }
                return e
            }
            var il = function(e, t) {
                var n = "function" == typeof Symbol && e[Symbol.iterator];
                if (!n) return e;
                var a, o, l = n.call(e),
                    r = [];
                try {
                    for (;
                        (void 0 === t || t-- > 0) && !(a = l.next()).done;) r.push(a.value)
                } catch (i) {
                    o = {
                        error: i
                    }
                } finally {
                    try {
                        a && !a.done && (n = l.return) && n.call(l)
                    } finally {
                        if (o) throw o.error
                    }
                }
                return r
            };

            function cl(e) {
                var t = (0, d.YB)(),
                    n = (0, d.oW)(),
                    o = (0, d.Sz)(),
                    r = e.isOpx,
                    c = e.opxData,
                    s = e.otModule,
                    u = e.otClick,
                    m = e.getDataIsSuccess,
                    v = e.index,
                    f = e.layoutIndex,
                    p = "activity-new-product",
                    g = il(a.useState({
                        image: "",
                        name: "",
                        tag: "",
                        url: ""
                    }), 2),
                    _ = g[0],
                    b = g[1];
                (0, a.useEffect)((function() {
                    var e, t;
                    if (null === (e = null == c ? void 0 : c.goods) || void 0 === e ? void 0 : e[0]) {
                        var n = c.goods[0];
                        b({
                            image: n.imgUrl,
                            name: n.name,
                            tag: (null == c ? void 0 : c.tips) || "",
                            url: (null === (t = c.buttons) || void 0 === t ? void 0 : t[0].gotoUrl) || ""
                        })
                    }
                }), [e]);
                var y = 1 === c.images.length;
                return a.createElement("div", {
                    className: l("".concat(p))
                }, m || r ? a.createElement("div", {
                    role: "button",
                    tabIndex: 0,
                    onClick: function() {
                        var e = _.url || "".concat(n.wwwSite.pc, "/store/new-products");
                        u({
                            event: "select_promotion",
                            tip: {
                                c: "".concat(s, "|").concat(v + 1)
                            },
                            elementName: "exclusive",
                            elementTitle: "new_product",
                            link: e
                        }), window.open(e)
                    },
                    "data-ot-expose": JSON.stringify({
                        event: "view_promotion",
                        tip: {
                            c: "".concat(s, "|").concat(v + 1)
                        },
                        elementName: "exclusive",
                        elementTitle: "new_product"
                    })
                }, a.createElement("div", {
                    className: l("".concat(p, "__content"))
                }, a.createElement(i.t, {
                    className: l("".concat(p, "__content-background")),
                    alt: c.title || "",
                    srcSet: {
                        desktop: "",
                        laptop: "",
                        mobile: o ? "" : rl(c.images[y ? 0 : 1].src.mobile, "1080x1080") || "",
                        tablet: "",
                        widescreen: o ? "" : rl(null == c ? void 0 : c.images[y ? 0 : 1].src.widescreen, "700x700") || "//i02.appmifile.com/769_operatorx_operatorx_xm/27/07/2023/cc6c8d4948c0fd01fb3123485da3f507.png"
                    },
                    lazyLoading: f > 2
                }), !r && !!_.image && y && a.createElement(i.t, {
                    className: l("".concat(p, "__content-image")),
                    alt: _.name,
                    srcSet: {
                        desktop: _.image || "",
                        laptop: _.image || "",
                        mobile: _.image || "",
                        tablet: _.image || "",
                        widescreen: _.image || ""
                    },
                    lazyLoading: f > 2
                })), a.createElement(al, {
                    title: c.title || "",
                    isGoods: !0,
                    subtitle: _.name || t.get("046fde5fa91283dcd572a030b35619c0"),
                    tag: _.tag || ""
                })) : a.createElement(tl, null))
            }
            var sl = n(7124),
                ul = n(49133),
                ml = n(70178),
                dl = n(29387),
                vl = function(e, t) {
                    var n = "function" == typeof Symbol && e[Symbol.iterator];
                    if (!n) return e;
                    var a, o, l = n.call(e),
                        r = [];
                    try {
                        for (;
                            (void 0 === t || t-- > 0) && !(a = l.next()).done;) r.push(a.value)
                    } catch (i) {
                        o = {
                            error: i
                        }
                    } finally {
                        try {
                            a && !a.done && (n = l.return) && n.call(l)
                        } finally {
                            if (o) throw o.error
                        }
                    }
                    return r
                };

            function fl(e) {
                var t, n;
                Oo.extend(sl), Oo.extend(ul), Oo.extend(ml), Oo.extend(dl);
                var o = e.isOpx,
                    r = e.opxData,
                    c = e.otModule,
                    s = e.otClick,
                    u = e.getDataIsSuccess,
                    v = e.index,
                    f = e.layoutIndex,
                    p = (0, a.useContext)(m.__),
                    g = vl((0, a.useState)(-1), 2),
                    _ = g[0],
                    b = g[1],
                    y = vl((0, a.useState)(0), 2),
                    E = y[0],
                    h = y[1],
                    N = (0, J.lS)((null === (n = null === (t = e.opxData) || void 0 === t ? void 0 : t.extends) || void 0 === n ? void 0 : n.dailyPick) || [], Math.floor(Date.now() / 1e3)),
                    k = vl((0, a.useState)({
                        endTime: 0,
                        startTime: 0,
                        serverTime: 0,
                        title: "",
                        subtitle: "",
                        buyUrl: "",
                        imgUrl: "",
                        promoImgUrl: "",
                        tagList: []
                    }), 2),
                    x = k[0],
                    S = k[1],
                    w = vl((0, a.useState)(!1), 2),
                    C = w[0],
                    T = w[1],
                    O = vl((0, a.useState)(!1), 2),
                    I = O[0],
                    M = O[1],
                    U = (0, d.Sz)(),
                    P = x.startTime,
                    A = x.serverTime,
                    L = x.endTime,
                    D = x.title,
                    F = (0, a.useMemo)((function() {
                        return A - E
                    }), [E, A]),
                    j = Math.floor(Date.now() / 1e3) + F + 5,
                    z = vl((0, a.useState)(-1), 2),
                    q = z[0],
                    B = z[1];
                (0, a.useEffect)((function() {
                    B(P > j ? 0 : j > P && j < L ? 1 : -1)
                }), [x]);
                var R = (0, d.YB)(),
                    G = (0, d.oW)(),
                    Y = "activity-daily-picks",
                    V = function(e) {
                        return Math.floor((e - Math.floor(Date.now() / 1e3)) / 86400)
                    },
                    Z = function(e) {
                        var t = [];
                        return e.forEach((function(e) {
                            t.push(e.name)
                        })), t
                    };
                (0, a.useEffect)((function() {
                    !o && p.getServiceSuccess && h(Math.floor(Date.now() / 1e3))
                }), [p.getServiceSuccess, o]), (0, a.useEffect)((function() {
                    N.length && b(0)
                }), [e]), (0, a.useEffect)((function() {
                    var t;
                    0 !== q ? _ > -1 && (_ < N.length ? (t = N[_], M(!0), S({
                        endTime: t.endTime,
                        startTime: t.startTime,
                        serverTime: t.serverTime,
                        title: t.children[0].title,
                        subtitle: t.children[0].subtitle,
                        buyUrl: t.children[0].buyUrl,
                        imgUrl: t.children[0].imgUrl,
                        promoImgUrl: t.children[0].promoImgUrl,
                        tagList: Z(t.children[0].tagList)
                    })) : (T(!0), e.slideItemMoveLast(v))) : B(1)
                }), [_]);
                var H, Q = [R.get("0948e04166f2a0236ec1747ef63e5bf6", {
                        countDown: ""
                    }), R.get("e1d607780c865de4b895298b4acc9b05", {
                        countDown: ""
                    })],
                    $ = 1 === r.images.length;
                return a.createElement("div", {
                    className: l("".concat(Y))
                }, u || o ? a.createElement("div", {
                    role: "button",
                    tabIndex: 0,
                    onClick: function() {
                        var e, t, n = (null === (t = null === (e = null == r ? void 0 : r.buttons) || void 0 === e ? void 0 : e[0]) || void 0 === t ? void 0 : t.gotoUrl) || x.buyUrl || "".concat(G.wwwSite.pc, "/store");
                        s({
                            event: "select_promotion",
                            tip: {
                                c: "".concat(c, "|").concat(v + 1)
                            },
                            elementName: "exclusive",
                            elementTitle: "dailypicks",
                            link: n
                        }), window.open(n)
                    },
                    "data-ot-expose": JSON.stringify({
                        event: "view_promotion",
                        tip: {
                            c: "".concat(c, "|").concat(v + 1)
                        },
                        elementName: "exclusive",
                        elementTitle: "dailypicks"
                    })
                }, a.createElement("div", {
                    className: l("".concat(Y, "__content"))
                }, a.createElement(i.t, {
                    className: l("".concat(Y, "__content-background")),
                    alt: D,
                    srcSet: {
                        desktop: "",
                        laptop: "",
                        mobile: U ? "" : rl(r.images[$ ? 0 : 1].src.mobile, "1080x1080") || "",
                        tablet: "",
                        widescreen: U ? "" : rl(null == r ? void 0 : r.images[$ ? 0 : 1].src.widescreen, "700x700") || "//i02.appmifile.com/292_operatorx_operatorx_xm/27/07/2023/11c910e5338a5d13c588bf24e23dd770.png"
                    },
                    lazyLoading: f > 2
                }), !o && !C && _ > -1 && a.createElement("div", {
                    className: l("".concat(Y, "__content-info"))
                }, I && a.createElement("div", {
                    className: l("".concat(Y, "__content-info-time"))
                }, a.createElement("div", {
                    className: "mi-count-down__tip"
                }, Q[q]), V(q ? L : P) ? a.createElement("div", {
                    className: "mi-count-down__day-content"
                }, a.createElement(nl.b, {
                    type: "number",
                    inputStr: R.get("d7dd33406fe94fc18c102ac0888f9dd7", {
                        n: V(q ? L : P)
                    })
                })) : a.createElement(W.i, {
                    time: {
                        requestTime: E,
                        serverTime: A,
                        finishTime: q ? L : P
                    },
                    displayType: "icon",
                    onFinish: function() {
                        M(!1)
                    }
                })), !!x.imgUrl && $ && a.createElement(i.t, {
                    className: l("".concat(Y, "__content-info-image")),
                    alt: D,
                    srcSet: {
                        desktop: x.imgUrl || "",
                        laptop: x.imgUrl || "",
                        mobile: x.imgUrl || "",
                        tablet: x.imgUrl || "",
                        widescreen: x.imgUrl || ""
                    },
                    lazyLoading: f > 2
                }))), a.createElement(al, {
                    title: r.title || "",
                    isGoods: !0,
                    subtitle: x.title || R.get("0cedf2a5c333f7065c84a2c2813b1c38"),
                    tag: (H = "", x.tagList.forEach((function(e, t) {
                        t && (H += " | "), H += e
                    })), H || "")
                })) : a.createElement(tl, null))
            }
            var pl = function() {
                    return pl = Object.assign || function(e) {
                        for (var t, n = 1, a = arguments.length; n < a; n++)
                            for (var o in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
                        return e
                    }, pl.apply(this, arguments)
                },
                gl = function(e, t) {
                    var n = "function" == typeof Symbol && e[Symbol.iterator];
                    if (!n) return e;
                    var a, o, l = n.call(e),
                        r = [];
                    try {
                        for (;
                            (void 0 === t || t-- > 0) && !(a = l.next()).done;) r.push(a.value)
                    } catch (i) {
                        o = {
                            error: i
                        }
                    } finally {
                        try {
                            a && !a.done && (n = l.return) && n.call(l)
                        } finally {
                            if (o) throw o.error
                        }
                    }
                    return r
                },
                _l = function(e, t, n) {
                    if (n || 2 === arguments.length)
                        for (var a, o = 0, l = t.length; o < l; o++) !a && o in t || (a || (a = Array.prototype.slice.call(t, 0, o)), a[o] = t[o]);
                    return e.concat(a || Array.prototype.slice.call(t))
                };

            function bl(e) {
                var t, n = e.otModule,
                    o = e.classModify,
                    r = e.skeletonData,
                    i = void 0 !== r && r,
                    c = e.layoutIndex,
                    s = e.otClick,
                    u = gl((0, a.useState)(e.slides), 2),
                    v = u[0],
                    f = u[1],
                    p = (0, a.useContext)(m.__),
                    g = "mobile" === (0, C.a)(),
                    _ = (0, d.YB)(),
                    b = "exclusive-offers",
                    y = (0, a.useRef)(null),
                    E = (0, a.useRef)();

                function h(e) {
                    var t = pl({}, v[e]),
                        n = _l([], gl(v), !1);
                    n.splice(e, 1), n.push(t), f(n)
                }

                function N() {
                    return a.createElement(a.Fragment, null, v && v.map((function(e, t) {
                        var o = "success" === p.ajaxStatus || !1;
                        return a.createElement(le.o, {
                            key: "".concat(e.title, "-").concat(t),
                            className: l("".concat(b, "__item"))
                        }, "customize" === e.type && a.createElement(ol, {
                            opxData: e,
                            isOpx: !!i,
                            otClick: s,
                            otModule: n,
                            getDataIsSuccess: o,
                            index: t,
                            layoutIndex: c
                        }), "dailypicker" === e.type && a.createElement(fl, {
                            slideItemMoveLast: h,
                            otClick: s,
                            otModule: n,
                            opxData: e,
                            isOpx: !!i,
                            getDataIsSuccess: o,
                            index: t,
                            layoutIndex: c
                        }), "newproduct" === e.type && a.createElement(cl, {
                            otClick: s,
                            otModule: n,
                            opxData: e,
                            isOpx: !!i,
                            getDataIsSuccess: o,
                            index: t,
                            layoutIndex: c
                        }))
                    })))
                }
                return (0, a.useEffect)((function() {
                    f(e.slides)
                }), [e]), a.createElement("div", {
                    className: l((t = {}, t["".concat(b)] = !0, t["".concat(b, "--").concat(o)] = !!o, t)),
                    "data-ot-expose": JSON.stringify({
                        tip: {
                            c: n
                        }
                    }),
                    ref: y
                }, a.createElement("div", {
                    className: l("".concat(b, "__header"))
                }, a.createElement("div", {
                    className: l("".concat(b, "__header-text"))
                }, _.get("cb4390ef137ee52abadcccb72adc6c97")), !g && v && v.length > 3 && a.createElement("div", {
                    className: l("".concat(b, "__header-arrow"))
                }, ["left", "right"].map((function(e) {
                    var t;
                    return a.createElement(w.q, {
                        key: e,
                        className: l((t = {}, t["".concat(b, "__header-arrow-").concat(e)] = !0, t)),
                        symbol: "fill-arrow-".concat(e),
                        onClick: function() {
                            s({
                                event: "click",
                                tip: {
                                    c: n,
                                    e: 16719
                                },
                                elementName: "exclusive",
                                elementTitle: "more"
                            })
                        }
                    })
                })))), g ? a.createElement("div", {
                    className: l("".concat(b, "__list"))
                }, N()) : a.createElement(oe.t, {
                    allowTouchMove: !1,
                    onSwiper: function(e) {
                        E.current = e
                    },
                    slidesPerView: "auto",
                    slidesPerGroup: 3,
                    navigation: {
                        prevEl: ".".concat(b, "__header-arrow-left"),
                        nextEl: ".".concat(b, "__header-arrow-right")
                    },
                    className: l("".concat(b, "__list"))
                }, N()))
            }
            var yl = function(e, t) {
                var n = "function" == typeof Symbol && e[Symbol.iterator];
                if (!n) return e;
                var a, o, l = n.call(e),
                    r = [];
                try {
                    for (;
                        (void 0 === t || t-- > 0) && !(a = l.next()).done;) r.push(a.value)
                } catch (i) {
                    o = {
                        error: i
                    }
                } finally {
                    try {
                        a && !a.done && (n = l.return) && n.call(l)
                    } finally {
                        if (o) throw o.error
                    }
                }
                return r
            };

            function El(e) {
                var t, n = e.otModule,
                    o = e.otClick,
                    r = e.classModify,
                    i = e.skeletonData,
                    c = e.title,
                    s = e.buttons,
                    u = yl((0, a.useState)(!1), 2),
                    m = u[0],
                    f = u[1],
                    p = (0, d.oW)(),
                    g = (0, v.VL)(va.LH.get("topNotified")) ? JSON.parse(va.LH.get("topNotified") || "") : {
                        indexRibbonAds: !0,
                        topNotified: !0,
                        businessProcess: !0
                    };
                void 0 === g.indexRibbonAds && (g.indexRibbonAds = !0);
                var _ = yl((0, a.useState)(g.indexRibbonAds), 2),
                    b = _[0],
                    y = _[1],
                    E = (0, d.Sz)();
                (0, a.useEffect)((function() {
                    i || setTimeout((function() {
                        f(!0)
                    }), 3e3)
                }), []);
                var h = function() {
                    var e, t;
                    return (null === (e = null == s ? void 0 : s[0]) || void 0 === e ? void 0 : e.gotoUrl) && (null === (t = null == s ? void 0 : s[0]) || void 0 === t ? void 0 : t.text) ? a.createElement(Rt.I, {
                        href: s[0].gotoUrl,
                        className: "ribbon-ads__link",
                        target: "_blank",
                        onClick: function(e) {
                            return function(e) {
                                e.preventDefault(), o({
                                    tip: {
                                        c: n
                                    },
                                    event: "select_promotion",
                                    elementName: "sales-notice",
                                    isOpenGA: !0
                                }), window.open(s[0].gotoUrl)
                            }(e)
                        }
                    }, a.createElement("span", null, s[0].text)) : a.createElement(a.Fragment, null)
                };
                return a.createElement("div", null, (null == g ? void 0 : g.indexRibbonAds) && b ? a.createElement("div", {
                    className: l((t = {
                        "ribbon-ads": !0
                    }, t["RibbonAds--".concat(r)] = !!r, t["ribbon-ads__default"] = m, t)),
                    "data-ot-expose": JSON.stringify({
                        event: "view_promotion",
                        tip: {
                            c: n
                        },
                        elementName: "sales-notice"
                    }),
                    style: {
                        display: E ? "none" : ""
                    }
                }, a.createElement("div", {
                    className: "ribbon-ads__container"
                }, a.createElement("div", {
                    className: "ribbon-ads__content"
                }, a.createElement("div", {
                    className: "ribbon-ads__content-desc"
                }, c, a.createElement("span", {
                    className: "ribbon-ads__content-mobile-button"
                }, h())), a.createElement("div", {
                    className: "ribbon-ads__content-button"
                }, h())), a.createElement(w.q, {
                    onClick: function() {
                        g.indexRibbonAds = !1, va.LH.set("required", "topNotified", JSON.stringify(g), {
                            expires: 1,
                            path: "/" + p.local,
                            domain: p.stat.cookieDomain
                        }), y(!1)
                    },
                    className: "ribbon-ads__close",
                    symbol: "close"
                }))) : a.createElement(a.Fragment, null))
            }
            var hl = n(24224),
                Nl = function(e, t) {
                    var n = "function" == typeof Symbol && e[Symbol.iterator];
                    if (!n) return e;
                    var a, o, l = n.call(e),
                        r = [];
                    try {
                        for (;
                            (void 0 === t || t-- > 0) && !(a = l.next()).done;) r.push(a.value)
                    } catch (i) {
                        o = {
                            error: i
                        }
                    } finally {
                        try {
                            a && !a.done && (n = l.return) && n.call(l)
                        } finally {
                            if (o) throw o.error
                        }
                    }
                    return r
                },
                kl = function(e, t, n) {
                    if (n || 2 === arguments.length)
                        for (var a, o = 0, l = t.length; o < l; o++) !a && o in t || (a || (a = Array.prototype.slice.call(t, 0, o)), a[o] = t[o]);
                    return e.concat(a || Array.prototype.slice.call(t))
                };

            function xl(e, t) {
                return "1S-4S" === e && 0 === t ? "mainSPU" : "1S-4S" === e && t > 0 ? "otherSPU" : "1C-4S" === e && 0 === t ? "mainCustom" : "1C-4S" === e && t > 0 ? "otherSPU" : "1C-4C" === e && 0 === t ? "mainCustom" : "1C-4C" === e && t > 0 ? "otherCustom" : "1S-2S" === e && 0 === t ? "mainSPU" : "1S-2S" === e && t > 0 ? "otherSPU" : "1C-2S" === e && 0 === t ? "mainCustom" : "1C-2S" === e && t > 0 ? "otherSPU" : "1C-2C" === e && 0 === t ? "mainCustom" : "1C-2C" === e && t > 0 ? "otherCustom" : "2S-2S" === e ? "otherSPU" : "1S" === e ? "mainSPU" : "1C" === e ? "mainCustom" : "mainSPU"
            }

            function Sl(e) {
                return void 0 === e && (e = {}), {
                    pc: String(e.pc || ""),
                    m: String(e.m || "")
                }
            }

            function wl(e) {
                return void 0 === e && (e = []), Array.from(e || []).map((function(e) {
                    var t, n;
                    return void 0 === e && (e = {}), {
                        text: String((null == e ? void 0 : e.text) || ""),
                        pcSvg: String((null == e ? void 0 : e.pcSvg) || ""),
                        mSvg: String((null == e ? void 0 : e.mSvg) || ""),
                        footnote: {
                            text: String((null === (t = null == e ? void 0 : e.footnote) || void 0 === t ? void 0 : t.text) || ""),
                            index: Number((null === (n = null == e ? void 0 : e.footnote) || void 0 === n ? void 0 : n.index) || 0)
                        }
                    }
                }))
            }

            function Cl(e) {
                var t = e.reduce((function(e, t) {
                        return t.goods[0] && 0 !== t.goods[0].productId ? e[0].push(t) : e[1].push(t), e
                    }), [
                        [],
                        []
                    ]),
                    n = t[0],
                    a = t[1],
                    o = n.sort((function(e, t) {
                        return !e.goods[0].isOutOfStock && t.goods[0].isOutOfStock ? -1 : e.goods[0].isOutOfStock && !t.goods[0].isOutOfStock ? 1 : 0
                    }));
                return kl(kl([], Nl(o), !1), Nl(a), !1)
            }

            function Tl(e) {
                var t, n, o, l, f, p, g, _, b, y, E, h, N, k, x, S, w, T, O, I, M, U, P, A = e.itemProps,
                    L = e.itemType,
                    D = e.itemStyle,
                    F = e.layout,
                    j = e.tabName,
                    z = e.tabIndex,
                    q = e.itemIndex,
                    B = e.skeletonData,
                    W = e.otModule,
                    R = e.layoutIndex,
                    J = e.otClick,
                    G = e.otExpose,
                    Y = A.title,
                    V = A.goods,
                    Z = A.images,
                    H = A.buttons,
                    Q = (0, d.YB)(),
                    $ = (0, d.oW)(),
                    K = (0, d.Sz)(),
                    X = "mobile" === (0, C.a)(),
                    ee = (0, a.useContext)(m.__),
                    te = ee.getServiceSuccess || !!B;
                (0, a.useEffect)((function() {
                    if (ee.getServiceSuccess && !B) {
                        var e = (0, ge.otExposeWith)({
                            isInfinite: !1,
                            exposeThreshold: .3,
                            targetNodeWrapper: document.querySelector(".feature-tab--item"),
                            targetNodeSelector: "[data-ot-expose]"
                        }, (function(e, t) {
                            var n;
                            return "function" == typeof G && G(e || {}, String((null === (n = null == e ? void 0 : e.tip) || void 0 === n ? void 0 : n.c) || ""))
                        }));
                        return function() {
                            e && e.disconnect()
                        }
                    }
                    return function() {
                        return null
                    }
                }), [ee.getServiceSuccess]);
                var ne = "item-info",
                    ae = (null === (t = Z[0]) || void 0 === t ? void 0 : t.src) ? null === (n = Z[0]) || void 0 === n ? void 0 : n.src : {
                        widescreen: null === (o = V[0]) || void 0 === o ? void 0 : o.imgUrl
                    } || {},
                    oe = (null === (l = Z[1]) || void 0 === l ? void 0 : l.src) || {},
                    le = function(e) {
                        var t, n;
                        return void 0 === e && (e = {}), {
                            svg: {
                                title: Sl((null === (t = e.svg) || void 0 === t ? void 0 : t.title) || {}),
                                extra: Sl((null === (n = e.svg) || void 0 === n ? void 0 : n.extra) || {})
                            },
                            sortContent: wl((null == e ? void 0 : e.sortContent) || [])
                        }
                    }(A.extends || {});
                return a.createElement("div", {
                    className: r()("feature-tab--item", {
                        "feature-tab--item-main": "main" === D,
                        "feature-tab--item-other": "other" === D
                    }),
                    "data-ot-expose": JSON.stringify({
                        event: ["mainSPU", "otherSPU"].includes(L) ? "view_item_list" : "view_promotion",
                        tip: {
                            c: "".concat(W, "|").concat(z, "_").concat(q)
                        },
                        elementName: "featured_".concat(j),
                        elementTitle: "image_".concat(j, "_").concat(Y),
                        itemName: null === (f = null == V ? void 0 : V[0]) || void 0 === f ? void 0 : f.name
                    }),
                    role: "button",
                    tabIndex: -1,
                    onClick: function(e) {
                        var t;
                        return function(e, t) {
                            var n, a, o;
                            e.stopPropagation(), (null === (n = null == H ? void 0 : H[0]) || void 0 === n ? void 0 : n.gotoUrl) && (J({
                                event: ["mainSPU", "otherSPU"].includes(L) ? "select_item" : "select_promotion",
                                tip: {
                                    c: "".concat(W, "|").concat(z, "_").concat(q)
                                },
                                elementName: "featured_".concat(j),
                                elementTitle: "image_".concat(j, "_").concat(Y),
                                itemName: null === (a = null == V ? void 0 : V[0]) || void 0 === a ? void 0 : a.name,
                                link: "".concat(null === (o = null == H ? void 0 : H[0]) || void 0 === o ? void 0 : o.gotoUrl)
                            }), (0, v.MN)(t))
                        }(e, null === (t = null == H ? void 0 : H[0]) || void 0 === t ? void 0 : t.gotoUrl)
                    }
                }, a.createElement("div", {
                    className: "image-block"
                }, oe.widescreen && a.createElement(i.t, {
                    className: "item-image background-image",
                    alt: Q.get("cf03dddc7ea96bb4d4e799607cfc8351", {
                        ns: "translation"
                    }),
                    srcSet: oe,
                    lazyLoading: !(R <= 2 && 1 === z)
                }), a.createElement(i.t, {
                    className: "item-image",
                    alt: (null === (p = Z[0]) || void 0 === p ? void 0 : p.alt) || (null === (g = null == H ? void 0 : H[0]) || void 0 === g ? void 0 : g.text) || "",
                    srcSet: ae,
                    lazyLoading: !(R <= 2 && 1 === z)
                })), a.createElement("div", {
                    className: "".concat(ne)
                }, (null === (b = null === (_ = null == le ? void 0 : le.svg) || void 0 === _ ? void 0 : _.title) || void 0 === b ? void 0 : b.pc) ? a.createElement("img", {
                    className: "slide__svg slide__title--svg",
                    src: null == le ? void 0 : le.svg.title.pc,
                    alt: "title"
                }) : a.createElement("h2", {
                    className: "".concat(ne, "__title")
                }, Y), !!le.svg.extra.pc && a.createElement("img", {
                    className: "slide__svg",
                    src: le.svg.extra.pc,
                    alt: "title"
                }), !!(null === (y = le.sortContent[0]) || void 0 === y ? void 0 : y.text) && !("1left4" === F && "other" === D) && a.createElement("h3", {
                    className: "".concat(ne, "__subtitle")
                }, null === (E = le.sortContent[0]) || void 0 === E ? void 0 : E.text, a.createElement(So, {
                    className: "slide__footnote-label",
                    index: null === (h = le.sortContent[0]) || void 0 === h ? void 0 : h.footnote.index
                })), !!(null === (N = le.sortContent[1]) || void 0 === N ? void 0 : N.text) && !("1left4" === F && "other" === D) && a.createElement("span", {
                    className: "".concat(ne, "__description")
                }, null === (k = le.sortContent[1]) || void 0 === k ? void 0 : k.text, a.createElement(So, {
                    className: "slide__footnote-label",
                    index: null === (x = le.sortContent[1]) || void 0 === x ? void 0 : x.footnote.index
                })), ["mainSPU", "otherSPU"].includes(L) && a.createElement(c.Y, {
                    className: "".concat(ne, "__energy"),
                    energyInfo: null === (S = null == V ? void 0 : V[0]) || void 0 === S ? void 0 : S.energyInfo
                }), a.createElement("div", {
                    className: "".concat(ne, "__translate")
                }, $.isToC && ["mainSPU", "otherSPU"].includes(L) && a.createElement(s.n, {
                    className: "".concat(ne, "__price"),
                    salePrice: String(null === (w = V[0]) || void 0 === w ? void 0 : w.salePrice),
                    delPrice: String(null === (T = V[0]) || void 0 === T ? void 0 : T.originPrice),
                    isShowFrom: !(null === (O = V[0]) || void 0 === O ? void 0 : O.salePriceIsEQ),
                    isShowBlank: K || !te
                }), !!(null === (I = le.sortContent[0]) || void 0 === I ? void 0 : I.text) && !$.isToC && "1left4" === F && "other" === D && a.createElement("h3", {
                    className: "".concat(ne, "__subtitle")
                }, null === (M = le.sortContent[0]) || void 0 === M ? void 0 : M.text, a.createElement(So, {
                    className: "slide__footnote-label",
                    index: null === (U = le.sortContent[0]) || void 0 === U ? void 0 : U.footnote.index
                })), !X && a.createElement("div", {
                    className: "".concat(ne, "__button-wrapper")
                }, a.createElement(u.z, {
                    className: "".concat(ne, "__button"),
                    btnType: "primary",
                    href: null === (P = null == H ? void 0 : H[0]) || void 0 === P ? void 0 : P.gotoUrl
                }, Q.get("f5395c9793af8a11b406ca7c1ac70da9", {
                    ns: "translation"
                }))))))
            }
            var Ol = function(e, t) {
                var n = "function" == typeof Symbol && e[Symbol.iterator];
                if (!n) return e;
                var a, o, l = n.call(e),
                    r = [];
                try {
                    for (;
                        (void 0 === t || t-- > 0) && !(a = l.next()).done;) r.push(a.value)
                } catch (i) {
                    o = {
                        error: i
                    }
                } finally {
                    try {
                        a && !a.done && (n = l.return) && n.call(l)
                    } finally {
                        if (o) throw o.error
                    }
                }
                return r
            };

            function Il(e) {
                var t = e.itemProps,
                    n = e.skeletonData,
                    o = e.tabIndex,
                    l = e.tabName,
                    i = e.otModule,
                    c = e.isActiveTab,
                    s = e.layoutIndex,
                    u = e.otClick,
                    m = e.setTabPaneHeight,
                    d = t.title,
                    v = t.tips,
                    f = t.type,
                    p = t.slides,
                    g = (0, a.useRef)(null),
                    _ = "feature-tab-content",
                    b = function(e, t) {
                        var n = e.slice(0, 1),
                            a = e.slice(1, e.length);
                        switch (t) {
                            case "1S-4S":
                            case "1C-4S":
                                return kl(kl([], Nl(n), !1), Nl(Cl(a)), !1).slice(0, 5);
                            case "1S-2S":
                            case "1C-2S":
                                return kl(kl([], Nl(n), !1), Nl(Cl(a)), !1).slice(0, 3);
                            case "2S-2S":
                                return Cl(e).slice(0, 4);
                            case "1C-4C":
                            default:
                                return e.slice(0, 5);
                            case "1C-2C":
                                return e.slice(0, 3);
                            case "1S":
                            case "1C":
                                return e.slice(0, 1)
                        }
                    }(p, f);
                return (0, a.useEffect)((function() {
                    var e;
                    if (c) {
                        var t = String((null === (e = null == g ? void 0 : g.current) || void 0 === e ? void 0 : e.clientHeight) || "initial");
                        m(t)
                    }
                }), [c]), a.createElement("div", {
                    className: r()("".concat(_), "".concat(_, "--").concat(v), "".concat(_, "--").concat(f)),
                    ref: g
                }, Array.from(b || []).map((function(e, t) {
                    return a.createElement(a.Fragment, {
                        key: "".concat(d, "-").concat(t)
                    }, 0 === t && ["1S", "1C", "1S-4S", "1C-4S", "1C-4C", "1S-2S", "1C-2S", "1C-2C"].includes(f) && a.createElement(Tl, {
                        itemType: xl(f, 0),
                        itemStyle: "main",
                        layout: v,
                        layoutType: f,
                        itemProps: e,
                        skeletonData: n,
                        otClick: u,
                        otModule: i,
                        tabIndex: o,
                        tabName: l,
                        itemIndex: t + 1,
                        layoutIndex: s
                    }), ("2S-2S" === f || 0 !== t) && a.createElement(Tl, {
                        itemType: xl(f, t),
                        itemStyle: "other",
                        layout: v,
                        layoutType: f,
                        itemProps: e,
                        skeletonData: n,
                        otClick: u,
                        otModule: i,
                        tabIndex: o,
                        tabName: l,
                        itemIndex: t + 1,
                        layoutIndex: s
                    }))
                })))
            }

            function Ml(e) {
                var t, n = e.classModify,
                    o = e.otClick,
                    l = e.otExpose,
                    i = e.otModule,
                    c = e.slides,
                    s = e.skeletonData,
                    u = e.layoutIndex,
                    m = (0, d.YB)(),
                    v = "mobile" === (0, C.a)(),
                    f = (0, a.useRef)(),
                    p = (0, a.useRef)(null),
                    g = Ol((0, a.useState)(0), 2),
                    _ = g[0],
                    b = g[1],
                    y = Ol((0, a.useState)("initial"), 2),
                    E = y[0],
                    h = y[1],
                    N = "feature-tab";

                function k(e, t, n) {
                    var a;
                    if (o({
                            event: "click",
                            tip: {
                                c: "".concat(i, "|").concat(t + 1)
                            },
                            elementName: "featured",
                            elementTitle: "tab_".concat(n)
                        }), t !== _) {
                        b(t),
                            function(e) {
                                var t;
                                null === (t = f.current) || void 0 === t || t.slideTo(e, 0)
                            }(t);
                        var l = e.currentTarget;
                        Array.from((null === (a = p.current) || void 0 === a ? void 0 : a.children) || []).forEach((function(e) {
                            return e.classList.remove("feature-tab--active")
                        })), l.classList.add("feature-tab--active"), x(l)
                    }
                }

                function x(e) {
                    var t = p.current;
                    if (t) {
                        var n = t.offsetWidth || 360,
                            a = e.offsetWidth,
                            o = e.offsetLeft - n / 2 + a / 2;
                        t.scrollLeft = o
                    }
                }
                var S;
                return a.createElement("div", {
                    className: r()("".concat(N), (t = {}, t["".concat(N, "--").concat(n)] = !!n, t)),
                    "data-ot-expose": JSON.stringify({
                        tip: {
                            c: i
                        },
                        elementName: "featured"
                    })
                }, a.createElement("div", {
                    className: "".concat(N, "-title")
                }, m.get("cf8156f1f57a8603cd6b3a28c9c2c61b")), a.createElement("div", {
                    className: "".concat(N, "__container")
                }, a.createElement("div", {
                    className: "".concat(N, "__header")
                }, a.createElement("div", {
                    className: "tab-header__wrapper",
                    ref: p
                }, (S = c, Array.isArray(S) ? S : [S]).map((function(e, t) {
                    var n, o = e.title;
                    return a.createElement("div", {
                        className: r()((n = {}, n["".concat(N, "__item")] = !0, n["".concat(N, "--active")] = _ ? _ === t : !t, n)),
                        key: t,
                        role: "button",
                        tabIndex: -1,
                        onClick: function(e) {
                            return k(e, t, o)
                        }
                    }, a.createElement("div", null, o))
                })))), a.createElement("div", {
                    className: "".concat(N, "__pane"),
                    style: {
                        "--tab-pane-height": "".concat(E, "px")
                    }
                }, a.createElement(oe.t, {
                    onSwiper: function(e) {
                        f.current = e
                    },
                    spaceBetween: 0,
                    keyboard: !!v,
                    allowTouchMove: !!v,
                    onSlideChange: function(e) {
                        var t;
                        b(e.realIndex), (t = document.querySelector(".feature-tab--active")) && x(t)
                    }
                }, c.map((function(e, t) {
                    return e && a.createElement(le.o, {
                        key: "".concat(e.title, "-").concat(t)
                    }, a.createElement(Il, {
                        itemProps: e,
                        otClick: o,
                        otModule: i,
                        otExpose: l,
                        tabIndex: t + 1,
                        tabName: e.title,
                        skeletonData: s,
                        isActiveTab: _ === t,
                        layoutIndex: u,
                        setTabPaneHeight: h
                    }))
                }))))))
            }

            function Ul(e) {
                var t, n = e.classModify;
                return a.createElement("div", {
                    className: r()((t = {
                        "multiple-spu": !0
                    }, t["multiple-spu--".concat(n)] = !!n, t))
                }, a.createElement("div", null, a.createElement("img", {
                    className: "preview-image",
                    src: "https://cdn.alsgp0.fds.api.mi-img.com/xiaomi-b2c-i18n-upload/i18n/images/demo/block-thumbnail/block-thumbnail-multiple-spu.png",
                    alt: ""
                })))
            }

            function Pl(e) {
                var t, n = e.classModify;
                return a.createElement("div", {
                    className: r()((t = {
                        "spu-custom": !0
                    }, t["spu-custom--".concat(n)] = !!n, t))
                }, a.createElement("div", null, a.createElement("img", {
                    className: "preview-image",
                    src: "https://cdn.alsgp0.fds.api.mi-img.com/xiaomi-b2c-i18n-upload/i18n/images/demo/block-thumbnail/block-thumbnail-spu-custom.png",
                    alt: ""
                })))
            }
            X.Z.use([To.Z, hl.Z]);
            var Al = n(66167);

            function Ll(e) {
                var t, n = e.type,
                    o = e.classModify;
                return a.createElement("div", {
                    className: r()((t = {
                        "block-feedback": !0
                    }, t["block-feedback--".concat(o)] = !!o, t))
                }, a.createElement(Al.r, {
                    type: Number(n)
                }))
            }

            function Dl(e) {
                var t, n = e.title,
                    o = e.classModify,
                    l = e.extends,
                    i = (0, C.a)(),
                    c = l.dataList,
                    s = [],
                    u = [];
                return c && c.forEach((function(e) {
                    e.inputInfo.forEach((function(e) {
                        u.push(e.name)
                    }))
                })), u.forEach((function(e, t) {
                    var n = t % c[0].inputInfo.length;
                    void 0 === s[n] ? s.push([e]) : s[n].push(e)
                })), a.createElement("div", {
                    className: r()((t = {
                        "multi-column-table": !0
                    }, t["multi-column-table--".concat(o)] = !!o, t))
                }, s && s.map((function(e, t) {
                    return a.createElement("div", {
                        key: t,
                        className: r()("multi-column--table-row", {
                            "multi-column--table-scroll": "mobile" === i && e.length > 3,
                            "multi-column--table-row-first": 0 === t
                        })
                    }, e.map((function(n, o) {
                        return a.createElement("div", {
                            key: o,
                            className: r()("multi-column--table-col", {
                                "multi-column--table-bl": 0 === t,
                                "multi-column--table-one": 1 === e.length,
                                "multi-column--table-two": 2 === e.length,
                                "multi-column--table-three": 3 === e.length,
                                "multi-column--table-four": 4 === e.length,
                                "multi-column--table-five": 5 === e.length
                            })
                        }, n)
                    })))
                })), a.createElement("h2", {
                    className: "mi-h2 multi-column--table-title"
                }, n))
            }

            function Fl(e) {
                var t, n = e.classModify,
                    o = e.otModule;
                return a.createElement("div", {
                    className: l((t = {
                        "site-default": !0
                    }, t["site-default--".concat(n)] = !!n, t)),
                    "data-ot-expose": JSON.stringify({
                        tip: {
                            c: o
                        }
                    })
                })
            }
            var jl = function() {
                    return jl = Object.assign || function(e) {
                        for (var t, n = 1, a = arguments.length; n < a; n++)
                            for (var o in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
                        return e
                    }, jl.apply(this, arguments)
                },
                zl = function(e, t) {
                    var n = {};
                    for (var a in e) Object.prototype.hasOwnProperty.call(e, a) && t.indexOf(a) < 0 && (n[a] = e[a]);
                    if (null != e && "function" == typeof Object.getOwnPropertySymbols) {
                        var o = 0;
                        for (a = Object.getOwnPropertySymbols(e); o < a.length; o++) t.indexOf(a[o]) < 0 && Object.prototype.propertyIsEnumerable.call(e, a[o]) && (n[a[o]] = e[a[o]])
                    }
                    return n
                };

            function ql(e) {
                var t = e.name,
                    n = zl(e, ["name"]),
                    o = {
                        banner: _,
                        "banner-event": y,
                        "banner-panorama": h,
                        "banner-text": S,
                        "banner-select": I,
                        breadcrumbs: P,
                        goods: A,
                        "goods-info": j,
                        "goods-sku": D,
                        event: z,
                        "daily-pick": V,
                        "text-a": Q,
                        "text-b": $,
                        "text-c": K,
                        swiper: re,
                        video: ue,
                        service: me,
                        entrance: ve,
                        "store-link-bar": pe,
                        "more-operator": ye,
                        "carrier-product": xe,
                        "store-partner": Ie,
                        "store-breadcrumbs": Ue,
                        "header-footer": Be,
                        "store-daily-pick": je,
                        "store-carrier": We,
                        "store-goods": Re.v,
                        "store-shop": Ye,
                        "store-week": Qe,
                        "store-title": Ke,
                        "store-event": et,
                        "store-menu": at,
                        "store-banner": ut,
                        "store-map": dt,
                        "new-product-title": bt,
                        "new-product-list": Nt,
                        "store-new-product": St,
                        "store-recommends": Tt,
                        "rich-text": Ot,
                        "tab-with-rich-text": Lt,
                        "tab-with-table": Gt,
                        "accordion-block": Zt,
                        search: Kt,
                        "service-product": en,
                        "support-small-btn": tn,
                        "support-button": an,
                        "height-faq": pn,
                        "support-title": _n,
                        "support-video": yn,
                        "phone-list": hn,
                        "image-description": Nn,
                        "service-share": Sn,
                        "support-article": wn,
                        "support-contact": jn,
                        "service-video": qn,
                        "service-background-text": Ft,
                        "support-country-info": zt,
                        "support-select": Bt,
                        "small-icon-text": Wt,
                        "image-with-desc": Bn,
                        "service-background-img": Wn,
                        "bubble-switcher": Rn,
                        blank: Gn,
                        "banner-flex": Vn,
                        "text-note": Zn,
                        "banner-links": Qn,
                        "daily-picks-list": Xn,
                        "social-share-bar": na,
                        "about-years": oa,
                        process: ga,
                        "page-gray-scale": _a,
                        "official-intro-steps": ya,
                        "store-popup-ads": xa,
                        "coupon-claim": qa,
                        "new-user-module": Qa,
                        "service-store-map": Xa,
                        "support-web-home": eo,
                        "explore-xiaomi": io,
                        "carousel-banner-normal": co,
                        "carousel-banner-important": so,
                        "official-service": uo,
                        "quick-link": fo,
                        "login-guide": po,
                        recommended: go,
                        "event-page-module": _o,
                        "daily-picks-app": bo,
                        "banner-h364": yo,
                        "new-product-app": Eo,
                        "carousel-banner": Jo,
                        "trade-in-sku": el,
                        "exclusive-offers": bl,
                        "ribbon-ads": El,
                        "featured-tabs": Ml,
                        "multiple-spu": Ul,
                        "spu-custom": Pl,
                        feedback: Ll,
                        "multi-column-table": Dl,
                        default: Fl
                    },
                    l = o[t] || o.default;
                return a.createElement(l, jl({}, n))
            }
            var Bl = n(14363),
                Wl = function() {
                    return Wl = Object.assign || function(e) {
                        for (var t, n = 1, a = arguments.length; n < a; n++)
                            for (var o in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
                        return e
                    }, Wl.apply(this, arguments)
                },
                Rl = function(e, t) {
                    var n = "function" == typeof Symbol && e[Symbol.iterator];
                    if (!n) return e;
                    var a, o, l = n.call(e),
                        r = [];
                    try {
                        for (;
                            (void 0 === t || t-- > 0) && !(a = l.next()).done;) r.push(a.value)
                    } catch (i) {
                        o = {
                            error: i
                        }
                    } finally {
                        try {
                            a && !a.done && (n = l.return) && n.call(l)
                        } finally {
                            if (o) throw o.error
                        }
                    }
                    return r
                },
                Jl = ["ribbon-ads", "carousel-banner", "featured-tabs", "explore-xiaomi", "exclusive-offers", "support-web-home"],
                Gl = ["index", "web/index"];

            function Yl(e) {
                var t = e.cmsPath,
                    n = e.doNotReportPageView,
                    l = void 0 !== n && n,
                    r = e.onGetDataSuccess,
                    i = (0, a.useContext)(m.__),
                    c = (0, o.TH)(),
                    s = c.pathname,
                    u = c.hash,
                    v = (0, d.Sz)(),
                    f = (0, C.a)(),
                    p = (0, d.Vi)(),
                    g = v ? (0, m.t5)(p, !1) : i.data,
                    _ = Rl((0, a.useState)(!0), 2),
                    b = _[0],
                    y = _[1],
                    E = (0, a.useMemo)((function() {
                        return "success" === i.ajaxStatus ? Array(g.layouts.length).fill(1).map((function() {
                            return (0, a.createRef)()
                        })) : []
                    }), [i.ajaxStatus]),
                    h = (0, a.useMemo)((function() {
                        return "success" === i.ajaxStatus ? Array(g.layouts.length).fill(1) : []
                    }), [i.ajaxStatus]),
                    x = (0, k.r)("moe"),
                    S = "true" === (null !== N.yv && void 0 !== N.yv ? N.yv : x);

                function w(e, t, n) {
                    var a = Rl((n || "|-").split("|"), 2)[1],
                        o = Rl((a || "-").split("-"), 1)[0],
                        l = T(e, 16756, t, Number(o || 0) - 1);
                    return e.event && "expose" !== e.event ? Object.assign({}, l, {
                        isOpenGA: !0,
                        eventType: "ecommerce"
                    }) : Object.assign({}, l, {
                        isOpenGA: !0
                    })
                }

                function T(e, t, n, a) {
                    var o, l, r, i, c, s, u, m, d, v, p, _, b, y, E, h, N, k, x, w, C, T, O, I, M, U = Object.assign(e.tip || {}, {
                            e: t
                        }),
                        P = g.layouts[n].children[a] || {},
                        A = Object.assign({}, e, {
                            event: e.event || "",
                            tip: U,
                            assetLink: e.assetLink || "",
                            linkUrl: e.linkUrl || e.link || (null === (l = null === (o = null == P ? void 0 : P.buttons) || void 0 === o ? void 0 : o[0]) || void 0 === l ? void 0 : l.gotoUrl) || "",
                            elementName: e.elementName || (null === (i = null === (r = null == P ? void 0 : P.buttons) || void 0 === r ? void 0 : r[0]) || void 0 === i ? void 0 : i.text) || (null == P ? void 0 : P.subtitle) || "",
                            elementTitle: e.elementTitle || (null == P ? void 0 : P.title) || "",
                            spuId: e.spuId || (null === (s = null === (c = null == P ? void 0 : P.goods) || void 0 === c ? void 0 : c[0]) || void 0 === s ? void 0 : s.spuId) || "",
                            productId: e.productId || (null === (m = null === (u = null == P ? void 0 : P.goods) || void 0 === u ? void 0 : u[0]) || void 0 === m ? void 0 : m.productId) || "",
                            goodsId: e.goodsId || "",
                            itemId: e.goodsId || ""
                        });
                    return e.event && "select_item" === e.event && (A = Object.assign({}, e, {
                        event: e.event || "",
                        moeEnable: S,
                        tip: U,
                        assetLink: e.assetLink || "",
                        linkUrl: e.linkUrl || e.link || (null === (v = null === (d = null == P ? void 0 : P.buttons) || void 0 === d ? void 0 : d[0]) || void 0 === v ? void 0 : v.gotoUrl) || "",
                        elementName: e.elementName || (null === (_ = null === (p = null == P ? void 0 : P.buttons) || void 0 === p ? void 0 : p[0]) || void 0 === _ ? void 0 : _.text) || (null == P ? void 0 : P.subtitle) || "",
                        elementTitle: e.elementTitle || (null == P ? void 0 : P.title) || "",
                        spuId: e.spuId || (null === (y = null === (b = null == P ? void 0 : P.goods) || void 0 === b ? void 0 : b[0]) || void 0 === y ? void 0 : y.spuId) || "",
                        productId: e.productId || (null === (h = null === (E = null == P ? void 0 : P.goods) || void 0 === E ? void 0 : E[0]) || void 0 === h ? void 0 : h.productId) || "",
                        goodsId: e.goodsId || "",
                        itemId: e.goodsId || ""
                    })), Object.assign({}, Wl({}, A), e.event ? {
                        ecommerce: Wl(Wl({}, A), {
                            items: [{
                                price: (null === (k = null === (N = null == P ? void 0 : P.goods) || void 0 === N ? void 0 : N[0]) || void 0 === k ? void 0 : k.salePrice) || void 0,
                                quantity: e.goodsId || (null === (w = null === (x = null == P ? void 0 : P.goods) || void 0 === x ? void 0 : x[0]) || void 0 === w ? void 0 : w.name) ? 1 : 0,
                                itemId: e.goodsId || "undefined",
                                itemName: e.itemName || (null === (T = null === (C = null == P ? void 0 : P.goods) || void 0 === C ? void 0 : C[0]) || void 0 === T ? void 0 : T.name) || "undefined",
                                itemListName: (null == P ? void 0 : P.name) || void 0,
                                index: Number(e.tip.d || a + 1 || 0),
                                promotionId: e.promotionId || void 0,
                                promotionName: e.promotionName || void 0,
                                creativeName: e.creativeName || (null === (M = null === (I = null === (O = null == P ? void 0 : P.images) || void 0 === O ? void 0 : O[0]) || void 0 === I ? void 0 : I.src) || void 0 === M ? void 0 : M[f]) || void 0,
                                creativeSlot: String(e.creativeSlot || 1)
                            }]
                        })
                    } : {})
                }
                return (0, a.useEffect)((function() {
                    var e = s.replace("/index.html", "").slice(1) || "index";
                    v || !e && !t || i.getService({
                        params: {
                            path: t || e
                        }
                    }, (function(e) {
                        var t = (null == e ? void 0 : e.data.seo.title) || "";
                        t && (document.title = t), u || b || window.scrollTo(0, 0);
                        var n = ((null == e ? void 0 : e.data.pageInfo.path) || "").replace(/\//g, "_");
                        !l && (0, ge.otView)({
                            tip: {
                                b: Gl.includes((null == e ? void 0 : e.data.pageInfo.path) || "") ? n : 107,
                                e: 16718
                            },
                            isOpenGA: !0,
                            pageType: n
                        }), y(!1), "function" == typeof r && r()
                    }))
                }), [s]), (0, a.useEffect)((function() {
                    return v || "success" !== i.ajaxStatus || E.forEach((function(e, t) {
                            e.current && (h[t] = (0, ge.otExposeWith)({
                                isInfinite: !1,
                                exposeThreshold: .3,
                                targetNodeWrapper: e.current,
                                targetNodeSelector: "[data-ot-expose]"
                            }, (function(e, n) {
                                var a;
                                return w(e || {}, t, String((null === (a = null == e ? void 0 : e.tip) || void 0 === a ? void 0 : a.c) || ""))
                            })))
                        })),
                        function() {
                            h.forEach((function(e) {
                                return e instanceof IntersectionObserver && e.disconnect()
                            }))
                        }
                }), [i.ajaxStatus]), a.createElement(ft.ZQ, null, a.createElement("main", {
                    className: "site-main"
                }, Array.from(g.layouts).map((function(e, t) {
                    return a.createElement(Bl.I, {
                        key: "".concat(e.id, "-").concat(t),
                        margin: e.margin,
                        style: e.style,
                        ref: E[t]
                    }, Array.from(e.children).map((function(n, o) {
                        return a.createElement(ql, Wl({
                            key: "".concat(n.title, "-").concat(t, "-").concat(o)
                        }, n, {
                            otClick: function(e) {
                                return function(e, t, n) {
                                    var a = T(e, 16719, t, n);
                                    e.event && "click" !== e.event ? ((0, ge.otClick)(a), (0, ge.otEcommerce)(a)) : (0, ge.otClick)(Object.assign({}, a, {
                                        isOpenGA: !0
                                    }))
                                }(e, t, o)
                            },
                            otExpose: function(e, n) {
                                return w(e, t, n)
                            },
                            otModule: Jl.includes(e.name) ? "".concat(t + 1, "_").concat(e.name) : "".concat(e.id, "-").concat(e.style, "|").concat(o + 1, "-").concat(n.name),
                            layoutIndex: t
                        }))
                    })))
                }))))
            }
        },
        66167: (e, t, n) => {
            n.d(t, {
                r: () => N
            });
            var a = n(67294),
                o = n(94184),
                l = n(62711),
                r = n(20786),
                i = n(82138),
                c = n(56024),
                s = n(1796),
                u = n(26644),
                m = n(1128),
                d = n(1159),
                v = n(86690),
                f = n(7148),
                p = n(68673),
                g = n(67970),
                _ = n(42296),
                b = function() {
                    return b = Object.assign || function(e) {
                        for (var t, n = 1, a = arguments.length; n < a; n++)
                            for (var o in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
                        return e
                    }, b.apply(this, arguments)
                },
                y = function(e, t) {
                    var n = "function" == typeof Symbol && e[Symbol.iterator];
                    if (!n) return e;
                    var a, o, l = n.call(e),
                        r = [];
                    try {
                        for (;
                            (void 0 === t || t-- > 0) && !(a = l.next()).done;) r.push(a.value)
                    } catch (i) {
                        o = {
                            error: i
                        }
                    } finally {
                        try {
                            a && !a.done && (n = l.return) && n.call(l)
                        } finally {
                            if (o) throw o.error
                        }
                    }
                    return r
                },
                E = "feedback-modal";

            function h(e) {
                var t, n, g = e.type,
                    b = (0, c.a)(),
                    h = (0, s.oW)(),
                    N = (0, s.YB)(),
                    k = y((0, a.useState)(!1), 2),
                    x = k[0],
                    S = k[1],
                    w = y((0, a.useState)(!1), 2),
                    C = w[0],
                    T = w[1],
                    O = y((0, a.useState)(!1), 2),
                    I = O[0],
                    M = O[1],
                    U = y((0, a.useState)(!1), 2),
                    P = U[0],
                    A = U[1],
                    L = y((0, a.useState)(!1), 2),
                    D = L[0],
                    F = L[1],
                    j = y((0, a.useState)([]), 2),
                    z = j[0],
                    q = j[1],
                    B = y((0, a.useState)(""), 2),
                    W = B[0],
                    R = B[1],
                    J = y((0, a.useState)(""), 2),
                    G = J[0],
                    Y = J[1],
                    V = y((0, a.useState)(""), 2),
                    Z = V[0],
                    H = V[1],
                    Q = y((0, a.useState)(!1), 2),
                    $ = Q[0],
                    K = Q[1],
                    X = (0, a.useContext)(f.o),
                    ee = (0, a.useContext)(p.j),
                    te = function(e) {
                        X.getService({
                            params: {
                                code: e,
                                module: g,
                                languageId: (0, _.B)(h.local)
                            }
                        }, (function(e) {
                            var t, n, a;
                            if (200 === (null == e ? void 0 : e.errNo)) {
                                var o = (null === (t = null == e ? void 0 : e.data) || void 0 === t ? void 0 : t.dataList) || [],
                                    l = o && o.map((function(e) {
                                        return {
                                            question: e.question,
                                            type: e.type,
                                            choiceType: e.choiceType,
                                            questionId: e.questionId,
                                            sourceQuestionIdentifier: e.sourceQuestionIdentifier,
                                            answerList: e.answerList,
                                            isEmpty: !1,
                                            value: 647390002 === e.type ? 0 : "",
                                            dataChildList: e.dataChildList
                                        }
                                    }));
                                S(!0), q(l), R((null === (n = null == e ? void 0 : e.data) || void 0 === n ? void 0 : n.msfpSurveyId) || ""), Y(null === (a = null == e ? void 0 : e.data) || void 0 === a ? void 0 : a.msfpSurveyName), setTimeout((function() {
                                    T(!0)
                                }), 1e4)
                            } else S(!1)
                        }))
                    };
                (0, a.useEffect)((function() {
                    if ("mobile" === b && (0, u.j1)() && K(!0), (0, m.Nr)()) ee.getService({}, (function(e) {
                        var t, n, a = (null === (n = null === (t = null == e ? void 0 : e.data) || void 0 === t ? void 0 : t.profile) || void 0 === n ? void 0 : n.userId) || "";
                        te(String(a)), H(String(a))
                    }));
                    else {
                        var e = d.LH.get("xmuuid");
                        e && te(String(e)), H(String(e))
                    }
                }), []);
                var ne = function() {
                        return a.createElement("div", {
                            className: "".concat(E, "__detail")
                        }, a.createElement("div", {
                            className: "".concat(E, "__detail-box")
                        }, a.createElement(l.q, {
                            symbol: "close",
                            className: "".concat(E, "__detail-icon"),
                            onClick: function() {
                                return M(!1)
                            }
                        })), a.createElement("span", {
                            className: "".concat(E, "__detail-title")
                        }, N.get("80b00eab69719a4be33e0abda6b827f0")), a.createElement("div", {
                            className: "".concat(E, "__detail-line")
                        }), a.createElement(i.X, {
                            type: g,
                            successFunc: function(e) {
                                return function(e) {
                                    M(!e), A(e)
                                }(e)
                            },
                            propsQuestionList: z,
                            propsMsfpSurveyId: W,
                            propsMsfpSurveyName: G,
                            propsUserId: Z,
                            getNewListInfo: function(e) {
                                return q(e)
                            }
                        }))
                    },
                    ae = function() {
                        return a.createElement("div", {
                            className: "".concat(E, "__result")
                        }, a.createElement("div", {
                            className: "".concat(E, "__detail-box")
                        }, a.createElement(l.q, {
                            symbol: "close",
                            className: "".concat(E, "__detail-icon"),
                            onClick: function() {
                                A(!1), S(!1)
                            }
                        })), a.createElement("span", {
                            className: "".concat(E, "__detail-title")
                        }, N.get("80b00eab69719a4be33e0abda6b827f0")), a.createElement("div", {
                            className: "".concat(E, "__detail-line")
                        }), a.createElement("img", {
                            className: "".concat(E, "__result-img"),
                            src: "https://i02.appmifile.com/after-sales/feedback_result_new.svg",
                            alt: "detail-img"
                        }), a.createElement("span", {
                            className: "".concat(E, "__result-text")
                        }, N.get("79c3c4f4b2ee9e9614772392a0fd3b8e")))
                    };
                return a.createElement("div", {
                    className: o((t = {}, t[E] = !0, t["".concat(E, "__btn-relative")] = !$, t))
                }, x && a.createElement("div", {
                    className: o("".concat(E, "__btn"), (n = {}, n["".concat(E, "__btn--active")] = C, n["".concat(E, "__btn--absolute")] = $, n))
                }, a.createElement("div", {
                    className: "".concat(E, "__btn-box"),
                    onClick: function() {
                        return M(!0), F(!0), void(0, v.otClick)({
                            tip: i.k[g][1],
                            pageType: i.k[g][0],
                            elementName: 5 === g ? "feedback" : "selfservice-feedback",
                            elementTitle: "icon",
                            isOpenGA: !0
                        })
                    },
                    role: "button",
                    tabIndex: 0
                }, a.createElement("span", {
                    className: "".concat(E, "__btn-text")
                }, N.get("80b00eab69719a4be33e0abda6b827f0")))), I && ("mobile" === b ? a.createElement(r.u, {
                    extraClassName: "feedback-modal",
                    styleMode: "bottom",
                    isModalShow: D,
                    closeModal: function() {
                        return F(!1)
                    }
                }, ne()) : ne()), P && ("mobile" === b ? a.createElement(r.u, {
                    extraClassName: "feedback-modal",
                    styleMode: "bottom",
                    isModalShow: D,
                    closeModal: function() {
                        return F(!1)
                    }
                }, ae()) : ae()))
            }

            function N(e) {
                var t = (0, s.oW)();
                return a.createElement(p.$, {
                    siteConfig: t,
                    isAutoFetch: !1
                }, a.createElement(f.c, {
                    siteConfig: t
                }, a.createElement(g.j, {
                    siteConfig: t
                }, a.createElement(h, b({}, e)))))
            }
        },
        43769: (e, t, n) => {
            n.d(t, {
                $m: () => v,
                C9: () => f,
                lS: () => p
            });
            var a, o, l = n(67294),
                r = n(16607),
                i = n(96625),
                c = n(67279),
                s = n(7894),
                u = function(e, t) {
                    var n = "function" == typeof Symbol && e[Symbol.iterator];
                    if (!n) return e;
                    var a, o, l = n.call(e),
                        r = [];
                    try {
                        for (;
                            (void 0 === t || t-- > 0) && !(a = l.next()).done;) r.push(a.value)
                    } catch (i) {
                        o = {
                            error: i
                        }
                    } finally {
                        try {
                            a && !a.done && (n = l.return) && n.call(l)
                        } finally {
                            if (o) throw o.error
                        }
                    }
                    return r
                };
            var m = {
                    data: (null === (a = window.__PRELOADED_STATE__) || void 0 === a ? void 0 : a.data) || [],
                    ajaxStatus: (null === (o = window.__PRELOADED_STATE__) || void 0 === o ? void 0 : o.data) ? "success" : "unsent",
                    getServiceSuccess: !1
                },
                d = (0, r.o)(p, m),
                v = (0, l.createContext)(d);

            function f(e) {
                var t = e.siteConfig,
                    n = e.isAutoFetch,
                    a = e.children,
                    o = u((0, l.useState)(d), 2),
                    r = o[0],
                    c = o[1];

                function s(e) {
                    var t = e.data,
                        n = e.errmsg,
                        a = e.errno,
                        o = e.__responseHeaders__;
                    return {
                        data: p(t || [], Number(o["xm-server-timestamp"] || 0)),
                        errMsg: String(n),
                        errNo: Number(a)
                    }
                }
                var m = {
                    url: "".concat(t.goSite, "/activity/home"),
                    method: "GET",
                    withCredentials: !0,
                    retryOptions: {
                        maxRetryAttempts: 1,
                        scalingDuration: 3e3
                    },
                    basicParams: {
                        from: "web"
                    }
                };
                return l.createElement(i.h, {
                    context: v,
                    setState: c,
                    defaultValue: d,
                    adapterError: function(e) {
                        return s(e)
                    },
                    adapter: s,
                    value: r,
                    siteConfig: t,
                    isAutoFetch: !0 === n,
                    ajaxConfig: m
                }, a)
            }

            function p(e, t) {
                return void 0 === e && (e = []), Array.from(e || []).map((function(e) {
                    return {
                        actId: Number(e.act_id || 0),
                        actType: Number(e.act_type || 0),
                        children: g(e.children || []),
                        endTime: Number(e.end_time || 0),
                        startTime: Number(e.start_time || 0),
                        serverTime: Number(t || Math.floor(Date.now() / 1e3))
                    }
                }))
            }

            function g(e) {
                return void 0 === e && (e = []), Array.from(e || []).map((function(e) {
                    return {
                        childId: Number(e.child_id || 0),
                        goodsIdList: String(e.goods_ids || "").split(",").map((function(e) {
                            return Number(e || 0)
                        })),
                        title: String(e.name || ""),
                        subtitle: String(e.desc || ""),
                        buyUrl: String(e.buy_url || ""),
                        giftUrl: String(e.gift_url || ""),
                        imgUrl: String(e.img_url || ""),
                        promoImgUrl: String(e.pre_img_url || e.img_url || ""),
                        isSubscribed: !!e.is_follow,
                        tagList: _(e.tags || []),
                        salePriceText: String(e.disct_price || ""),
                        originPriceText: String(e.price || ""),
                        energyInfo: (0, c.T)(e.energy || []),
                        marketingInfo: (0, s.p)(e.marketing_tags || [])
                    }
                }))
            }

            function _(e) {
                return void 0 === e && (e = []), Array.from(e || []).map((function(e) {
                    return {
                        type: Number(e.type || 0),
                        name: String(e.name || ""),
                        detail: String(e.detail || "")
                    }
                }))
            }
        },
        6658: (e, t, n) => {
            n.d(t, {
                J: () => s,
                N: () => c
            });
            var a = n(67294),
                o = n(16607),
                l = n(96625),
                r = function(e, t) {
                    var n = "function" == typeof Symbol && e[Symbol.iterator];
                    if (!n) return e;
                    var a, o, l = n.call(e),
                        r = [];
                    try {
                        for (;
                            (void 0 === t || t-- > 0) && !(a = l.next()).done;) r.push(a.value)
                    } catch (i) {
                        o = {
                            error: i
                        }
                    } finally {
                        try {
                            a && !a.done && (n = l.return) && n.call(l)
                        } finally {
                            if (o) throw o.error
                        }
                    }
                    return r
                },
                i = (0, o.o)(u),
                c = (0, a.createContext)(i);

            function s(e) {
                var t = e.siteConfig,
                    n = e.isAutoFetch,
                    o = e.children,
                    s = r((0, a.useState)(i), 2),
                    m = s[0],
                    d = s[1];

                function v(e) {
                    var n = e.data,
                        a = e.errmsg,
                        o = e.errno;
                    return {
                        data: u(n || {}, t),
                        errMsg: String(a),
                        errNo: Number(o)
                    }
                }
                var f = {
                    url: "".concat(t.goSite, "/authorizedstore/getdata"),
                    method: "GET"
                };
                return a.createElement(l.h, {
                    context: c,
                    setState: d,
                    defaultValue: i,
                    adapterError: function(e) {
                        return v(e)
                    },
                    adapter: v,
                    value: m,
                    siteConfig: t,
                    isAutoFetch: !!n,
                    ajaxConfig: f
                }, o)
            }

            function u(e, t) {
                void 0 === e && (e = {});
                var n = t || {};
                return {
                    storeList: m(e.storeList || [], n),
                    storeTypeInfo: e.storeTypeInfo || {},
                    partnerList: d(e.partnerList || [])
                }
            }

            function m(e, t) {
                return void 0 === e && (e = []), Array.from(e || []).map((function(e) {
                    return {
                        id: String(e.id || ""),
                        name: String(e.name || ""),
                        image: (n = e.pic, a = /^(http:)/, (a.test(n) ? n.replace(a, "https:") : n) || ""),
                        address: String(e.address || ""),
                        storeType: String(e.storeType || ""),
                        longitude: Number(e.longitude || 1e3),
                        latitude: Number(e.latitude || 1e3),
                        link: e.id ? "".concat(t.wwwSite.pc, "/store/xiaomi-store/detail/").concat(String(e.id)) : "",
                        weekend: String(e.weekend || ""),
                        mobileArr: Array.from(e.mobileArr || []).map((function(e) {
                            return String(e || "")
                        })).filter((function(e) {
                            return !!e && "0" !== e && "/" !== e
                        }))
                    };
                    var n, a
                }))
            }

            function d(e) {
                return void 0 === e && (e = []), Array.from(e || []).map((function(e) {
                    return {
                        partnerTypeDesc: String(e.partnerTypeDesc || ""),
                        partnerTypeName: String(e.partnerTypeName || ""),
                        type: Number(e.type || 0),
                        partnerInfoList: v(e.PartnerList || [])
                    }
                }))
            }

            function v(e) {
                return void 0 === e && (e = []), Array.from(e || []).map((function(e) {
                    return {
                        image: String(e.image || ""),
                        name: String(e.name || ""),
                        turnLink: String(e.turnLink || "")
                    }
                }))
            }
        },
        31182: (e, t, n) => {
            n.d(t, {
                S: () => c,
                d: () => s
            });
            var a = n(67294),
                o = n(16607),
                l = n(96625),
                r = function(e, t) {
                    var n = "function" == typeof Symbol && e[Symbol.iterator];
                    if (!n) return e;
                    var a, o, l = n.call(e),
                        r = [];
                    try {
                        for (;
                            (void 0 === t || t-- > 0) && !(a = l.next()).done;) r.push(a.value)
                    } catch (i) {
                        o = {
                            error: i
                        }
                    } finally {
                        try {
                            a && !a.done && (n = l.return) && n.call(l)
                        } finally {
                            if (o) throw o.error
                        }
                    }
                    return r
                },
                i = (0, o.o)(u),
                c = (0, a.createContext)(i);

            function s(e) {
                var t = e.siteConfig,
                    n = e.isAutoFetch,
                    o = e.children,
                    s = r((0, a.useState)(i), 2),
                    m = s[0],
                    d = s[1];

                function v(e) {
                    var t = e.data,
                        n = e.errmsg,
                        a = e.errno;
                    return {
                        data: u(t || {}),
                        errMsg: String(n),
                        errNo: Number(a)
                    }
                }
                var f = {
                    url: "".concat(t.goSite, "/v2/page/newproductwatch"),
                    method: "POST",
                    withCredentials: !0
                };
                return a.createElement(l.h, {
                    context: c,
                    setState: d,
                    defaultValue: i,
                    adapterError: function(e) {
                        return v(e)
                    },
                    adapter: v,
                    value: m,
                    siteConfig: t,
                    isAutoFetch: !0 === n,
                    ajaxConfig: f
                }, o)
            }

            function u(e) {
                return void 0 === e && (e = {}), {
                    actionResponse: String(e || "")
                }
            }
        }
    }
]);