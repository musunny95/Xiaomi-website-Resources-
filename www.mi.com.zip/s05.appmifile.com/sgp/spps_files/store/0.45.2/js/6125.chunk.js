"use strict";
(self.__LOADABLE_LOADED_CHUNKS__ = self.__LOADABLE_LOADED_CHUNKS__ || []).push([
    [6125], {
        16125: (e, i, l) => {
            l.d(i, {
                __: () => P,
                hP: () => v,
                t5: () => U
            });
            var o = l(67294),
                a = l(16607),
                t = l(96625),
                r = [{
                    id: 1,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group01.png",
                    style: 1,
                    margin: "small-top",
                    title: "[1] Banner with SPU data",
                    children: ["banner"],
                    useWideEditor: 600,
                    denyPath: ["/store", "/store/*", "/support", "/support/*", "/about", "/about/*", "/new-user", "/app/index"]
                }, {
                    id: 2,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group02.png",
                    style: 1,
                    margin: "small-top",
                    title: "[2] Banner with tips",
                    children: ["banner-event"],
                    denyPath: ["/store", "/store/*", "/support", "/support/*", "/about", "/about/*", "/new-user", "/app/index"]
                }, {
                    id: 3,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group03.png",
                    style: 2,
                    margin: "medium-special",
                    title: "[3] Two SPU components",
                    children: ["goods", "goods"],
                    repeat: ["goods"],
                    allowPath: ["/index"]
                }, {
                    id: 4,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group04.png",
                    style: 14,
                    margin: "medium-first",
                    title: "[4] Events and DailyPick widget",
                    children: ["event", "event", "daily-pick"],
                    allowPath: ["/index"]
                }, {
                    id: 5,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group05.png",
                    style: 1,
                    margin: "large",
                    title: "[5] Product gallery",
                    children: ["swiper"],
                    denyPath: ["/store", "/phone", "/phone/*", "/support", "/support/*", "/about", "/about/*", "/new-user", "/app/index"]
                }, {
                    id: 6,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group06.png",
                    style: 6,
                    margin: "large",
                    title: "[6] Support entrance",
                    children: ["text-a", "text-b", "text-b"],
                    denyPath: ["/store", "/store/*", "/phone", "/phone/*", "/support", "/support/*", "/about", "/about/*", "/new-user", "/app/index"]
                }, {
                    id: 7,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group07.png",
                    style: 1,
                    margin: "small-special",
                    title: "[7] Background video",
                    children: ["video"],
                    denyPath: ["/store", "/store/*", "/support", "/support/*", "/about", "/about/*", "/new-user", "/app/index"]
                }, {
                    id: 8,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group08.png",
                    style: 2,
                    margin: "medium-special",
                    title: "[8] Block goods * 2",
                    children: ["goods-sku", "goods-sku"],
                    repeat: ["goods-sku"],
                    denyPath: ["/store", "/store/*", "/index", "/support", "/support/*", "/about", "/about/*", "/new-user", "/app/index"]
                }, {
                    id: 9,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group09.png",
                    style: 5,
                    margin: "medium",
                    title: "[9] Block goods * 4",
                    children: ["goods-sku", "goods-sku", "goods-sku", "goods-sku"],
                    repeat: ["goods-sku"],
                    minItem: 4,
                    maxItem: 12,
                    denyPath: ["/store", "/store/*", "/index", "/support", "/support/*", "/about", "/about/*", "/new-user", "/app/index"]
                }, {
                    id: 10,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group10.png",
                    style: 5,
                    margin: "medium",
                    title: "[10] Block goods * 3 w/ more",
                    children: ["goods-sku", "goods-sku", "goods-sku", "text-c"],
                    repeat: ["goods-sku"],
                    minItem: 4,
                    maxItem: 12,
                    denyPath: ["/store", "/store/*", "/index", "/support", "/support/*", "/about", "/about/*", "/new-user", "/app/index"]
                }, {
                    id: 11,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group11.png",
                    style: 1,
                    margin: "large-special",
                    title: "[11] Model room",
                    children: ["banner-panorama"],
                    denyPath: ["/store", "/store/*", "/support", "/support/*", "/about", "/about/*", "/new-user", "/app/index"]
                }, {
                    id: 12,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group12.png",
                    style: 1,
                    margin: "small",
                    title: "[12] Wide title",
                    children: ["banner-text"],
                    denyPath: ["/store", "/store/*", "/support", "/support/*", "/about", "/about/*", "/new-user", "/app/index"]
                }, {
                    id: 13,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group13.png",
                    style: 1,
                    margin: "small-special",
                    title: "[13] Wide title with navigation",
                    children: ["banner-select"],
                    allowPath: ["/phone/*"]
                }, {
                    id: 14,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group14.png",
                    style: 2,
                    margin: "medium-special",
                    title: "[14] Service entrance",
                    children: ["service", "service"],
                    denyPath: ["/store", "/store/*", "/support", "/support/*", "/about", "/about/*", "/new-user", "/app/index"]
                }, {
                    id: 15,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group15.png",
                    style: 3,
                    margin: "medium",
                    title: "[15] Block goods * 3",
                    children: ["goods-sku", "goods-sku", "goods-sku"],
                    repeat: ["goods-sku"],
                    denyPath: ["/store", "/store/*", "/index", "/support", "/support/*", "/about", "/about/*", "/new-user", "/app/index"]
                }, {
                    id: 16,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group16.png",
                    style: 1,
                    margin: "small-top",
                    title: "[16] Banners with slider",
                    children: ["store-banner"],
                    denyPath: ["/app/index"]
                }, {
                    id: 17,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group17.png",
                    style: 1,
                    margin: "small",
                    title: "[17] Quick Access (Store Menu)",
                    children: ["store-menu"],
                    allowPath: ["/store"]
                }, {
                    id: 18,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group18.png",
                    style: 1,
                    margin: "store-medium",
                    title: "[18] Event fashion entrance",
                    children: ["store-event"],
                    allowPath: ["/store", "/new-user", "/phone", "/phone/*", "/smart-home", "/smart-office", "/life-style"]
                }, {
                    id: 19,
                    name: "",
                    enable: 0,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group19.png",
                    style: 1,
                    margin: "store-large-special",
                    title: "[19] DailyPicks section",
                    children: ["store-daily-pick"],
                    allowPath: ["/store"]
                }, {
                    id: 20,
                    name: "store-title",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group20.png",
                    style: 1,
                    margin: "store-small-title",
                    title: "[20] Section title",
                    children: ["store-title"],
                    allowPath: ["/store", "/support", "/support/*", "/about", "/about/*", "/new-user", "/universal/*"]
                }, {
                    id: 21,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group21.png",
                    style: 14,
                    margin: "store-small-special",
                    title: "[21] Section goods * 3",
                    children: ["store-goods", "store-goods", "store-goods"],
                    repeat: ["store-goods"],
                    allowPath: ["/store", "/new-user"]
                }, {
                    id: 22,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group22.png",
                    style: 2,
                    margin: "store-small-special",
                    title: "[22] Section goods * 2",
                    children: ["store-goods", "store-goods"],
                    repeat: ["store-goods"],
                    allowPath: ["/store", "/new-user"]
                }, {
                    id: 23,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group23.png",
                    style: 16,
                    margin: "store-small-special",
                    title: "[23] Section goods * 4",
                    children: ["store-goods", "store-goods", "store-goods", "store-goods"],
                    repeat: ["store-goods"],
                    allowPath: ["/store", "/new-user"]
                }, {
                    id: 24,
                    name: "",
                    enable: 0,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group24.png",
                    style: 1,
                    margin: "store-large-special",
                    title: "[24] Sales from event",
                    children: ["store-week"],
                    allowPath: ["/store"]
                }, {
                    id: 25,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group25.png",
                    style: 1,
                    margin: "store-large",
                    title: "[25] Xiaomi store entrance",
                    children: ["store-shop"],
                    allowPath: ["/store"]
                }, {
                    id: 26,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group26.png",
                    style: 13,
                    margin: "store-medium-special",
                    title: "[26] carriers and partners",
                    children: ["store-carrier", "store-carrier"],
                    allowPath: ["/store"]
                }, {
                    id: 27,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group27.png",
                    style: 2,
                    margin: "large-special",
                    title: "[27] entrance",
                    children: ["entrance", "entrance"],
                    allowPath: ["/store/*"]
                }, {
                    id: 28,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group28.png",
                    style: 1,
                    margin: "small",
                    title: "[28] carrier-product of where to buy",
                    children: ["carrier-product"],
                    allowPath: ["/store/carrier-deals"]
                }, {
                    id: 29,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group29.png",
                    style: 1,
                    margin: "large-special",
                    title: "[29] more-operator of where to buy",
                    children: ["more-operator"],
                    allowPath: ["/store/*"]
                }, {
                    id: 30,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group30.png",
                    style: 1,
                    margin: "small",
                    title: "[30] store-link-bar of where to buy",
                    children: ["store-link-bar"],
                    allowPath: ["/store/*"]
                }, {
                    id: 31,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group31.png",
                    style: 1,
                    margin: "large-special",
                    title: "[31] store-partner of where to buy",
                    children: ["store-partner"],
                    allowPath: ["/store/partner"]
                }, {
                    id: 32,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group32.png",
                    style: 1,
                    margin: "small",
                    title: "[32] store map",
                    children: ["store-map"],
                    allowPath: ["/store/xiaomi-store"]
                }, {
                    id: 33,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group33.png",
                    style: 1,
                    margin: "small",
                    title: "[33] store breadcrumbs",
                    children: ["store-breadcrumbs"],
                    allowPath: ["/store/*"]
                }, {
                    id: 34,
                    name: "",
                    enable: 2,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group34.png",
                    style: 1,
                    margin: "small-top",
                    title: "[34] breadcrumbs",
                    children: ["breadcrumbs"],
                    allowPath: ["/none"]
                }, {
                    id: 35,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group35.png",
                    style: 1,
                    margin: "small",
                    title: "[35] New Product Title",
                    children: ["new-product-title"],
                    allowPath: ["/store/new-products"]
                }, {
                    id: 36,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group36.png",
                    style: 1,
                    margin: "store-large-special",
                    title: "[36] New Product List",
                    children: ["new-product-list"],
                    allowPath: ["/store/new-products"]
                }, {
                    id: 37,
                    name: "",
                    enable: 0,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group37.png",
                    style: 1,
                    margin: "store-large-special",
                    title: "[37] New Product Entrance",
                    children: ["store-new-product"],
                    allowPath: ["/store"]
                }, {
                    id: 38,
                    name: "",
                    enable: 5,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group18.png",
                    style: 1,
                    margin: "store-medium",
                    title: "[38] [APP only] Event fashion entrance",
                    children: ["store-event"],
                    allowPath: ["/store"]
                }, {
                    id: 39,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group08.png",
                    style: 2,
                    margin: "medium-special",
                    title: "[39] Goods without price * 2",
                    children: ["goods-info", "goods-info"],
                    repeat: ["goods-info"],
                    denyPath: ["/store", "/store/*", "/index", "/support", "/support/*", "/about", "/about/*", "/new-user", "/app/index"]
                }, {
                    id: 40,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group15.png",
                    style: 3,
                    margin: "medium",
                    title: "[40] Goods without price * 3",
                    children: ["goods-info", "goods-info", "goods-info"],
                    repeat: ["goods-info"],
                    denyPath: ["/store", "/store/*", "/index", "/support", "/support/*", "/about", "/about/*", "/new-user", "/app/index"]
                }, {
                    id: 41,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group09.png",
                    style: 5,
                    margin: "medium",
                    title: "[41] Goods without price * 4",
                    children: ["goods-info", "goods-info", "goods-info", "goods-info"],
                    repeat: ["goods-info"],
                    minItem: 4,
                    maxItem: 12,
                    denyPath: ["/store", "/store/*", "/index", "/support", "/support/*", "/about", "/about/*", "/new-user", "/app/index"]
                }, {
                    id: 42,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group10.png",
                    style: 5,
                    margin: "medium",
                    title: "[42] Goods without price * 3 w/ more",
                    children: ["goods-info", "goods-info", "goods-info", "text-c"],
                    repeat: ["goods-info"],
                    minItem: 4,
                    maxItem: 12,
                    denyPath: ["/store", "/store/*", "/index", "/support", "/support/*", "/about", "/about/*", "/new-user", "/app/index"]
                }, {
                    id: 43,
                    name: "",
                    enable: 0,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group43.png",
                    style: 1,
                    margin: "store-small-title",
                    title: "[43] Intelligent Goods Recommendation 3 ~ 20",
                    children: ["store-recommends"],
                    allowPath: ["/store", "/new-user"]
                }, {
                    id: 44,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group44.png",
                    style: 1,
                    margin: "none",
                    title: "[44] Static rich text",
                    children: ["rich-text"],
                    allowPath: ["/universal/*", "/event/*", "/categories/*", "/s/*"],
                    useWideEditor: 1e3
                }, {
                    id: 45,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group45.png?v1",
                    style: 1,
                    margin: "none",
                    title: "[45] Blank block",
                    children: ["blank"],
                    allowPath: ["/universal/*", "/support", "/support/*", "/about", "/about/*", "/event/*", "/categories/*", "/s/*"]
                }, {
                    id: 46,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group46.png?v1",
                    style: 1,
                    margin: "support-medium",
                    title: "[46] Support title",
                    children: ["support-title"],
                    allowPath: ["/support", "/support/*", "/about", "/about/*"]
                }, {
                    id: 47,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group47.png?v1",
                    style: 1,
                    margin: "support-medium-special",
                    title: "[47] Small Icon Text",
                    children: ["small-icon-text"],
                    allowPath: ["/support", "/support/*", "/about", "/about/*"]
                }, {
                    id: 48,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group48.png?v1",
                    style: 5,
                    margin: "medium",
                    title: "[48] Phone List",
                    children: ["phone-list", "phone-list", "phone-list", "phone-list", "phone-list", "phone-list"],
                    repeat: ["phone-list"],
                    minItem: 1,
                    maxItem: 999,
                    allowPath: ["/support", "/support/*", "/about", "/about/*"]
                }, {
                    id: 49,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group49.png?v1",
                    style: 1,
                    margin: "support-none",
                    title: "[49] Service Wide Video",
                    children: ["service-video"],
                    allowPath: ["/support", "/support/*", "/about", "/about/*"]
                }, {
                    id: 50,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group50.png?v1",
                    style: 2,
                    margin: "support-medium",
                    title: "[50] Service Share * 2",
                    children: ["service-share", "service-share"],
                    allowPath: ["/support", "/support/*", "/about", "/about/*"]
                }, {
                    id: 51,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group51.png?v1",
                    style: 1,
                    margin: "support-medium",
                    title: "[51] Tab With Rich Text",
                    children: ["tab-with-rich-text"],
                    allowPath: ["/support", "/support/*"],
                    useWideEditor: 1e3
                }, {
                    id: 52,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group52.png?v1",
                    style: 1,
                    margin: "support-medium",
                    title: "[52] Tab With Table",
                    children: ["tab-with-table"],
                    allowPath: ["/support", "/support/*", "/about", "/about/*", "/universal/*"]
                }, {
                    id: 53,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group53.png?v1",
                    style: 1,
                    margin: "store-large",
                    title: "[53] Service Product",
                    children: ["service-product"],
                    allowPath: ["/support", "/support/*"]
                }, {
                    id: 54,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group54.png",
                    style: 1,
                    margin: "support-medium",
                    title: "[54] Accordion",
                    children: ["accordion-block"],
                    allowPath: ["/support", "/support/*"]
                }, {
                    id: 55,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group55.png",
                    style: 1,
                    margin: "store-large",
                    title: "[55] Search",
                    children: ["search"],
                    allowPath: ["/support", "/support/*"]
                }, {
                    id: 56,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group56.png",
                    style: 1,
                    margin: "store-large",
                    title: "[56] Support Small Button",
                    children: ["support-small-btn"],
                    allowPath: ["/support", "/support/*"]
                }, {
                    id: 57,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group57.png?v1",
                    style: 1,
                    margin: "store-small-special",
                    title: "[57] Support Button",
                    children: ["support-button"],
                    allowPath: ["/support", "/support/*", "/universal/*"]
                }, {
                    id: 58,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group58.png?v1",
                    style: 2,
                    margin: "store-small-special",
                    title: "[58] Support Button x 2",
                    children: ["support-button", "support-button"],
                    allowPath: ["/support", "/support/*", "/universal/*"]
                }, {
                    id: 59,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group59.png?v1",
                    style: 16,
                    margin: "store-small-special",
                    title: "[59] Support Button x 4",
                    children: ["support-button", "support-button", "support-button", "support-button"],
                    allowPath: ["/support", "/support/*", "/universal/*"]
                }, {
                    id: 60,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group60.png",
                    style: 2,
                    margin: "store-medium",
                    title: "[60] Support Video x 2",
                    children: ["support-video", "support-video"],
                    allowPath: ["/support", "/support/*"]
                }, {
                    id: 61,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group61.png",
                    style: 1,
                    margin: "store-medium",
                    title: "[61] FAQ list",
                    children: ["height-faq"],
                    allowPath: ["/support", "/support/*", "/universal/*"]
                }, {
                    id: 62,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group62.png",
                    style: 1,
                    margin: "store-small-special",
                    title: "[62] Support Article",
                    children: ["support-article"],
                    allowPath: ["/support", "/support/*"]
                }, {
                    id: 63,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group63.png",
                    style: 1,
                    margin: "store-medium",
                    title: "[63] Contact Us & Terms",
                    children: ["support-contact"],
                    allowPath: ["/support", "/support/*"]
                }, {
                    id: 64,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group64.png",
                    style: 1,
                    margin: "none",
                    title: "[64] Flexible Banner",
                    children: ["banner-flex"],
                    allowPath: ["/support", "/support/*", "/about", "/about/*"]
                }, {
                    id: 65,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group65.png",
                    style: 1,
                    margin: "support-transparent-special",
                    title: "[65] Bubble Switcher",
                    children: ["bubble-switcher"],
                    allowPath: ["/about", "/about/*"],
                    clients: ["Web", "iOS", "Android"]
                }, {
                    id: 66,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group66.png",
                    style: 1,
                    margin: "support-medium",
                    title: "[66] Image Block",
                    children: ["service-background-img"],
                    allowPath: ["/support", "/support/*", "/about", "/about/*"]
                }, {
                    id: 67,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group67.png",
                    style: 1,
                    margin: "support-medium",
                    title: "[67] Image Block w/ Text",
                    children: ["service-background-text"],
                    allowPath: ["/about", "/about/*"]
                }, {
                    id: 68,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group68.png",
                    style: 1,
                    margin: "support-large",
                    title: "[68] Image w/ Description",
                    children: ["image-with-desc"],
                    allowPath: ["/about", "/about/*"]
                }, {
                    id: 69,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group69.png",
                    style: 1,
                    margin: "small-special",
                    title: "[69] Support select menu",
                    children: ["support-select"],
                    allowPath: ["/support", "/support/*"]
                }, {
                    id: 70,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group70.png",
                    style: 1,
                    margin: "none",
                    title: "[70] Support Country Info",
                    children: ["support-country-info"],
                    allowPath: ["/support", "/support/*", "/about", "/about/*"]
                }, {
                    id: 71,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group71.png",
                    style: 1,
                    margin: "support-small",
                    title: "[71] Image Description",
                    children: ["image-description"],
                    allowPath: ["/about", "/about/*"]
                }, {
                    id: 72,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group44.png",
                    style: 1,
                    margin: "support-small",
                    title: "[72] Support rich text",
                    children: ["rich-text"],
                    allowPath: ["/support", "/support/*", "/about", "/about/*"],
                    useWideEditor: 1e3
                }, {
                    id: 73,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group73.png",
                    style: 1,
                    margin: "support-transparent-small",
                    title: "[73] Note",
                    children: ["text-note"],
                    allowPath: ["/support", "/support/*", "/about", "/about/*"]
                }, {
                    id: 74,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group74.png",
                    style: 1,
                    margin: "support-small",
                    title: "[74] Note (White Background)",
                    children: ["text-note"],
                    allowPath: ["/support", "/support/*", "/about", "/about/*"]
                }, {
                    id: 75,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group75.png",
                    style: 1,
                    margin: "small-top",
                    title: "[75] Banner with links",
                    children: ["banner-links"],
                    allowPath: ["/store/daily-picks", "/new-user"]
                }, {
                    id: 76,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group76.png",
                    style: 1,
                    margin: "store-large-special",
                    title: "[76] Daily Picks List",
                    children: ["daily-picks-list"],
                    allowPath: ["/store/daily-picks"]
                }, {
                    id: 77,
                    name: "",
                    enable: 1,
                    imgUrl: "",
                    style: 1,
                    margin: "none-sticky-bottom",
                    title: "[77] SocialShareBar",
                    children: ["social-share-bar"],
                    allowPath: ["/store/daily-picks", "/new-user"]
                }, {
                    id: 78,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group78.png",
                    style: 1,
                    margin: "support-medium",
                    title: "[78] About Years",
                    children: ["about-years"],
                    allowPath: ["/support", "/support/*", "/about", "/about/*"]
                }, {
                    id: 79,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group38.png",
                    style: 1,
                    margin: "small",
                    title: "[79] Process",
                    children: ["process"],
                    allowPath: ["/universal/*", "/new-user"]
                }, {
                    id: 80,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group12.png",
                    style: 1,
                    margin: "store-large",
                    title: "[80] Support Title",
                    children: ["banner-text"],
                    allowPath: ["/support", "/support/*", "/about", "/about/*"]
                }, {
                    id: 81,
                    name: "",
                    enable: 1,
                    imgUrl: "",
                    style: 1,
                    margin: "none",
                    title: "[81] Black and White",
                    children: ["page-gray-scale"],
                    allowPath: ["/index"]
                }, {
                    id: 82,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group79.jpg",
                    style: 1,
                    margin: "store-large-special",
                    title: "[82] Official Intro Steps(store)",
                    children: ["official-intro-steps"],
                    allowPath: ["/store", "/store/*", "/new-user"]
                }, {
                    id: 83,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group79.jpg",
                    style: 1,
                    margin: "large-special",
                    title: "[83] Official Intro Steps(index)",
                    children: ["official-intro-steps"],
                    allowPath: ["/index"]
                }, {
                    id: 84,
                    name: "",
                    enable: 1,
                    imgUrl: "//i02.appmifile.com/929_operatorx_operatorx_xm/04/08/2023/e29b78d870e10d5d514fa079ec6e8da3.jpg",
                    style: 1,
                    margin: "store-small-special",
                    title: "[84] CouponClaim",
                    children: ["coupon-claim"],
                    allowPath: ["/new-user"]
                }, {
                    id: 85,
                    name: "",
                    enable: 1,
                    imgUrl: "//i02.appmifile.com/428_operatorx_operatorx_xm/04/08/2023/8f93022ccd5c905030f678077b618cbd.jpg",
                    style: 1,
                    margin: "none",
                    title: "[85] NewUserModule",
                    children: ["new-user-module"],
                    allowPath: ["/new-user"]
                }, {
                    id: 86,
                    name: "",
                    enable: 1,
                    imgUrl: "//i01.appmifile.com/webfile/globalimg/demo/group-images/group87.png",
                    style: 1,
                    margin: "none",
                    title: "[86] Service Stroe Map",
                    children: ["service-store-map"],
                    allowPath: ["/support", "/support/*"]
                }, {
                    id: 87,
                    name: "",
                    enable: 1,
                    imgUrl: "//cdn.alsgp0.fds.api.mi-img.com/xiaomi-b2c-i18n-upload/i18n/images/demo/block-thumbnail-pop-up.png",
                    style: 1,
                    margin: "none",
                    title: "[87] Store Popup Ads",
                    children: ["store-popup-ads"],
                    allowPath: ["/store/popup-ads"]
                }, {
                    id: 88,
                    name: "",
                    enable: 5,
                    imgUrl: "//cdn.alsgp0.fds.api.mi-img.com/xiaomi-b2c-i18n-upload/i18n/images/demo/block-thumbnail/block-thumbnail-carousel-banner-normal.png",
                    style: 1,
                    margin: "none",
                    title: "[88] Carousel banner-normal",
                    children: ["carousel-banner-normal"],
                    allowPath: ["/app/index"],
                    clients: ["iOS", "Android"]
                }, {
                    id: 89,
                    name: "",
                    enable: 5,
                    imgUrl: "//cdn.alsgp0.fds.api.mi-img.com/xiaomi-b2c-i18n-upload/i18n/images/demo/block-thumbnail/block-thumbnail-carousel-banner-important.png",
                    style: 1,
                    margin: "none",
                    title: "[89] Carousel banner-important",
                    children: ["carousel-banner-important"],
                    allowPath: ["/app/index"],
                    clients: ["iOS", "Android"]
                }, {
                    id: 90,
                    name: "",
                    enable: 5,
                    imgUrl: "//cdn.alsgp0.fds.api.mi-img.com/xiaomi-b2c-i18n-upload/i18n/images/demo/block-thumbnail/block-thumbnail-official-service.png",
                    style: 1,
                    margin: "none",
                    title: "[90] Official Service",
                    children: ["official-service"],
                    allowPath: ["/app/index"],
                    clients: ["iOS", "Android"]
                }, {
                    id: 91,
                    name: "",
                    enable: 5,
                    imgUrl: "//cdn.alsgp0.fds.api.mi-img.com/xiaomi-b2c-i18n-upload/i18n/images/demo/block-thumbnail/block-thumbnail-quick-link.png",
                    style: 1,
                    margin: "none",
                    title: "[91] Quick link",
                    children: ["quick-link"],
                    allowPath: ["/app/index"],
                    clients: ["iOS", "Android"]
                }, {
                    id: 92,
                    name: "",
                    enable: 5,
                    imgUrl: "//cdn.alsgp0.fds.api.mi-img.com/xiaomi-b2c-i18n-upload/i18n/images/demo/block-thumbnail/block-thumbnail-login-guide.png",
                    style: 1,
                    margin: "none",
                    title: "[92] Login Guide",
                    children: ["login-guide"],
                    allowPath: ["/app/index"],
                    clients: ["iOS", "Android"]
                }, {
                    id: 93,
                    name: "",
                    enable: 5,
                    imgUrl: "//cdn.alsgp0.fds.api.mi-img.com/xiaomi-b2c-i18n-upload/i18n/images/demo/block-thumbnail/block-thumbnail-recommended.png",
                    style: 1,
                    margin: "none",
                    title: "[93] Recommended",
                    children: ["recommended"],
                    allowPath: ["/app/index"],
                    clients: ["iOS", "Android"]
                }, {
                    id: 94,
                    name: "",
                    enable: 5,
                    imgUrl: "//cdn.alsgp0.fds.api.mi-img.com/xiaomi-b2c-i18n-upload/i18n/images/demo/block-thumbnail/block-thumbnail-event-page-module.png",
                    style: 1,
                    margin: "none",
                    title: "[94] Event Page Module",
                    children: ["event-page-module"],
                    allowPath: ["/app/index"],
                    clients: ["iOS", "Android"]
                }, {
                    id: 95,
                    name: "",
                    enable: 5,
                    imgUrl: "//cdn.alsgp0.fds.api.mi-img.com/xiaomi-b2c-i18n-upload/i18n/images/demo/block-thumbnail/block-thumbnail-dailypicks-app.png",
                    style: 1,
                    margin: "none",
                    title: "[95] Daily Picks-App",
                    children: ["daily-picks-app"],
                    allowPath: ["/app/index"],
                    clients: ["iOS", "Android"]
                }, {
                    id: 96,
                    name: "",
                    enable: 5,
                    imgUrl: "//cdn.alsgp0.fds.api.mi-img.com/xiaomi-b2c-i18n-upload/i18n/images/demo/block-thumbnail/block-thumbnail-banner-h364.png",
                    style: 1,
                    margin: "none",
                    title: "[96] Banner-H364",
                    children: ["banner-h364"],
                    allowPath: ["/app/index"],
                    clients: ["iOS", "Android"]
                }, {
                    id: 97,
                    name: "",
                    enable: 5,
                    imgUrl: "//cdn.alsgp0.fds.api.mi-img.com/xiaomi-b2c-i18n-upload/i18n/images/demo/block-thumbnail/block-thumbnail-new-product-app.png",
                    style: 1,
                    margin: "none",
                    title: "[97] New Product-App",
                    children: ["new-product-app"],
                    allowPath: ["/app/index"],
                    clients: ["iOS", "Android"]
                }, {
                    id: 98,
                    name: "support-web-home",
                    enable: 1,
                    imgUrl: "https://i02.appmifile.com/876_operatorx_operatorx_xm/17/08/2023/d2db0ae7aa5579b9414f95a458e10225.jpeg",
                    style: 1,
                    margin: "vertical-100",
                    title: "[98] Support Web Home",
                    children: ["support-web-home"],
                    allowPath: ["/web/index", "/index"]
                }, {
                    id: 99,
                    name: "explore-xiaomi",
                    enable: 1,
                    imgUrl: "https://i02.appmifile.com/467_operatorx_operatorx_xm/17/08/2023/4d3cc41422ff27fd675adbc7068f1289.jpeg",
                    style: 1,
                    margin: "none",
                    title: "[99] Explore Xiaomi",
                    children: ["explore-xiaomi"],
                    allowPath: ["/web/index", "/index"]
                }, {
                    id: 100,
                    name: "exclusive-offers",
                    enable: 1,
                    imgUrl: "//cdn.alsgp0.fds.api.mi-img.com/xiaomi-b2c-i18n-upload/i18n/images/demo/block-thumbnail/block-thumbnail-exclusive-offers.png",
                    style: 1,
                    margin: "vertical-100",
                    title: "[100] Exclusive Offers",
                    children: ["exclusive-offers"],
                    allowPath: ["/web/index", "/index"]
                }, {
                    id: 101,
                    name: "ribbon-ads",
                    enable: 1,
                    imgUrl: "//cdn.alsgp0.fds.api.mi-img.com/xiaomi-b2c-i18n-upload/i18n/images/demo/block-thumbnail/block-thumbnail-ribbon-ads.png",
                    style: 1,
                    margin: "next-no-margin-top",
                    title: "[101] Ribbon Ads",
                    children: ["ribbon-ads"],
                    allowPath: ["/web/index", "/index"]
                }, {
                    id: 102,
                    name: "carousel-banner",
                    enable: 1,
                    imgUrl: "https://cdn.alsgp0.fds.api.mi-img.com/xiaomi-b2c-i18n-upload/i18n/images/demo/block-thumbnail/block-thumbnail-carousel-banner.png",
                    style: 1,
                    margin: "small-top",
                    title: "[102] Carousel Banner",
                    children: ["carousel-banner"],
                    allowPath: ["/index", "/web/index", "/store"]
                }, {
                    id: 103,
                    name: "featured-tabs",
                    enable: 1,
                    imgUrl: "https://alsgp0.fds.api.xiaomi.com/xiaomi-b2c-i18n-upload/i18n/images/demo/feature-tabs.png",
                    style: 1,
                    margin: "vertical-100",
                    title: "[103] FeaturedTabs",
                    children: ["featured-tabs"],
                    allowPath: ["/web/index", "/index"]
                }, {
                    id: 104,
                    name: "",
                    enable: 1,
                    imgUrl: "https://alsgp0.fds.api.xiaomi.com/xiaomi-b2c-i18n-upload/i18n/images/demo/trade-in-sku.png",
                    style: 1,
                    margin: "store-large",
                    title: "[104] TradeInSku",
                    children: ["trade-in-sku"],
                    denyPath: ["/app/index"]
                }, {
                    id: 105,
                    name: "",
                    enable: 1,
                    imgUrl: "",
                    style: 1,
                    margin: "small",
                    title: "[105] Header Footer",
                    children: ["header-footer"],
                    allowPath: ["public/header-footer"],
                    clients: ["Web"]
                }, {
                    name: "",
                    id: 106,
                    enable: 1,
                    style: 1,
                    margin: "none",
                    title: "[106] MultipleSpu",
                    children: ["multiple-spu"],
                    allowPath: ["/app/index"],
                    imgUrl: "https://cdn.alsgp0.fds.api.mi-img.com/xiaomi-b2c-i18n-upload/i18n/images/demo/block-thumbnail/block-thumbnail-multiple-spu.png",
                    clients: ["iOS", "Android"]
                }, {
                    name: "",
                    id: 107,
                    enable: 1,
                    imgUrl: "https://cdn.alsgp0.fds.api.mi-img.com/xiaomi-b2c-i18n-upload/i18n/images/demo/block-thumbnail/block-thumbnail-spu-custom.png",
                    style: 1,
                    margin: "none",
                    title: "[107] SpuCustom",
                    children: ["spu-custom"],
                    allowPath: ["/app/index"],
                    clients: ["iOS", "Android"]
                }, {
                    name: "",
                    id: 108,
                    enable: 1,
                    imgUrl: "https://i02.appmifile.com/457_operatorx_operatorx_xm/22/09/2023/be64bf02dd267773dfa36f186b18374a.jpeg",
                    style: 1,
                    margin: "support-medium",
                    title: "[108] MultiColumnTable",
                    children: ["multi-column-table"],
                    allowPath: ["/support", "/universal/*"]
                }, {
                    name: "",
                    id: 109,
                    enable: 1,
                    imgUrl: "https://i02.appmifile.com/946_operatorx_operatorx_xm/28/09/2023/302ac88a55ac63299011b7b3fa1434e2.jpeg",
                    style: 1,
                    margin: "none",
                    title: "[108] Feedback",
                    children: ["feedback"],
                    allowPath: ["/support", "/support/*"]
                }],
                n = l(27930);

            function m(e) {
                return void 0 === e && (e = []), Array.from(e).map((function(e) {
                    return {
                        index: Number(e.index || -1),
                        content: String(e.content || "")
                    }
                })).filter((function(e) {
                    return e.index > 0 && !!e.content
                }))
            }
            var p, g, s = l(26644),
                u = l(67279),
                d = l(7894),
                c = [1, 2, 6, 7],
                b = [0, 1, 2, 6, 7],
                h = [0, 1, 3, 5, 7],
                f = [0, 1, 4, 5, 6],
                w = function(e, i) {
                    var l = "function" == typeof Symbol && e[Symbol.iterator];
                    if (!l) return e;
                    var o, a, t = l.call(e),
                        r = [];
                    try {
                        for (;
                            (void 0 === i || i-- > 0) && !(o = t.next()).done;) r.push(o.value)
                    } catch (n) {
                        a = {
                            error: n
                        }
                    } finally {
                        try {
                            o && !o.done && (l = t.return) && l.call(t)
                        } finally {
                            if (a) throw a.error
                        }
                    }
                    return r
                };
            var y = {
                    data: (null === (p = window.__PRELOADED_STATE__) || void 0 === p ? void 0 : p.pagedata) || {},
                    ajaxStatus: (null === (g = window.__PRELOADED_STATE__) || void 0 === g ? void 0 : g.pagedata) ? "success" : "unsent",
                    getServiceSuccess: !1
                },
                x = (0, a.o)(U, y),
                P = (0, o.createContext)(x);

            function v(e) {
                var i = e.siteConfig,
                    l = e.isAutoFetch,
                    a = e.children,
                    r = w((0, o.useState)(x), 2),
                    m = r[0],
                    p = r[1];

                function g(e) {
                    var i = e.data,
                        l = e.errmsg,
                        o = e.errno;
                    return {
                        data: U(i || {}, !0),
                        errMsg: String(l),
                        errNo: Number(o)
                    }
                }
                var s = Number((0, n.W)("publishId") || 0),
                    u = {
                        url: "".concat(i.goSite, "/v2/cms/page/get"),
                        method: "GET",
                        basicParams: Object.assign({
                            from: "web",
                            cacheable: 1
                        }, s ? {
                            publishId: s
                        } : {}),
                        withCredentials: !0,
                        retryOptions: {
                            maxRetryAttempts: 2,
                            scalingDuration: 2500
                        }
                    };
                return o.createElement(t.h, {
                    context: P,
                    setState: p,
                    defaultValue: x,
                    adapterError: function(e) {
                        return g(Object.assign({}, e, {
                            data: y.data,
                            errmsg: "",
                            errno: 0
                        }))
                    },
                    adapter: g,
                    value: m,
                    siteConfig: i,
                    isAutoFetch: !0 === l,
                    ajaxConfig: u
                }, a)
            }

            function U(e, i) {
                var l, o, a, t;
                return void 0 === e && (e = {}), {
                    pageInfo: S(e.pageInfo || {}),
                    layouts: A(e.layouts || [], !i),
                    seo: k(e.seo || {}),
                    footnote: m((null === (t = JSON.parse((null === (a = null === (o = null === (l = Array.from(e.layouts || []).find((function(e) {
                        var i, l;
                        return "footnote" === (null === (l = null === (i = null == e ? void 0 : e.children) || void 0 === i ? void 0 : i[0]) || void 0 === l ? void 0 : l.name)
                    }))) || void 0 === l ? void 0 : l.children) || void 0 === o ? void 0 : o[0]) || void 0 === a ? void 0 : a.extstr) || "[]")) || void 0 === t ? void 0 : t.data) || [])
                }
            }

            function k(e) {
                return void 0 === e && (e = {}), {
                    title: String(e.title || ""),
                    headings: String(e.headings || "")
                }
            }

            function S(e) {
                return void 0 === e && (e = {}), {
                    pageId: Number(e.pageId || 0),
                    treeId: Number(e.treeId || 0),
                    path: String(e.path || "index"),
                    clients: e.clients || []
                }
            }

            function A(e, i) {
                return void 0 === e && (e = []), Array.from(e || []).map((function(e) {
                    return function(e) {
                        void 0 === e && (e = {});
                        return {
                            id: Number(e.id || 0),
                            name: String(e.name || _(e)),
                            margin: e.margin || "small",
                            style: Number(e.style || 1),
                            enable: Number(e.enable || 0),
                            children: I(e.children || []),
                            groupId: Number(e.groupId || 0),
                            layoutConfig: e.layoutConfig || {}
                        }
                    }(e)
                })).filter((function(e) {
                    var l, o;
                    if ("footnote" === (null === (o = null === (l = e.children) || void 0 === l ? void 0 : l[0]) || void 0 === o ? void 0 : o.name)) return !1;
                    var a = (0, s.uZ)(),
                        t = (0, s.j1)();
                    return a ? h.includes(e.enable) : t ? f.includes(e.enable) : i ? c.includes(e.enable) : b.includes(e.enable)
                }))
            }

            function _(e) {
                void 0 === e && (e = {});
                var i = r.map((function(e) {
                        return {
                            name: e.name,
                            margin: e.margin,
                            groupId: e.id,
                            blocks: e.children
                        }
                    })),
                    l = e.children.map((function(e) {
                        return e.name
                    })).slice(0, 4);
                return (i.filter((function(i) {
                    return 0 !== Number(e.groupId || 0) ? e.groupId === i.groupId : i.blocks.slice(0, 4).join(",") === l.join(",") && i.margin === e.margin
                }))[0] || {
                    name: ""
                }).name
            }

            function I(e) {
                return void 0 === e && (e = []), Array.from(e || []).map((function(e) {
                    return function(e) {
                        void 0 === e && (e = {});
                        return {
                            id: Number(e.id || 0),
                            name: e.name || "",
                            style: Number(e.style || 1),
                            title: e.title || "",
                            subtitle: (e.subtitle || "").replace(/<br(\/)?>/gi, "\n"),
                            tips: e.tips || "",
                            theme: e.theme || "light",
                            hashtags: Array.from(e.hashtags || []).map((function(e) {
                                return String(e || "")
                            })).filter((function(e) {
                                return !!e
                            })),
                            slides: I(e.slides || []),
                            siftList: E(e.siftList || []),
                            goods: T(e.goods || []),
                            images: C(e.images || []),
                            buttons: j(e.buttons || []),
                            extends: JSON.parse(e.extstr || "{}"),
                            videos: W(e.videos || []),
                            type: e.type,
                            playIcon: e.playIcon || !1,
                            showType: e.showType || "page",
                            visibleGroups: O(e.visibleGroups || {}),
                            timer: e.timer
                        }
                    }(e)
                }))
            }

            function O(e) {
                return void 0 === e && (e = {}), {
                    group_type: String(e.group_type || "all"),
                    groups: N(e.groups || [])
                }
            }

            function N(e) {
                return void 0 === e && (e = []), Array.from(e || []).map((function(e) {
                    return {
                        tag: e.tag
                    }
                }))
            }

            function E(e) {
                return void 0 === e && (e = []), Array.from(e || []).map((function(e) {
                    return {
                        title: e.title || "",
                        path: e.path || "",
                        children: E(e.children || [])
                    }
                }))
            }

            function T(e) {
                return void 0 === e && (e = []), Array.from(e || []).map((function(e) {
                    return function(e) {
                        void 0 === e && (e = {});
                        return {
                            spuId: String(e.spuId || ""),
                            productId: Number(e.productId || 0),
                            name: e.name || "",
                            imgUrl: (e.imgUrl || "").replace(/^(http(s)?:)?\/\//, "//"),
                            gotoUrl: (e.gotoUrl || "").replace(/^(http(s)?:)?\/\//, "//"),
                            originPrice: Number(e.originPrice) || Number(e.salePrice),
                            originPriceText: String(e.originPriceText) || String(e.salePriceText),
                            salePrice: Number(e.salePrice),
                            salePriceText: String(e.salePriceText),
                            salePriceIsEQ: !!e.salePriceIsEQ,
                            isSale: !1 !== e.isSale,
                            isOutOfStock: !!e.isOutOfStock,
                            tags: B(e.tags || []),
                            energyInfo: (0, u.T)(e.energy || []),
                            marketingInfo: (0, d.p)(e.marketing_tags || [])
                        }
                    }(e)
                }))
            }

            function B(e) {
                return void 0 === e && (e = []), Array.from(e || []).map((function(e) {
                    return {
                        text: String(e.text || ""),
                        type: String(e.type || "")
                    }
                }))
            }

            function C(e) {
                return void 0 === e && (e = []), Array.from(e || []).map((function(e) {
                    return function(e) {
                        void 0 === e && (e = {});
                        return {
                            src: D(e.src || {}),
                            alt: e.alt || ""
                        }
                    }(e)
                }))
            }

            function D(e) {
                return void 0 === e && (e = {}), {
                    widescreen: (e.widescreen || "").replace(/^(http(s)?:)?\/\//, "//"),
                    desktop: (e.desktop || "").replace(/^(http(s)?:)?\/\//, "//"),
                    laptop: (e.laptop || "").replace(/^(http(s)?:)?\/\//, "//"),
                    tablet: (e.tablet || "").replace(/^(http(s)?:)?\/\//, "//"),
                    mobile: (e.mobile || "").replace(/^(http(s)?:)?\/\//, "//")
                }
            }

            function j(e) {
                return void 0 === e && (e = []), Array.from(e || []).map((function(e) {
                    return {
                        text: e.text || "",
                        gotoUrl: e.gotoUrl || ""
                    }
                }))
            }

            function W(e) {
                return void 0 === e && (e = []), Array.from(e || []).map((function(e) {
                    return {
                        url: String(e.url || ""),
                        mUrl: String(e.mUrl || "")
                    }
                }))
            }
        }
    }
]);