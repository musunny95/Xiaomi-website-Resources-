(self.__LOADABLE_LOADED_CHUNKS__ = self.__LOADABLE_LOADED_CHUNKS__ || []).push([
    [1470], {
        10285: function(e) {
            e.exports = function() {
                "use strict";
                var e = {
                        LTS: "h:mm:ss A",
                        LT: "h:mm A",
                        L: "MM/DD/YYYY",
                        LL: "MMMM D, YYYY",
                        LLL: "MMMM D, YYYY h:mm A",
                        LLLL: "dddd, MMMM D, YYYY h:mm A"
                    },
                    t = /(\[[^[]*\])|([-_:/.,()\s]+)|(A|a|YYYY|YY?|MM?M?M?|Do|DD?|hh?|HH?|mm?|ss?|S{1,3}|z|ZZ?)/g,
                    n = /\d\d/,
                    a = /\d\d?/,
                    r = /\d*[^-_:/,()\s\d]+/,
                    i = {},
                    s = function(e) {
                        return (e = +e) + (e > 68 ? 1900 : 2e3)
                    },
                    o = function(e) {
                        return function(t) {
                            this[e] = +t
                        }
                    },
                    l = [/[+-]\d\d:?(\d\d)?|Z/, function(e) {
                        (this.zone || (this.zone = {})).offset = function(e) {
                            if (!e) return 0;
                            if ("Z" === e) return 0;
                            var t = e.match(/([+-]|\d\d)/g),
                                n = 60 * t[1] + (+t[2] || 0);
                            return 0 === n ? 0 : "+" === t[0] ? -n : n
                        }(e)
                    }],
                    u = function(e) {
                        var t = i[e];
                        return t && (t.indexOf ? t : t.s.concat(t.f))
                    },
                    f = function(e, t) {
                        var n, a = i.meridiem;
                        if (a) {
                            for (var r = 1; r <= 24; r += 1)
                                if (e.indexOf(a(r, 0, t)) > -1) {
                                    n = r > 12;
                                    break
                                }
                        } else n = e === (t ? "pm" : "PM");
                        return n
                    },
                    d = {
                        A: [r, function(e) {
                            this.afternoon = f(e, !1)
                        }],
                        a: [r, function(e) {
                            this.afternoon = f(e, !0)
                        }],
                        S: [/\d/, function(e) {
                            this.milliseconds = 100 * +e
                        }],
                        SS: [n, function(e) {
                            this.milliseconds = 10 * +e
                        }],
                        SSS: [/\d{3}/, function(e) {
                            this.milliseconds = +e
                        }],
                        s: [a, o("seconds")],
                        ss: [a, o("seconds")],
                        m: [a, o("minutes")],
                        mm: [a, o("minutes")],
                        H: [a, o("hours")],
                        h: [a, o("hours")],
                        HH: [a, o("hours")],
                        hh: [a, o("hours")],
                        D: [a, o("day")],
                        DD: [n, o("day")],
                        Do: [r, function(e) {
                            var t = i.ordinal,
                                n = e.match(/\d+/);
                            if (this.day = n[0], t)
                                for (var a = 1; a <= 31; a += 1) t(a).replace(/\[|\]/g, "") === e && (this.day = a)
                        }],
                        M: [a, o("month")],
                        MM: [n, o("month")],
                        MMM: [r, function(e) {
                            var t = u("months"),
                                n = (u("monthsShort") || t.map((function(e) {
                                    return e.slice(0, 3)
                                }))).indexOf(e) + 1;
                            if (n < 1) throw new Error;
                            this.month = n % 12 || n
                        }],
                        MMMM: [r, function(e) {
                            var t = u("months").indexOf(e) + 1;
                            if (t < 1) throw new Error;
                            this.month = t % 12 || t
                        }],
                        Y: [/[+-]?\d+/, o("year")],
                        YY: [n, function(e) {
                            this.year = s(e)
                        }],
                        YYYY: [/\d{4}/, o("year")],
                        Z: l,
                        ZZ: l
                    };

                function h(n) {
                    var a, r;
                    a = n, r = i && i.formats;
                    for (var s = (n = a.replace(/(\[[^\]]+])|(LTS?|l{1,4}|L{1,4})/g, (function(t, n, a) {
                            var i = a && a.toUpperCase();
                            return n || r[a] || e[a] || r[i].replace(/(\[[^\]]+])|(MMMM|MM|DD|dddd)/g, (function(e, t, n) {
                                return t || n.slice(1)
                            }))
                        }))).match(t), o = s.length, l = 0; l < o; l += 1) {
                        var u = s[l],
                            f = d[u],
                            h = f && f[0],
                            c = f && f[1];
                        s[l] = c ? {
                            regex: h,
                            parser: c
                        } : u.replace(/^\[|\]$/g, "")
                    }
                    return function(e) {
                        for (var t = {}, n = 0, a = 0; n < o; n += 1) {
                            var r = s[n];
                            if ("string" == typeof r) a += r.length;
                            else {
                                var i = r.regex,
                                    l = r.parser,
                                    u = e.slice(a),
                                    f = i.exec(u)[0];
                                l.call(t, f), e = e.replace(f, "")
                            }
                        }
                        return function(e) {
                            var t = e.afternoon;
                            if (void 0 !== t) {
                                var n = e.hours;
                                t ? n < 12 && (e.hours += 12) : 12 === n && (e.hours = 0), delete e.afternoon
                            }
                        }(t), t
                    }
                }
                return function(e, t, n) {
                    n.p.customParseFormat = !0, e && e.parseTwoDigitYear && (s = e.parseTwoDigitYear);
                    var a = t.prototype,
                        r = a.parse;
                    a.parse = function(e) {
                        var t = e.date,
                            a = e.utc,
                            s = e.args;
                        this.$u = a;
                        var o = s[1];
                        if ("string" == typeof o) {
                            var l = !0 === s[2],
                                u = !0 === s[3],
                                f = l || u,
                                d = s[2];
                            u && (d = s[2]), i = this.$locale(), !l && d && (i = n.Ls[d]), this.$d = function(e, t, n) {
                                try {
                                    if (["x", "X"].indexOf(t) > -1) return new Date(("X" === t ? 1e3 : 1) * e);
                                    var a = h(t)(e),
                                        r = a.year,
                                        i = a.month,
                                        s = a.day,
                                        o = a.hours,
                                        l = a.minutes,
                                        u = a.seconds,
                                        f = a.milliseconds,
                                        d = a.zone,
                                        c = new Date,
                                        m = s || (r || i ? 1 : c.getDate()),
                                        p = r || c.getFullYear(),
                                        v = 0;
                                    r && !i || (v = i > 0 ? i - 1 : c.getMonth());
                                    var g = o || 0,
                                        w = l || 0,
                                        M = u || 0,
                                        y = f || 0;
                                    return d ? new Date(Date.UTC(p, v, m, g, w, M, y + 60 * d.offset * 1e3)) : n ? new Date(Date.UTC(p, v, m, g, w, M, y)) : new Date(p, v, m, g, w, M, y)
                                } catch (e) {
                                    return new Date("")
                                }
                            }(t, o, a), this.init(), d && !0 !== d && (this.$L = this.locale(d).$L), f && t != this.format(o) && (this.$d = new Date("")), i = {}
                        } else if (o instanceof Array)
                            for (var c = o.length, m = 1; m <= c; m += 1) {
                                s[1] = o[m - 1];
                                var p = n.apply(this, s);
                                if (p.isValid()) {
                                    this.$d = p.$d, this.$L = p.$L, this.init();
                                    break
                                }
                                m === c && (this.$d = new Date(""))
                            } else r.call(this, e)
                    }
                }
            }()
        },
        7124: function(e) {
            e.exports = function() {
                "use strict";
                return function(e, t, n) {
                    t.prototype.isToday = function() {
                        var e = "YYYY-MM-DD",
                            t = n();
                        return this.format(e) === t.format(e)
                    }
                }
            }()
        },
        49133: function(e) {
            e.exports = function() {
                "use strict";
                return function(e, t, n) {
                    t.prototype.isTomorrow = function() {
                        var e = "YYYY-MM-DD",
                            t = n().add(1, "day");
                        return this.format(e) === t.format(e)
                    }
                }
            }()
        },
        29387: function(e) {
            e.exports = function() {
                "use strict";
                var e = {
                        year: 0,
                        month: 1,
                        day: 2,
                        hour: 3,
                        minute: 4,
                        second: 5
                    },
                    t = {};
                return function(n, a, r) {
                    var i, s = function(e, n, a) {
                            void 0 === a && (a = {});
                            var r = new Date(e),
                                i = function(e, n) {
                                    void 0 === n && (n = {});
                                    var a = n.timeZoneName || "short",
                                        r = e + "|" + a,
                                        i = t[r];
                                    return i || (i = new Intl.DateTimeFormat("en-US", {
                                        hour12: !1,
                                        timeZone: e,
                                        year: "numeric",
                                        month: "2-digit",
                                        day: "2-digit",
                                        hour: "2-digit",
                                        minute: "2-digit",
                                        second: "2-digit",
                                        timeZoneName: a
                                    }), t[r] = i), i
                                }(n, a);
                            return i.formatToParts(r)
                        },
                        o = function(t, n) {
                            for (var a = s(t, n), i = [], o = 0; o < a.length; o += 1) {
                                var l = a[o],
                                    u = l.type,
                                    f = l.value,
                                    d = e[u];
                                d >= 0 && (i[d] = parseInt(f, 10))
                            }
                            var h = i[3],
                                c = 24 === h ? 0 : h,
                                m = i[0] + "-" + i[1] + "-" + i[2] + " " + c + ":" + i[4] + ":" + i[5] + ":000",
                                p = +t;
                            return (r.utc(m).valueOf() - (p -= p % 1e3)) / 6e4
                        },
                        l = a.prototype;
                    l.tz = function(e, t) {
                        void 0 === e && (e = i);
                        var n = this.utcOffset(),
                            a = this.toDate(),
                            s = a.toLocaleString("en-US", {
                                timeZone: e
                            }),
                            o = Math.round((a - new Date(s)) / 1e3 / 60),
                            l = r(s).$set("millisecond", this.$ms).utcOffset(15 * -Math.round(a.getTimezoneOffset() / 15) - o, !0);
                        if (t) {
                            var u = l.utcOffset();
                            l = l.add(n - u, "minute")
                        }
                        return l.$x.$timezone = e, l
                    }, l.offsetName = function(e) {
                        var t = this.$x.$timezone || r.tz.guess(),
                            n = s(this.valueOf(), t, {
                                timeZoneName: e
                            }).find((function(e) {
                                return "timezonename" === e.type.toLowerCase()
                            }));
                        return n && n.value
                    };
                    var u = l.startOf;
                    l.startOf = function(e, t) {
                        if (!this.$x || !this.$x.$timezone) return u.call(this, e, t);
                        var n = r(this.format("YYYY-MM-DD HH:mm:ss:SSS"));
                        return u.call(n, e, t).tz(this.$x.$timezone, !0)
                    }, r.tz = function(e, t, n) {
                        var a = n && t,
                            s = n || t || i,
                            l = o(+r(), s);
                        if ("string" != typeof e) return r(e).tz(s);
                        var u = function(e, t, n) {
                                var a = e - 60 * t * 1e3,
                                    r = o(a, n);
                                if (t === r) return [a, t];
                                var i = o(a -= 60 * (r - t) * 1e3, n);
                                return r === i ? [a, r] : [e - 60 * Math.min(r, i) * 1e3, Math.max(r, i)]
                            }(r.utc(e, a).valueOf(), l, s),
                            f = u[0],
                            d = u[1],
                            h = r(f).utcOffset(d);
                        return h.$x.$timezone = s, h
                    }, r.tz.guess = function() {
                        return Intl.DateTimeFormat().resolvedOptions().timeZone
                    }, r.tz.setDefault = function(e) {
                        i = e
                    }
                }
            }()
        },
        70178: function(e) {
            e.exports = function() {
                "use strict";
                var e = "minute",
                    t = /[+-]\d\d(?::?\d\d)?/g,
                    n = /([+-]|\d\d)/g;
                return function(a, r, i) {
                    var s = r.prototype;
                    i.utc = function(e) {
                        return new r({
                            date: e,
                            utc: !0,
                            args: arguments
                        })
                    }, s.utc = function(t) {
                        var n = i(this.toDate(), {
                            locale: this.$L,
                            utc: !0
                        });
                        return t ? n.add(this.utcOffset(), e) : n
                    }, s.local = function() {
                        return i(this.toDate(), {
                            locale: this.$L,
                            utc: !1
                        })
                    };
                    var o = s.parse;
                    s.parse = function(e) {
                        e.utc && (this.$u = !0), this.$utils().u(e.$offset) || (this.$offset = e.$offset), o.call(this, e)
                    };
                    var l = s.init;
                    s.init = function() {
                        if (this.$u) {
                            var e = this.$d;
                            this.$y = e.getUTCFullYear(), this.$M = e.getUTCMonth(), this.$D = e.getUTCDate(), this.$W = e.getUTCDay(), this.$H = e.getUTCHours(), this.$m = e.getUTCMinutes(), this.$s = e.getUTCSeconds(), this.$ms = e.getUTCMilliseconds()
                        } else l.call(this)
                    };
                    var u = s.utcOffset;
                    s.utcOffset = function(a, r) {
                        var i = this.$utils().u;
                        if (i(a)) return this.$u ? 0 : i(this.$offset) ? u.call(this) : this.$offset;
                        if ("string" == typeof a && (a = function(e) {
                                void 0 === e && (e = "");
                                var a = e.match(t);
                                if (!a) return null;
                                var r = ("" + a[0]).match(n) || ["-", 0, 0],
                                    i = r[0],
                                    s = 60 * +r[1] + +r[2];
                                return 0 === s ? 0 : "+" === i ? s : -s
                            }(a), null === a)) return this;
                        var s = Math.abs(a) <= 16 ? 60 * a : a,
                            o = this;
                        if (r) return o.$offset = s, o.$u = 0 === a, o;
                        if (0 !== a) {
                            var l = this.$u ? this.toDate().getTimezoneOffset() : -1 * this.utcOffset();
                            (o = this.local().add(s + l, e)).$offset = s, o.$x.$localOffset = l
                        } else o = this.utc();
                        return o
                    };
                    var f = s.format;
                    s.format = function(e) {
                        var t = e || (this.$u ? "YYYY-MM-DDTHH:mm:ss[Z]" : "");
                        return f.call(this, t)
                    }, s.valueOf = function() {
                        var e = this.$utils().u(this.$offset) ? 0 : this.$offset + (this.$x.$localOffset || this.$d.getTimezoneOffset());
                        return this.$d.valueOf() - 6e4 * e
                    }, s.isUTC = function() {
                        return !!this.$u
                    }, s.toISOString = function() {
                        return this.toDate().toISOString()
                    }, s.toString = function() {
                        return this.toDate().toUTCString()
                    };
                    var d = s.toDate;
                    s.toDate = function(e) {
                        return "s" === e && this.$offset ? i(this.format("YYYY-MM-DD HH:mm:ss:SSS")).toDate() : d.call(this)
                    };
                    var h = s.diff;
                    s.diff = function(e, t, n) {
                        if (e && this.$u === e.$u) return h.call(this, e, t, n);
                        var a = this.local(),
                            r = i(e).local();
                        return h.call(a, r, t, n)
                    }
                }
            }()
        },
        86584: (e, t, n) => {
            "use strict";
            n.d(t, {
                Z: () => s
            });
            var a = n(28262);

            function r() {
                return r = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var a in n) Object.prototype.hasOwnProperty.call(n, a) && (e[a] = n[a])
                    }
                    return e
                }, r.apply(this, arguments)
            }
            var i = {
                setTranslate: function() {
                    for (var e = this, t = e.slides, n = 0; n < t.length; n += 1) {
                        var a = e.slides.eq(n),
                            r = -a[0].swiperSlideOffset;
                        e.params.virtualTranslate || (r -= e.translate);
                        var i = 0;
                        e.isHorizontal() || (i = r, r = 0);
                        var s = e.params.fadeEffect.crossFade ? Math.max(1 - Math.abs(a[0].progress), 0) : 1 + Math.min(Math.max(a[0].progress, -1), 0);
                        a.css({
                            opacity: s
                        }).transform("translate3d(" + r + "px, " + i + "px, 0px)")
                    }
                },
                setTransition: function(e) {
                    var t = this,
                        n = t.slides,
                        a = t.$wrapperEl;
                    if (n.transition(e), t.params.virtualTranslate && 0 !== e) {
                        var r = !1;
                        n.transitionEnd((function() {
                            if (!r && t && !t.destroyed) {
                                r = !0, t.animating = !1;
                                for (var e = ["webkitTransitionEnd", "transitionend"], n = 0; n < e.length; n += 1) a.trigger(e[n])
                            }
                        }))
                    }
                }
            };
            const s = {
                name: "effect-fade",
                params: {
                    fadeEffect: {
                        crossFade: !1
                    }
                },
                create: function() {
                    (0, a.cR)(this, {
                        fadeEffect: r({}, i)
                    })
                },
                on: {
                    beforeInit: function(e) {
                        if ("fade" === e.params.effect) {
                            e.classNames.push(e.params.containerModifierClass + "fade");
                            var t = {
                                slidesPerView: 1,
                                slidesPerColumn: 1,
                                slidesPerGroup: 1,
                                watchSlidesProgress: !0,
                                spaceBetween: 0,
                                virtualTranslate: !0
                            };
                            (0, a.l7)(e.params, t), (0, a.l7)(e.originalParams, t)
                        }
                    },
                    setTranslate: function(e) {
                        "fade" === e.params.effect && e.fadeEffect.setTranslate()
                    },
                    setTransition: function(e, t) {
                        "fade" === e.params.effect && e.fadeEffect.setTransition(t)
                    }
                }
            }
        },
        40024: (e, t, n) => {
            "use strict";
            n.d(t, {
                Z: () => l
            });
            var a = n(6156),
                r = n(7513),
                i = n(28262);

            function s() {
                return s = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var a in n) Object.prototype.hasOwnProperty.call(n, a) && (e[a] = n[a])
                    }
                    return e
                }, s.apply(this, arguments)
            }
            var o = {
                handle: function(e) {
                    var t = this;
                    if (t.enabled) {
                        var n = (0, a.Jj)(),
                            r = (0, a.Me)(),
                            i = t.rtlTranslate,
                            s = e;
                        s.originalEvent && (s = s.originalEvent);
                        var o = s.keyCode || s.charCode,
                            l = t.params.keyboard.pageUpDown,
                            u = l && 33 === o,
                            f = l && 34 === o,
                            d = 37 === o,
                            h = 39 === o,
                            c = 38 === o,
                            m = 40 === o;
                        if (!t.allowSlideNext && (t.isHorizontal() && h || t.isVertical() && m || f)) return !1;
                        if (!t.allowSlidePrev && (t.isHorizontal() && d || t.isVertical() && c || u)) return !1;
                        if (!(s.shiftKey || s.altKey || s.ctrlKey || s.metaKey || r.activeElement && r.activeElement.nodeName && ("input" === r.activeElement.nodeName.toLowerCase() || "textarea" === r.activeElement.nodeName.toLowerCase()))) {
                            if (t.params.keyboard.onlyInViewport && (u || f || d || h || c || m)) {
                                var p = !1;
                                if (t.$el.parents("." + t.params.slideClass).length > 0 && 0 === t.$el.parents("." + t.params.slideActiveClass).length) return;
                                var v = t.$el,
                                    g = v[0].clientWidth,
                                    w = v[0].clientHeight,
                                    M = n.innerWidth,
                                    y = n.innerHeight,
                                    D = t.$el.offset();
                                i && (D.left -= t.$el[0].scrollLeft);
                                for (var T = [
                                        [D.left, D.top],
                                        [D.left + g, D.top],
                                        [D.left, D.top + w],
                                        [D.left + g, D.top + w]
                                    ], b = 0; b < T.length; b += 1) {
                                    var $ = T[b];
                                    if ($[0] >= 0 && $[0] <= M && $[1] >= 0 && $[1] <= y) {
                                        if (0 === $[0] && 0 === $[1]) continue;
                                        p = !0
                                    }
                                }
                                if (!p) return
                            }
                            t.isHorizontal() ? ((u || f || d || h) && (s.preventDefault ? s.preventDefault() : s.returnValue = !1), ((f || h) && !i || (u || d) && i) && t.slideNext(), ((u || d) && !i || (f || h) && i) && t.slidePrev()) : ((u || f || c || m) && (s.preventDefault ? s.preventDefault() : s.returnValue = !1), (f || m) && t.slideNext(), (u || c) && t.slidePrev()), t.emit("keyPress", o)
                        }
                    }
                },
                enable: function() {
                    var e = this,
                        t = (0, a.Me)();
                    e.keyboard.enabled || ((0, r.Z)(t).on("keydown", e.keyboard.handle), e.keyboard.enabled = !0)
                },
                disable: function() {
                    var e = this,
                        t = (0, a.Me)();
                    e.keyboard.enabled && ((0, r.Z)(t).off("keydown", e.keyboard.handle), e.keyboard.enabled = !1)
                }
            };
            const l = {
                name: "keyboard",
                params: {
                    keyboard: {
                        enabled: !1,
                        onlyInViewport: !0,
                        pageUpDown: !0
                    }
                },
                create: function() {
                    (0, i.cR)(this, {
                        keyboard: s({
                            enabled: !1
                        }, o)
                    })
                },
                on: {
                    init: function(e) {
                        e.params.keyboard.enabled && e.keyboard.enable()
                    },
                    destroy: function(e) {
                        e.keyboard.enabled && e.keyboard.disable()
                    }
                }
            }
        },
        24224: (e, t, n) => {
            "use strict";
            n.d(t, {
                Z: () => o
            });
            var a = n(6156),
                r = n(7513),
                i = n(28262);
            var s = {
                lastScrollTime: (0, i.zO)(),
                lastEventBeforeSnap: void 0,
                recentWheelEvents: [],
                event: function() {
                    return (0, a.Jj)().navigator.userAgent.indexOf("firefox") > -1 ? "DOMMouseScroll" : function() {
                        var e = (0, a.Me)(),
                            t = "onwheel",
                            n = t in e;
                        if (!n) {
                            var r = e.createElement("div");
                            r.setAttribute(t, "return;"), n = "function" == typeof r.onwheel
                        }
                        return !n && e.implementation && e.implementation.hasFeature && !0 !== e.implementation.hasFeature("", "") && (n = e.implementation.hasFeature("Events.wheel", "3.0")), n
                    }() ? "wheel" : "mousewheel"
                },
                normalize: function(e) {
                    var t = 0,
                        n = 0,
                        a = 0,
                        r = 0;
                    return "detail" in e && (n = e.detail), "wheelDelta" in e && (n = -e.wheelDelta / 120), "wheelDeltaY" in e && (n = -e.wheelDeltaY / 120), "wheelDeltaX" in e && (t = -e.wheelDeltaX / 120), "axis" in e && e.axis === e.HORIZONTAL_AXIS && (t = n, n = 0), a = 10 * t, r = 10 * n, "deltaY" in e && (r = e.deltaY), "deltaX" in e && (a = e.deltaX), e.shiftKey && !a && (a = r, r = 0), (a || r) && e.deltaMode && (1 === e.deltaMode ? (a *= 40, r *= 40) : (a *= 800, r *= 800)), a && !t && (t = a < 1 ? -1 : 1), r && !n && (n = r < 1 ? -1 : 1), {
                        spinX: t,
                        spinY: n,
                        pixelX: a,
                        pixelY: r
                    }
                },
                handleMouseEnter: function() {
                    this.enabled && (this.mouseEntered = !0)
                },
                handleMouseLeave: function() {
                    this.enabled && (this.mouseEntered = !1)
                },
                handle: function(e) {
                    var t = e,
                        n = this;
                    if (n.enabled) {
                        var a = n.params.mousewheel;
                        n.params.cssMode && t.preventDefault();
                        var o = n.$el;
                        if ("container" !== n.params.mousewheel.eventsTarget && (o = (0, r.Z)(n.params.mousewheel.eventsTarget)), !n.mouseEntered && !o[0].contains(t.target) && !a.releaseOnEdges) return !0;
                        t.originalEvent && (t = t.originalEvent);
                        var l = 0,
                            u = n.rtlTranslate ? -1 : 1,
                            f = s.normalize(t);
                        if (a.forceToAxis)
                            if (n.isHorizontal()) {
                                if (!(Math.abs(f.pixelX) > Math.abs(f.pixelY))) return !0;
                                l = -f.pixelX * u
                            } else {
                                if (!(Math.abs(f.pixelY) > Math.abs(f.pixelX))) return !0;
                                l = -f.pixelY
                            }
                        else l = Math.abs(f.pixelX) > Math.abs(f.pixelY) ? -f.pixelX * u : -f.pixelY;
                        if (0 === l) return !0;
                        a.invert && (l = -l);
                        var d = n.getTranslate() + l * a.sensitivity;
                        if (d >= n.minTranslate() && (d = n.minTranslate()), d <= n.maxTranslate() && (d = n.maxTranslate()), (!!n.params.loop || !(d === n.minTranslate() || d === n.maxTranslate())) && n.params.nested && t.stopPropagation(), n.params.freeMode) {
                            var h = {
                                    time: (0, i.zO)(),
                                    delta: Math.abs(l),
                                    direction: Math.sign(l)
                                },
                                c = n.mousewheel.lastEventBeforeSnap,
                                m = c && h.time < c.time + 500 && h.delta <= c.delta && h.direction === c.direction;
                            if (!m) {
                                n.mousewheel.lastEventBeforeSnap = void 0, n.params.loop && n.loopFix();
                                var p = n.getTranslate() + l * a.sensitivity,
                                    v = n.isBeginning,
                                    g = n.isEnd;
                                if (p >= n.minTranslate() && (p = n.minTranslate()), p <= n.maxTranslate() && (p = n.maxTranslate()), n.setTransition(0), n.setTranslate(p), n.updateProgress(), n.updateActiveIndex(), n.updateSlidesClasses(), (!v && n.isBeginning || !g && n.isEnd) && n.updateSlidesClasses(), n.params.freeModeSticky) {
                                    clearTimeout(n.mousewheel.timeout), n.mousewheel.timeout = void 0;
                                    var w = n.mousewheel.recentWheelEvents;
                                    w.length >= 15 && w.shift();
                                    var M = w.length ? w[w.length - 1] : void 0,
                                        y = w[0];
                                    if (w.push(h), M && (h.delta > M.delta || h.direction !== M.direction)) w.splice(0);
                                    else if (w.length >= 15 && h.time - y.time < 500 && y.delta - h.delta >= 1 && h.delta <= 6) {
                                        var D = l > 0 ? .8 : .2;
                                        n.mousewheel.lastEventBeforeSnap = h, w.splice(0), n.mousewheel.timeout = (0, i.Y3)((function() {
                                            n.slideToClosest(n.params.speed, !0, void 0, D)
                                        }), 0)
                                    }
                                    n.mousewheel.timeout || (n.mousewheel.timeout = (0, i.Y3)((function() {
                                        n.mousewheel.lastEventBeforeSnap = h, w.splice(0), n.slideToClosest(n.params.speed, !0, void 0, .5)
                                    }), 500))
                                }
                                if (m || n.emit("scroll", t), n.params.autoplay && n.params.autoplayDisableOnInteraction && n.autoplay.stop(), p === n.minTranslate() || p === n.maxTranslate()) return !0
                            }
                        } else {
                            var T = {
                                    time: (0, i.zO)(),
                                    delta: Math.abs(l),
                                    direction: Math.sign(l),
                                    raw: e
                                },
                                b = n.mousewheel.recentWheelEvents;
                            b.length >= 2 && b.shift();
                            var $ = b.length ? b[b.length - 1] : void 0;
                            if (b.push(T), $ ? (T.direction !== $.direction || T.delta > $.delta || T.time > $.time + 150) && n.mousewheel.animateSlider(T) : n.mousewheel.animateSlider(T), n.mousewheel.releaseScroll(T)) return !0
                        }
                        return t.preventDefault ? t.preventDefault() : t.returnValue = !1, !1
                    }
                },
                animateSlider: function(e) {
                    var t = this,
                        n = (0, a.Jj)();
                    return !(this.params.mousewheel.thresholdDelta && e.delta < this.params.mousewheel.thresholdDelta) && (!(this.params.mousewheel.thresholdTime && (0, i.zO)() - t.mousewheel.lastScrollTime < this.params.mousewheel.thresholdTime) && (e.delta >= 6 && (0, i.zO)() - t.mousewheel.lastScrollTime < 60 || (e.direction < 0 ? t.isEnd && !t.params.loop || t.animating || (t.slideNext(), t.emit("scroll", e.raw)) : t.isBeginning && !t.params.loop || t.animating || (t.slidePrev(), t.emit("scroll", e.raw)), t.mousewheel.lastScrollTime = (new n.Date).getTime(), !1)))
                },
                releaseScroll: function(e) {
                    var t = this,
                        n = t.params.mousewheel;
                    if (e.direction < 0) {
                        if (t.isEnd && !t.params.loop && n.releaseOnEdges) return !0
                    } else if (t.isBeginning && !t.params.loop && n.releaseOnEdges) return !0;
                    return !1
                },
                enable: function() {
                    var e = this,
                        t = s.event();
                    if (e.params.cssMode) return e.wrapperEl.removeEventListener(t, e.mousewheel.handle), !0;
                    if (!t) return !1;
                    if (e.mousewheel.enabled) return !1;
                    var n = e.$el;
                    return "container" !== e.params.mousewheel.eventsTarget && (n = (0, r.Z)(e.params.mousewheel.eventsTarget)), n.on("mouseenter", e.mousewheel.handleMouseEnter), n.on("mouseleave", e.mousewheel.handleMouseLeave), n.on(t, e.mousewheel.handle), e.mousewheel.enabled = !0, !0
                },
                disable: function() {
                    var e = this,
                        t = s.event();
                    if (e.params.cssMode) return e.wrapperEl.addEventListener(t, e.mousewheel.handle), !0;
                    if (!t) return !1;
                    if (!e.mousewheel.enabled) return !1;
                    var n = e.$el;
                    return "container" !== e.params.mousewheel.eventsTarget && (n = (0, r.Z)(e.params.mousewheel.eventsTarget)), n.off(t, e.mousewheel.handle), e.mousewheel.enabled = !1, !0
                }
            };
            const o = {
                name: "mousewheel",
                params: {
                    mousewheel: {
                        enabled: !1,
                        releaseOnEdges: !1,
                        invert: !1,
                        forceToAxis: !1,
                        sensitivity: 1,
                        eventsTarget: "container",
                        thresholdDelta: null,
                        thresholdTime: null
                    }
                },
                create: function() {
                    (0, i.cR)(this, {
                        mousewheel: {
                            enabled: !1,
                            lastScrollTime: (0, i.zO)(),
                            lastEventBeforeSnap: void 0,
                            recentWheelEvents: [],
                            enable: s.enable,
                            disable: s.disable,
                            handle: s.handle,
                            handleMouseEnter: s.handleMouseEnter,
                            handleMouseLeave: s.handleMouseLeave,
                            animateSlider: s.animateSlider,
                            releaseScroll: s.releaseScroll
                        }
                    })
                },
                on: {
                    init: function(e) {
                        !e.params.mousewheel.enabled && e.params.cssMode && e.mousewheel.disable(), e.params.mousewheel.enabled && e.mousewheel.enable()
                    },
                    destroy: function(e) {
                        e.params.cssMode && e.mousewheel.enable(), e.mousewheel.enabled && e.mousewheel.disable()
                    }
                }
            }
        },
        28721: (e, t, n) => {
            "use strict";
            n.d(t, {
                Z: () => u
            });
            const a = {
                randomUUID: "undefined" != typeof crypto && crypto.randomUUID && crypto.randomUUID.bind(crypto)
            };
            let r;
            const i = new Uint8Array(16);

            function s() {
                if (!r && (r = "undefined" != typeof crypto && crypto.getRandomValues && crypto.getRandomValues.bind(crypto), !r)) throw new Error("crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported");
                return r(i)
            }
            const o = [];
            for (let f = 0; f < 256; ++f) o.push((f + 256).toString(16).slice(1));

            function l(e, t = 0) {
                return (o[e[t + 0]] + o[e[t + 1]] + o[e[t + 2]] + o[e[t + 3]] + "-" + o[e[t + 4]] + o[e[t + 5]] + "-" + o[e[t + 6]] + o[e[t + 7]] + "-" + o[e[t + 8]] + o[e[t + 9]] + "-" + o[e[t + 10]] + o[e[t + 11]] + o[e[t + 12]] + o[e[t + 13]] + o[e[t + 14]] + o[e[t + 15]]).toLowerCase()
            }
            const u = function(e, t, n) {
                if (a.randomUUID && !t && !e) return a.randomUUID();
                const r = (e = e || {}).random || (e.rng || s)();
                if (r[6] = 15 & r[6] | 64, r[8] = 63 & r[8] | 128, t) {
                    n = n || 0;
                    for (let e = 0; e < 16; ++e) t[n + e] = r[e];
                    return t
                }
                return l(r)
            }
        }
    }
]);