"use strict";
(self.__LOADABLE_LOADED_CHUNKS__ = self.__LOADABLE_LOADED_CHUNKS__ || []).push([
    [5342], {
        50626: (e, t, n) => {
            n.d(t, {
                W: () => y
            });
            var r = n(59986),
                c = n(22886),
                a = n(5631),
                o = n(55709),
                i = n(81690),
                u = n(582),
                s = n(66008),
                l = n(96381),
                m = n(52329),
                f = n(41931),
                d = n(63438),
                _ = n(52241),
                h = function(e, t) {
                    var n = "function" == typeof Symbol && e[Symbol.iterator];
                    if (!n) return e;
                    var r, c, a = n.call(e),
                        o = [];
                    try {
                        for (;
                            (void 0 === t || t-- > 0) && !(r = a.next()).done;) o.push(r.value)
                    } catch (i) {
                        c = {
                            error: i
                        }
                    } finally {
                        try {
                            r && !r.done && (n = a.return) && n.call(a)
                        } finally {
                            if (c) throw c.error
                        }
                    }
                    return o
                },
                p = function(e, t, n) {
                    if (n || 2 === arguments.length)
                        for (var r, c = 0, a = t.length; c < a; c++) !r && c in t || (r || (r = Array.prototype.slice.call(t, 0, c)), r[c] = t[c]);
                    return e.concat(r || Array.prototype.slice.call(t))
                };

            function y(e) {
                var t = e.remainTime,
                    n = e.delayTime,
                    y = void 0 === n ? 0 : n,
                    v = e.onCallback,
                    g = 1e3,
                    b = h((0, _.m)((function(e, t) {
                        return t.pipe((0, o.U)((function(e) {
                            return p([0, 0], h(e), !1)
                        })), (0, i.j)((function(e) {
                            var t = h(e, 4),
                                n = (t[0], t[1], t[2], t[3]);
                            return (0, r.H)(n)
                        })), (0, o.U)((function(e) {
                            var t = h(e, 4),
                                n = (t[0], t[1], t[2]);
                            t[3];
                            return n
                        })), (0, o.U)((function(e) {
                            return [Number(e > 0 ? e : 0), Date.now()]
                        })))
                    }), [0, 0], [t, y]), 2),
                    E = b[0],
                    N = b[1],
                    S = h((0, _.m)((function(e, t) {
                        return t.pipe((0, u.n)((function(e) {
                            return h(e, 1)[0] < 0
                        })), (0, o.U)((function(e) {
                            var t = h(e, 2),
                                n = t[0],
                                r = t[1];
                            return [n - g, r, 1, g]
                        })), (0, s.h)((function(e) {
                            return h(e, 1)[0] > 0
                        })), (0, l.w)((function(e) {
                            return (0, c.of)(e).pipe((0, m.jn)((function(e) {
                                return h(e, 1)[0] <= 0 ? a.E : (0, c.of)(e).pipe((0, o.U)((function(e) {
                                    var t = h(e, 4),
                                        n = t[0],
                                        r = t[1],
                                        c = t[2],
                                        a = (t[3], n - g),
                                        o = c + 1,
                                        i = Date.now() - (r + o * g),
                                        u = i <= 0 ? 0 : i,
                                        s = g - u,
                                        l = s < 0 ? 0 : s > g ? g : s,
                                        m = 0 === l && u >= 1e3 ? Math.floor(u / g) : 0,
                                        f = a - m * g;
                                    return [f >= 0 ? f : 0, r, o + m, l]
                                })), (0, f.x)((function(e, t) {
                                    return e.map((function(e, n) {
                                        return t[n] === e
                                    })).every((function(e) {
                                        return !0 === e
                                    }))
                                })), (0, i.j)((function(e) {
                                    var t = h(e, 4),
                                        n = (t[0], t[1], t[2], t[3]);
                                    return (0, r.H)(n)
                                })))
                            })))
                        })), (0, o.U)((function(e) {
                            var t = h(e, 4),
                                n = t[0];
                            t[1], t[2], t[3];
                            return n
                        })), (0, f.x)(), (0, o.U)((function(e) {
                            return e / g
                        })), (0, d.b)((function(e) {
                            return e <= 0 && "function" == typeof v && v()
                        })), (0, o.U)((function(e) {
                            return [String(Math.floor(e / 86400)), String(Math.floor(e / 3600 % 24)).padStart(2, "0"), String(Math.floor(e / 60 % 60)).padStart(2, "0"), String(Math.floor(e % 60)).padStart(2, "0")]
                        })))
                    }), ["0", "00", "00", "00"], [E, N]), 4);
                return {
                    days: S[0],
                    hours: S[1],
                    minutes: S[2],
                    seconds: S[3]
                }
            }
        },
        50209: (e, t, n) => {
            n.d(t, {
                i: () => y
            });
            var r = n(67294),
                c = n(94184),
                a = n(59986),
                o = n(41931),
                i = n(81690),
                u = n(55709),
                s = n(66008),
                l = n(582),
                m = n(63438),
                f = n(5602),
                d = n(1796),
                _ = n(52241),
                h = n(50626),
                p = function(e, t) {
                    var n = "function" == typeof Symbol && e[Symbol.iterator];
                    if (!n) return e;
                    var r, c, a = n.call(e),
                        o = [];
                    try {
                        for (;
                            (void 0 === t || t-- > 0) && !(r = a.next()).done;) o.push(r.value)
                    } catch (i) {
                        c = {
                            error: i
                        }
                    } finally {
                        try {
                            r && !r.done && (n = a.return) && n.call(a)
                        } finally {
                            if (c) throw c.error
                        }
                    }
                    return o
                };

            function y(e) {
                var t, n = e.time,
                    y = void 0 === n ? 0 : n,
                    v = e.className,
                    g = e.onStart,
                    b = e.onFinish,
                    E = e.onTiming,
                    N = e.isAutoPlay,
                    S = e.delayTime,
                    x = void 0 === S ? 0 : S,
                    w = e.dataType,
                    D = void 0 === w ? "timeWithDays" : w,
                    A = e.displayType,
                    T = void 0 === A ? "text" : A,
                    U = e.textColor,
                    k = void 0 === U ? "light" : U,
                    F = (0, d.YB)(),
                    W = "mi-count-down",
                    M = "dark" === k ? "".concat(W, "-light") : "",
                    C = p((0, r.useState)(!1 !== N), 2),
                    O = C[0],
                    j = C[1],
                    L = p((0, r.useState)(!1 !== N ? 0 : x), 2),
                    H = L[0],
                    B = L[1];
                (0, r.useEffect)((function() {
                    return j(!1 !== N)
                }), [N]), (0, r.useEffect)((function() {
                    return B(!1 !== N ? 0 : x)
                }), [x]);
                var I = (0, r.useMemo)((function() {
                        return Number.isInteger(y) ? y : y.finishTime - (Math.floor(Date.now() / 1e3) - y.requestTime + y.serverTime)
                    }), [y]),
                    q = p((0, _.m)((function(e, t) {
                        return t.pipe((0, o.x)((function(e, t) {
                            return e[0] === t[0] && e[1] === t[1]
                        })), (0, i.j)((function(e) {
                            var t = p(e, 2),
                                n = (t[0], t[1]);
                            return (0, a.H)(1e3 * n)
                        })), (0, u.U)((function(e) {
                            var t = p(e, 2),
                                n = t[0];
                            return (t[1] > 0 || n) && "function" == typeof g && g(), [n]
                        })))
                    }), [!1], [O, H, I]), 1),
                    K = q[0],
                    P = (0, h.W)({
                        remainTime: H > 0 || K ? 1e3 * I : 0,
                        delayTime: 1e3 * (H || 0),
                        onCallback: function() {
                            return "function" == typeof b ? b() : null
                        }
                    }),
                    X = P.days,
                    Z = P.hours,
                    V = P.minutes,
                    Y = P.seconds;

                function $(e) {
                    var t = Number(X),
                        n = Number(Z),
                        r = Number(V),
                        c = Number(Y);
                    switch (e) {
                        case "seconds":
                        case "secondsWithText":
                            return {
                                days: "0",
                                hours: "00",
                                minutes: "00",
                                seconds: String(c + 60 * r + 3600 * n + 86400 * t).padStart(2, "0")
                            };
                        case "timeWithoutDays":
                            return {
                                days: "0",
                                hours: String(n + 24 * t).padStart(2, "0"),
                                minutes: V,
                                seconds: Y
                            };
                        default:
                            return {
                                days: X,
                                hours: Z,
                                minutes: V,
                                seconds: Y
                            }
                    }
                }
                return (0, _.m)((function(e, t) {
                    return t.pipe((0, s.h)((function() {
                        return "function" == typeof E
                    })), (0, o.x)((function(e, t) {
                        return e[0] === t[0]
                    })), (0, u.U)((function(e) {
                        var t = p(e, 1)[0];
                        return Number(t)
                    })), (0, l.n)((function(e) {
                        return e <= 0
                    })), (0, m.b)((function(e) {
                        return "function" == typeof E && E(e)
                    })), (0, f.h)(void 0))
                }), void 0, [Y]), r.createElement("div", {
                    className: c(W, (t = {}, t["".concat(W, "--").concat(T)] = !!T, t["".concat(W, "-text--icon")] = "timeWithDaysIcon" === D, t), v)
                }, function(e) {
                    switch (e) {
                        case "seconds":
                            return r.createElement(r.Fragment, null, Number($(e).seconds));
                        case "secondsWithText":
                            return r.createElement(r.Fragment, null, F.get("1691578e91bc2625490fe13ce63ea8da", {
                                n: Number($(e).seconds)
                            }));
                        case "timeWithDays":
                            var t = $(e),
                                n = t.days,
                                c = t.hours,
                                a = t.minutes,
                                o = t.seconds,
                                i = "0" === n ? "" : "".concat(F.get("d7dd33406fe94fc18c102ac0888f9dd7", {
                                    n: Number(n)
                                }), " ");
                            return r.createElement(r.Fragment, null, i && r.createElement("strong", {
                                className: "".concat(W, "__date")
                            }, i), r.createElement("strong", {
                                className: "".concat(W, "__time ").concat(W, "__time--hours")
                            }, c), r.createElement("span", {
                                className: "".concat(W, "__colon ").concat(W, "__colon--hours")
                            }, ":"), r.createElement("strong", {
                                className: "".concat(W, "__time ").concat(W, "__time--minutes")
                            }, a), r.createElement("span", {
                                className: "".concat(W, "__colon ").concat(W, "__colon--minutes")
                            }, ":"), r.createElement("strong", {
                                className: "".concat(W, "__time ").concat(W, "__time--seconds")
                            }, o));
                        case "timeWithDaysIcon":
                            var u = $(e),
                                s = u.days,
                                l = u.hours,
                                m = u.minutes,
                                f = u.seconds;
                            return "00" === (i = Number(s) > 9 ? s : "0".concat(s)) && "00" === l && "00" === m && "00" === f ? r.createElement(r.Fragment, null) : r.createElement(r.Fragment, null, r.createElement("div", {
                                className: "".concat(W, "-card ").concat(M)
                            }, r.createElement("strong", {
                                className: "".concat(W, "__time ").concat(W, "__time--date")
                            }, i), r.createElement("div", {
                                className: "".concat(W, "__bottom-text")
                            }, F.get("d7dd33406fe94fc18c102ac0888f9dd7", {
                                n: Number(i)
                            }).replace(/\d+/, "").trim())), r.createElement("div", {
                                className: "".concat(W, "-card ").concat(M)
                            }, r.createElement("strong", {
                                className: "".concat(W, "__time ").concat(W, "__time--hours")
                            }, l), r.createElement("div", {
                                className: "".concat(W, "__bottom-text")
                            }, F.get("d8b7bcc33031a4bcb3822c46861f5b43", {
                                n: Number(l)
                            }).replace(/\d+/, "").trim())), r.createElement("div", {
                                className: "".concat(W, "-card ").concat(M)
                            }, r.createElement("strong", {
                                className: "".concat(W, "__time ").concat(W, "__time--minutes")
                            }, m), r.createElement("div", {
                                className: "".concat(W, "__bottom-text")
                            }, F.get("b6ad50fc34d2635fb618016d7345704b", {
                                n: Number(m)
                            }).replace(/\d+/, "").trim())), r.createElement("div", {
                                className: "".concat(W, "-card ").concat(M)
                            }, r.createElement("strong", {
                                className: "".concat(W, "__time ").concat(W, "__time--seconds")
                            }, f), r.createElement("div", {
                                className: "".concat(W, "__bottom-text")
                            }, F.get("68fe6d4026c41fe7ed5aab2b190960ae", {
                                n: Number(f)
                            }).replace(/\d+/, "").trim())));
                        case "timeWithoutDays":
                            var d = $(e),
                                _ = d.hours,
                                h = d.minutes,
                                p = d.seconds;
                            return r.createElement(r.Fragment, null, r.createElement("strong", {
                                className: "".concat(W, "__time ").concat(W, "__time--hours")
                            }, _), r.createElement("span", {
                                className: "".concat(W, "__colon ").concat(W, "__colon--hours")
                            }, ":"), r.createElement("strong", {
                                className: "".concat(W, "__time ").concat(W, "__time--minutes")
                            }, h), r.createElement("span", {
                                className: "".concat(W, "__colon ").concat(W, "__colon--minutes")
                            }, ":"), r.createElement("strong", {
                                className: "".concat(W, "__time ").concat(W, "__time--seconds")
                            }, p));
                        default:
                            return r.createElement(r.Fragment, null)
                    }
                }(D))
            }
        },
        55342: (e, t, n) => {
            n.d(t, {
                b: () => s
            });
            var r = n(67294),
                c = n(50209),
                a = n(62711),
                o = function() {
                    return o = Object.assign || function(e) {
                        for (var t, n = 1, r = arguments.length; n < r; n++)
                            for (var c in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, c) && (e[c] = t[c]);
                        return e
                    }, o.apply(this, arguments)
                },
                i = function(e, t) {
                    var n = "function" == typeof Symbol && e[Symbol.iterator];
                    if (!n) return e;
                    var r, c, a = n.call(e),
                        o = [];
                    try {
                        for (;
                            (void 0 === t || t-- > 0) && !(r = a.next()).done;) o.push(r.value)
                    } catch (i) {
                        c = {
                            error: i
                        }
                    } finally {
                        try {
                            r && !r.done && (n = a.return) && n.call(a)
                        } finally {
                            if (c) throw c.error
                        }
                    }
                    return o
                },
                u = function(e, t, n) {
                    if (n || 2 === arguments.length)
                        for (var r, c = 0, a = t.length; c < a; c++) !r && c in t || (r || (r = Array.prototype.slice.call(t, 0, c)), r[c] = t[c]);
                    return e.concat(r || Array.prototype.slice.call(t))
                };

            function s(e) {
                var t = e.inputStr,
                    n = e.linkArr,
                    s = e.type,
                    l = e.target,
                    m = e.onClick,
                    f = e.countdown,
                    d = t.split(/#@cd@#/gi);
                if (d.length > 1)
                    for (var _ = 1; _ < d.length; _ += 2) d[_] = r.createElement(r.Fragment, {
                        key: "highlight-countdown"
                    }, f && r.createElement(c.i, o({}, f)));
                var h = d.map((function(e) {
                        if ("string" == typeof e) {
                            for (var t = e.split(/#@icon@#/gi), n = 1; n < t.length; n += 2) t[n] = r.createElement(a.q, {
                                key: "highlight-icon-".concat(n),
                                symbol: t[n]
                            });
                            return t
                        }
                        return e
                    })),
                    p = y(h).map((function(e) {
                        if ("string" == typeof e) {
                            for (var t = ("number" === s ? e.replace(/[+-]?(0|([1-9]\d*))(\.\d+)?/g, "#@@#$&#@@#") : e).split(/#@@#/gi), c = function(e) {
                                    var c = !!n && n[~~(e / 2)] || "";
                                    t[e] = c ? r.createElement("a", {
                                        target: l,
                                        key: "highlight-".concat(e),
                                        onClick: function(e) {
                                            return "function" == typeof m && m(e, c)
                                        },
                                        href: c
                                    }, t[e]) : r.createElement("strong", {
                                        key: "highlight-".concat(e)
                                    }, t[e])
                                }, a = 1; a < t.length; a += 2) c(a);
                            return t
                        }
                        return e
                    }));

                function y(e) {
                    return e.map((function(e) {
                        return Array.isArray(e) ? u([], i(e), !1) : [e]
                    })).reduce((function(e, t) {
                        return u(u([], i(e), !1), i(t.filter((function(e) {
                            return void 0 !== e
                        }))), !1)
                    }), [])
                }
                return r.createElement(r.Fragment, null, y(p))
            }
        },
        52241: (e, t, n) => {
            n.d(t, {
                m: () => u
            });
            var r = n(89233),
                c = n(63438),
                a = n(67294),
                o = n(98963),
                i = n(61688);

            function u(e, t, n) {
                var u = (0, o.Z)((function() {
                        return new r.X(t)
                    })),
                    s = (0, o.Z)((function() {
                        return new r.X(n)
                    }));
                (0, a.useEffect)((function() {
                    return function() {
                        u.complete(), s.complete()
                    }
                }), []), (0, a.useEffect)((function() {
                    s.next(n)
                }), n || []);
                var l = (0, a.useMemo)((function() {
                        var t;
                        return t = n ? e(u, s) : e(u),
                            function(e) {
                                var n = t.pipe((0, c.b)((function(e) {
                                    return u.next(e)
                                }))).subscribe(e);
                                return function() {
                                    return n.unsubscribe()
                                }
                            }
                    }), []),
                    m = (0, a.useMemo)((function() {
                        return function() {
                            var e;
                            return null !== (e = u.getValue()) && void 0 !== e ? e : null
                        }
                    }), []);
                return (0, i.useSyncExternalStore)(l, m, m)
            }
        }
    }
]);