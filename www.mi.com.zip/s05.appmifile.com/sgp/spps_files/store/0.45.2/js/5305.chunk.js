"use strict";
(self.__LOADABLE_LOADED_CHUNKS__ = self.__LOADABLE_LOADED_CHUNKS__ || []).push([
    [5305], {
        82138: (e, t, a) => {
            a.d(t, {
                X: () => k,
                k: () => V
            });
            var n = a(67294),
                r = a(16550),
                i = a(1796),
                o = a(86690),
                c = a(67970),
                l = a(55342),
                s = a(7651),
                u = a(28553),
                d = a(94184),
                m = a.n(d),
                f = a(88039),
                p = a(28396),
                v = a(62711),
                y = a(56024),
                _ = function(e, t) {
                    var a = "function" == typeof Symbol && e[Symbol.iterator];
                    if (!a) return e;
                    var n, r, i = a.call(e),
                        o = [];
                    try {
                        for (;
                            (void 0 === t || t-- > 0) && !(n = i.next()).done;) o.push(n.value)
                    } catch (c) {
                        r = {
                            error: c
                        }
                    } finally {
                        try {
                            n && !n.done && (a = i.return) && a.call(i)
                        } finally {
                            if (r) throw r.error
                        }
                    }
                    return o
                };

            function h(e) {
                var t, a = (0, i.YB)(),
                    r = (0, y.a)(),
                    o = e.className,
                    c = void 0 === o ? "" : o,
                    l = e.usage,
                    s = void 0 === l ? "display" : l,
                    u = e.totalStars,
                    d = void 0 === u ? 5 : u,
                    f = e.lightUpStars,
                    p = void 0 === f ? 0 : f,
                    h = e.onClick,
                    g = _((0, n.useState)(-1), 2),
                    S = g[0],
                    b = g[1];

                function E(e) {
                    "rate" === s && "function" == typeof h && h(e)
                }
                var N = [a.get("33cf5ec0ada0b91b96379f7a2e7dd558"), a.get("0e94d01753f69bda9b5060a18994540d"), a.get("b1897515d548a960afe49ecf66a29021"), a.get("0c6ad70beb3a7e76c3fc7adab7c46acc"), a.get("fcc2d28a33d2df558f18766e067569c6")],
                    C = function(e) {
                        "mobile" === r ? E(e) : b(e)
                    },
                    w = "feed-back";
                return n.createElement("div", {
                    className: m()(w, (t = {}, t[c] = !!c, t))
                }, n.createElement("ul", {
                    className: "".concat(w, "__list")
                }, Array.from({
                    length: Math.floor(d)
                }, (function() {
                    return null
                })).map((function(e, t) {
                    var a, r;
                    return n.createElement("li", {
                        key: t,
                        className: "".concat(w, "__item")
                    }, n.createElement(v.q, {
                        symbol: "star",
                        className: m()("".concat(w, "__star"), "".concat(w, "__star--top"), (a = {}, a["".concat(w, "__star--interactive")] = "rate" === s, a)),
                        style: {
                            width: Math.floor(S) > t || Math.floor(p) > t ? "100%" : Math.ceil(p) > t ? "".concat(p % 1 * 100, "%") : "0"
                        },
                        onClick: function() {
                            return E(t + 1)
                        },
                        onMouseEnter: function() {
                            return C(t + 1)
                        },
                        onMouseLeave: function() {
                            return b(-1)
                        }
                    }), n.createElement(v.q, {
                        symbol: "star",
                        className: m()("".concat(w, "__star"), "".concat(w, "__star--bottom"), (r = {}, r["".concat(w, "__star--interactive")] = "rate" === s, r)),
                        onClick: function() {
                            return E(t + 1)
                        },
                        onMouseEnter: function() {
                            return C(t + 1)
                        },
                        onMouseLeave: function() {
                            return b(-1)
                        }
                    }))
                }))), n.createElement("span", {
                    className: "".concat(w, "__text")
                }, S > -1 ? N[S - 1] : p > -1 ? N[p - 1] : ""))
            }
            var g = function(e, t) {
                    var a = "function" == typeof Symbol && e[Symbol.iterator];
                    if (!a) return e;
                    var n, r, i = a.call(e),
                        o = [];
                    try {
                        for (;
                            (void 0 === t || t-- > 0) && !(n = i.next()).done;) o.push(n.value)
                    } catch (c) {
                        r = {
                            error: c
                        }
                    } finally {
                        try {
                            n && !n.done && (a = i.return) && a.call(i)
                        } finally {
                            if (r) throw r.error
                        }
                    }
                    return o
                },
                S = "mi-textarea";

            function b(e) {
                var t, a = e.className,
                    r = e.getInputValue,
                    i = e.value,
                    o = g((0, n.useState)(!1), 2),
                    c = o[0],
                    l = o[1],
                    s = g((0, n.useState)(i), 2),
                    u = s[0],
                    d = s[1],
                    f = m()(S, ((t = {})["".concat(a)] = a, t["".concat(S, "--active")] = c, t));
                return n.createElement("div", {
                    className: f
                }, n.createElement("textarea", {
                    value: u,
                    onFocus: function() {
                        l(!0)
                    },
                    onBlur: function(e) {
                        return function(e) {
                            l(!1), r(e)
                        }(e.target.value)
                    },
                    onChange: function(e) {
                        return function(e) {
                            var t = e.substring(0, 500);
                            d(t)
                        }(e.target.value)
                    }
                }))
            }
            var E = "feed-question";

            function N(e) {
                var t, a, r, o, c, l = (0, i.YB)(),
                    s = e.type,
                    u = e.choiceType,
                    m = e.question,
                    v = e.isEmpty,
                    y = e.onChangeInfo,
                    _ = e.questionId,
                    g = e.answerList,
                    S = e.inputValue,
                    N = e.isMoreClass,
                    C = void 0 !== N && N,
                    w = e.className,
                    V = l.get("64b5ea4592df8a97beab501ec833f1f0");
                return 64739e4 === s && 64739e4 === u ? n.createElement("div", {
                    className: "".concat(E)
                }, n.createElement("div", {
                    className: d("".concat(E, "__detail--radio-box"), (t = {}, t[w || ""] = !!w, t))
                }, n.createElement("span", {
                    className: "".concat(E, "__detail-question")
                }, m), v && n.createElement("span", {
                    className: "".concat(E, "__detail-err")
                }, V), n.createElement("div", {
                    className: "".concat(E, "__detail-answer")
                }, g.map((function(e, t) {
                    return n.createElement("div", {
                        className: "".concat(E, "__detail--radio-item"),
                        key: t
                    }, n.createElement(f.Z, {
                        className: "".concat(E, "__detail--radio"),
                        selectedValue: S,
                        value: String(t),
                        onChange: function() {
                            return y(String(t), _)
                        }
                    }), n.createElement("span", {
                        className: "".concat(E, "__detail-text")
                    }, e))
                }))))) : 647390001 === s ? n.createElement("div", {
                    className: "".concat(E)
                }, n.createElement("div", {
                    className: d("".concat(E, "__detail--input-box"), (a = {}, a["".concat(E, "__detail--no-space")] = C, a[w || ""] = !!w, a))
                }, n.createElement("span", {
                    className: "".concat(E, "__detail-question")
                }, m), n.createElement(b, {
                    className: d("".concat(E, "__detail-input"), (r = {}, r[w || ""] = !!w, r)),
                    getInputValue: function(e) {
                        return y(e, _)
                    },
                    value: S ? String(S) : ""
                }))) : 647390002 === s ? n.createElement("div", {
                    className: "".concat(E)
                }, n.createElement("div", {
                    className: d("".concat(E, "__detail--star-box"), (o = {}, o[w || ""] = !!w, o))
                }, n.createElement("span", {
                    className: "".concat(E, "__detail-question")
                }, m), v && n.createElement("span", {
                    className: "".concat(E, "__detail-err")
                }, V), n.createElement("div", {
                    className: "".concat(E, "__detail-star")
                }, n.createElement(h, {
                    usage: "rate",
                    lightUpStars: Number(S),
                    onClick: function(e) {
                        return y(e, _)
                    }
                })))) : 64739e4 === s && 647390001 === u ? n.createElement("div", {
                    className: "".concat(E)
                }, n.createElement("div", {
                    className: d("".concat(E, "__detail--radio-box ").concat(E, "__detail--checkout-box"), (c = {}, c[w || ""] = !!w, c))
                }, n.createElement("span", {
                    className: "".concat(E, "__detail-question")
                }, m), v && n.createElement("span", {
                    className: "".concat(E, "__detail-err")
                }, V), n.createElement("div", {
                    className: "".concat(E, "__detail-answer ").concat(E, "__detail-answer-checkout")
                }, g.map((function(e, t) {
                    return n.createElement("div", {
                        className: "".concat(E, "__detail--checkout-item"),
                        key: t
                    }, n.createElement(p.Z, {
                        className: "".concat(E, "__detail--checkout"),
                        onChange: function() {
                            return y(t, _)
                        },
                        checked: String(S).includes(String(t))
                    }), n.createElement("span", {
                        className: "".concat(E, "__detail-text")
                    }, e))
                }))))) : n.createElement(n.Fragment, null)
            }
            var C = function() {
                    return C = Object.assign || function(e) {
                        for (var t, a = 1, n = arguments.length; a < n; a++)
                            for (var r in t = arguments[a]) Object.prototype.hasOwnProperty.call(t, r) && (e[r] = t[r]);
                        return e
                    }, C.apply(this, arguments)
                },
                w = function(e, t) {
                    var a = "function" == typeof Symbol && e[Symbol.iterator];
                    if (!a) return e;
                    var n, r, i = a.call(e),
                        o = [];
                    try {
                        for (;
                            (void 0 === t || t-- > 0) && !(n = i.next()).done;) o.push(n.value)
                    } catch (c) {
                        r = {
                            error: c
                        }
                    } finally {
                        try {
                            n && !n.done && (a = i.return) && a.call(i)
                        } finally {
                            if (r) throw r.error
                        }
                    }
                    return o
                },
                V = {
                    1: ["support", {
                        c: 2,
                        e: 32881
                    }],
                    2: ["support_service-centre", {
                        c: 4,
                        e: 32882
                    }],
                    3: ["support_spare-parts-price", {
                        c: 3,
                        e: 32884
                    }],
                    4: ["support_service-progress", {
                        c: 3,
                        e: 32883
                    }],
                    5: ["support_aftersales_applylist_feedback", {
                        c: 2,
                        e: 32889
                    }]
                };

            function k(e) {
                var t = e.successFunc,
                    a = e.propsQuestionList,
                    d = e.propsMsfpSurveyId,
                    m = e.propsMsfpSurveyName,
                    f = e.propsUserId,
                    p = e.getNewListInfo,
                    v = e.className,
                    y = e.type,
                    _ = (0, i.YB)(),
                    h = (0, i.oW)(),
                    g = (0, n.useContext)(c.J),
                    S = (0, r.TH)().state,
                    b = w((0, n.useState)(a), 2),
                    E = b[0],
                    k = b[1],
                    L = w((0, n.useState)(""), 2),
                    x = L[0],
                    A = L[1],
                    I = w((0, n.useState)(!1), 2),
                    M = I[0],
                    q = I[1],
                    O = function() {
                        var e = !1,
                            a = E.map((function(t) {
                                return 647390001 === t.type || t.inputValue || (e = !0), C(C({}, t), {
                                    isEmpty: !t.inputValue
                                })
                            }));
                        k(a), M || e || (! function(e) {
                            var a = e.map((function(e) {
                                return {
                                    questionId: e.questionId,
                                    msfpSourcequestionidentifier: e.sourceQuestionIdentifier,
                                    answer: e.inputValue ? String(e.inputValue) : ""
                                }
                            }));
                            g.getService({
                                params: {
                                    code: f || "",
                                    workorderId: (null == S ? void 0 : S.workorderId) || "",
                                    msfpSurveyId: d || "",
                                    msfpSurveyName: m || "",
                                    dataList: a,
                                    country: h.local
                                }
                            }, (function(e) {
                                q(!1), (0, o.otClick)({
                                    tip: V[y][1],
                                    pageType: V[y][0],
                                    elementName: 5 === y ? "feedback" : "selfservice-feedback",
                                    elementTitle: "submit",
                                    isOpenGA: !0
                                }), 200 === (null == e ? void 0 : e.errNo) ? t(!0) : A((null == e ? void 0 : e.errMsg) || "")
                            }))
                        }(a), q(!0))
                    },
                    Q = function(e, t) {
                        var a = 0,
                            n = 0,
                            r = E[0],
                            i = E.map((function(i, o) {
                                if (i.questionId === t) {
                                    var c = void 0;
                                    if (64739e4 === i.type)
                                        if (647390001 === i.choiceType) {
                                            var l = "",
                                                s = i.noShowValue || "";
                                            l = i.inputValue && String(i.inputValue).indexOf(String(e)) > -1 ? String(i.inputValue).split(",").filter((function(t) {
                                                return t !== String(e)
                                            })).join(",") : i.inputValue ? i.inputValue + "," + e : String(e);
                                            var u = i.inputValue && String(i.inputValue).includes(String(i.answerList.length - 1));
                                            i.dataChildList && 64739e4 === i.type && e === i.answerList.length - 1 && u ? (a = 2, n = o + 1, s = String(E[o + 1].inputValue) || "") : i.dataChildList && 64739e4 === i.type && e === i.answerList.length - 1 && (a = 1, n = o + 1, r = C(C({}, i.dataChildList[0]), {
                                                isEmpty: !1,
                                                question: "",
                                                isMoreClass: !0,
                                                inputValue: i.noShowValue || ""
                                            })), c = C(C({}, i), {
                                                inputValue: l,
                                                noShowValue: s,
                                                isEmpty: !l
                                            })
                                        } else c = C(C({}, i), {
                                            inputValue: e,
                                            isEmpty: !e
                                        });
                                    else if (647390002 === i.type && i.dataChildList)
                                        if (n = o + 1, Number(e) > 3) {
                                            s = String(E[o + 1].inputValue) || "";
                                            !1 === i.isAddMoreQuestion || void 0 === i.isAddMoreQuestion ? c = C(C({}, i), {
                                                inputValue: e,
                                                isAddMoreQuestion: !1,
                                                noShowValue: i.noShowValue,
                                                isEmpty: !e
                                            }) : (a = 2, c = C(C({}, i), {
                                                inputValue: e,
                                                isAddMoreQuestion: !1,
                                                noShowValue: s,
                                                isEmpty: !e
                                            }))
                                        } else i.isAddMoreQuestion ? a = 0 : (a = 1, r = C(C({}, i.dataChildList[0]), {
                                            isEmpty: !1,
                                            inputValue: "undefined" === i.noShowValue ? "" : i.noShowValue
                                        })), c = C(C({}, i), {
                                            inputValue: e,
                                            isAddMoreQuestion: !0,
                                            isEmpty: !e
                                        });
                                    else c = C(C({}, i), {
                                        inputValue: e,
                                        isEmpty: !e
                                    });
                                    return c
                                }
                                return i
                            }));
                        1 === a ? i.splice(n, 0, r) : 2 === a && i.splice(n, 1), k(i), p && p(i)
                    };
                return n.createElement(n.Fragment, null, E.map((function(e) {
                    return n.createElement(N, C({}, e, {
                        onChangeInfo: Q,
                        key: e.questionId,
                        className: v
                    }))
                })), n.createElement("span", {
                    className: "feedback__privacy"
                }, n.createElement(l.b, {
                    inputStr: _.get("1371619ec9ccc7d1d167c04d7f90d2d2", {
                        n1: "#@@#".concat(_.get("ca0f9a86ca33f1d6baa9051bd7f4ed21"), "#@@#")
                    }),
                    target: "_blank",
                    linkArr: ["".concat(h.wwwSite.pc, "/about/privacy")]
                })), n.createElement(s.z, {
                    className: "feedback__btn",
                    onClick: function() {
                        return O()
                    }
                }, _.get("a4d3b161ce1309df1c4e25df28694b7b")), n.createElement(u.F, {
                    msg: x,
                    callback: function() {
                        return A("")
                    },
                    type: "error",
                    className: "mi-address__toast"
                }))
            }
        },
        7148: (e, t, a) => {
            a.d(t, {
                c: () => u,
                o: () => s
            });
            var n = a(67294),
                r = a(16607),
                i = a(96625),
                o = a(56024),
                c = function(e, t) {
                    var a = "function" == typeof Symbol && e[Symbol.iterator];
                    if (!a) return e;
                    var n, r, i = a.call(e),
                        o = [];
                    try {
                        for (;
                            (void 0 === t || t-- > 0) && !(n = i.next()).done;) o.push(n.value)
                    } catch (c) {
                        r = {
                            error: c
                        }
                    } finally {
                        try {
                            n && !n.done && (a = i.return) && a.call(i)
                        } finally {
                            if (r) throw r.error
                        }
                    }
                    return o
                },
                l = (0, r.o)(d),
                s = (0, n.createContext)(l);

            function u(e) {
                var t = e.siteConfig,
                    a = e.isAutoFetch,
                    r = e.children,
                    u = (0, o.a)(),
                    m = c((0, n.useState)(l), 2),
                    f = m[0],
                    p = m[1];

                function v(e) {
                    var t = e.body,
                        a = (null == e ? void 0 : e.errmsg) || (null == e ? void 0 : e.message),
                        n = (null == e ? void 0 : e.errno) || (null == e ? void 0 : e.statusCode);
                    return {
                        errMsg: String(a),
                        errNo: Number(n),
                        data: d(t || [])
                    }
                }
                var y = {
                    url: "".concat(t.apiSite, "/crm/api/XGetQuestion"),
                    method: "POST",
                    basicParams: {
                        from: "mobile" === u ? "mobile" : "pc"
                    },
                    headers: {
                        "Content-Type": "application/json"
                    },
                    retryOptions: {
                        maxRetryAttempts: 3,
                        scalingDuration: 3e3
                    },
                    withCredentials: !0
                };
                return n.createElement(i.h, {
                    context: s,
                    setState: p,
                    defaultValue: l,
                    adapterError: function(e) {
                        return v(e)
                    },
                    adapter: v,
                    value: f,
                    siteConfig: t,
                    isAutoFetch: !0 === a,
                    ajaxConfig: y
                }, r)
            }

            function d(e) {
                return {
                    dataList: m(Array.from(e.dataList || [])),
                    msfpSurveyId: e.msfpSurveyId,
                    msfpSurveyName: e.msfpSurveyName
                }
            }

            function m(e) {
                return e.map((function(e) {
                    return {
                        question: e.question || "",
                        type: e.type || 0,
                        choiceType: e.choiceType || 0,
                        answerList: e.answerList || [],
                        questionId: e.msfpQuestionId || "",
                        sourceQuestionIdentifier: e.msfpSourcequestionidentifier || "",
                        dataChildList: e.dataChildList && m(e.dataChildList) || null
                    }
                }))
            }
        },
        67970: (e, t, a) => {
            a.d(t, {
                J: () => s,
                j: () => u
            });
            var n = a(67294),
                r = a(16607),
                i = a(96625),
                o = a(56024),
                c = function(e, t) {
                    var a = "function" == typeof Symbol && e[Symbol.iterator];
                    if (!a) return e;
                    var n, r, i = a.call(e),
                        o = [];
                    try {
                        for (;
                            (void 0 === t || t-- > 0) && !(n = i.next()).done;) o.push(n.value)
                    } catch (c) {
                        r = {
                            error: c
                        }
                    } finally {
                        try {
                            n && !n.done && (a = i.return) && a.call(i)
                        } finally {
                            if (r) throw r.error
                        }
                    }
                    return o
                },
                l = (0, r.o)(d),
                s = (0, n.createContext)(l);

            function u(e) {
                var t = e.siteConfig,
                    a = e.isAutoFetch,
                    r = e.children,
                    u = (0, o.a)(),
                    d = c((0, n.useState)(l), 2),
                    m = d[0],
                    f = d[1];

                function p(e) {
                    var t = e.body,
                        a = (null == e ? void 0 : e.errmsg) || (null == e ? void 0 : e.message),
                        n = (null == e ? void 0 : e.errno) || (null == e ? void 0 : e.statusCode);
                    return {
                        errMsg: String(a),
                        errNo: Number(n),
                        data: t
                    }
                }
                var v = {
                    url: "".concat(t.apiSite, "/crm/api/XSaveAnswer"),
                    method: "POST",
                    basicParams: {
                        from: "mobile" === u ? "mobile" : "pc"
                    },
                    headers: {
                        "Content-Type": "application/json"
                    },
                    retryOptions: {
                        maxRetryAttempts: 3,
                        scalingDuration: 3e3
                    },
                    withCredentials: !0
                };
                return n.createElement(i.h, {
                    context: s,
                    setState: f,
                    defaultValue: l,
                    adapterError: function(e) {
                        return p(e)
                    },
                    adapter: p,
                    value: m,
                    siteConfig: t,
                    isAutoFetch: !0 === a,
                    ajaxConfig: v
                }, r)
            }

            function d(e) {
                return e
            }
        },
        42296: (e, t, a) => {
            a.d(t, {
                B: () => r
            });
            var n = {
                    de: 1031,
                    it: 1040,
                    es: 3082,
                    fr: 1036,
                    nl: 1043,
                    pl: 1045,
                    jp: 1041,
                    ru: 1049,
                    vn: 1066,
                    th: 1054,
                    eg: 1025,
                    sa: 1025,
                    mx: 3082,
                    id: 1057,
                    tr: 1055,
                    hk: 3076,
                    tw: 1028,
                    default: 1033
                },
                r = function(e) {
                    return n[e] || n.default
                }
        }
    }
]);